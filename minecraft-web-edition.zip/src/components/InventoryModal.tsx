/**
 * Inventory Modal: 2x2 Player Crafting Grid, 27 Inventory slots, 9 Hotbar slots,
 * and Creative Mode catalog browser.
 */

import React, { useState } from 'react';
import { GameMode, ItemStack, ItemType } from '../types/game';
import { findMatchingRecipe } from '../engine/crafting';
import { CREATIVE_BLOCKS, ITEMS } from '../engine/items';
import { sound } from '../engine/sound';
import { getItemDataUrl } from '../engine/textures';

interface InventoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  hotbar: (ItemStack | null)[];
  setHotbar: React.Dispatch<React.SetStateAction<(ItemStack | null)[]>>;
  inventory: (ItemStack | null)[];
  setInventory: React.Dispatch<React.SetStateAction<(ItemStack | null)[]>>;
  gameMode: GameMode;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({
  isOpen,
  onClose,
  hotbar,
  setHotbar,
  inventory,
  setInventory,
  gameMode,
}) => {
  const [activeTab, setActiveTab] = useState<'inventory' | 'creative'>(
    gameMode === 'creative' ? 'creative' : 'inventory'
  );
  const [search, setSearch] = useState('');
  const [heldItem, setHeldItem] = useState<ItemStack | null>(null);

  // 2x2 Crafting Grid
  const [craftGrid, setCraftGrid] = useState<(ItemStack | null)[][]>([
    [null, null],
    [null, null],
  ]);

  if (!isOpen) return null;

  // Recipe result
  const craftResult = findMatchingRecipe(craftGrid);

  // Handle clicking a slot with held cursor item
  const handleSlotClick = (
    currentStack: ItemStack | null,
    setStack: (val: ItemStack | null) => void
  ) => {
    sound.playClick();

    if (!heldItem) {
      if (currentStack) {
        setHeldItem(currentStack);
        setStack(null);
      }
    } else {
      if (!currentStack) {
        setStack(heldItem);
        setHeldItem(null);
      } else if (currentStack.id === heldItem.id) {
        const max = ITEMS[heldItem.id]?.maxStack || 64;
        const space = max - currentStack.count;
        if (space > 0) {
          const move = Math.min(space, heldItem.count);
          setStack({ id: currentStack.id, count: currentStack.count + move });
          if (heldItem.count - move <= 0) {
            setHeldItem(null);
          } else {
            setHeldItem({ id: heldItem.id, count: heldItem.count - move });
          }
        } else {
          // Swap
          setStack(heldItem);
          setHeldItem(currentStack);
        }
      } else {
        // Swap different items
        setStack(heldItem);
        setHeldItem(currentStack);
      }
    }
  };

  const handleCraftResultClick = () => {
    if (!craftResult) return;
    sound.playPop();

    // Give result to held cursor or inventory
    if (!heldItem) {
      setHeldItem({ ...craftResult });
    } else if (heldItem.id === craftResult.id) {
      const max = ITEMS[heldItem.id]?.maxStack || 64;
      if (heldItem.count + craftResult.count <= max) {
        setHeldItem({ id: heldItem.id, count: heldItem.count + craftResult.count });
      } else {
        return; // Full
      }
    } else {
      return; // Can't place different item
    }

    // Decrement 1 from each craft grid slot
    setCraftGrid((prev) =>
      prev.map((row) =>
        row.map((slot) => {
          if (!slot) return null;
          if (slot.count <= 1) return null;
          return { ...slot, count: slot.count - 1 };
        })
      )
    );
  };

  // Add creative item to first empty hotbar/inventory slot
  const handleCreativeItemClick = (id: ItemType) => {
    sound.playPop();
    const isTool = ITEMS[id]?.maxStack === 1;
    const count = isTool ? 1 : 64;

    // Fill hotbar first
    const hIdx = hotbar.findIndex((s) => s === null);
    if (hIdx !== -1) {
      const newH = [...hotbar];
      newH[hIdx] = { id, count };
      setHotbar(newH);
      return;
    }

    // Otherwise inventory
    const iIdx = inventory.findIndex((s) => s === null);
    if (iIdx !== -1) {
      const newI = [...inventory];
      newI[iIdx] = { id, count };
      setInventory(newI);
    }
  };

  const filteredCreativeItems = CREATIVE_BLOCKS.filter((id) =>
    ITEMS[id]?.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs select-none p-4"
      onClick={() => {
        // Put held item back into inventory if clicking outside
        if (heldItem) {
          const idx = inventory.findIndex((s) => s === null);
          if (idx !== -1) {
            const next = [...inventory];
            next[idx] = heldItem;
            setInventory(next);
            setHeldItem(null);
          }
        }
      }}
    >
      {/* Floating held item following cursor */}
      {heldItem && (
        <div
          className="fixed pointer-events-none z-50 -translate-x-1/2 -translate-y-1/2"
          id="held-cursor-item"
        >
          <div className="relative w-10 h-10 flex items-center justify-center">
            <img
              src={getItemDataUrl(heldItem.id)}
              alt={heldItem.id}
              className="w-8 h-8 object-contain pixelated drop-shadow-md"
            />
            {heldItem.count > 1 && (
              <span className="absolute bottom-0 right-0 font-minecraft text-xs font-bold text-white drop-shadow">
                {heldItem.count}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Main Panel */}
      <div
        className="mc-panel w-full max-w-xl p-5 rounded-lg flex flex-col gap-4 text-[#333333] shadow-2xl relative"
        onClick={(e) => e.stopPropagation()}
        onMouseMove={(e) => {
          const el = document.getElementById('held-cursor-item');
          if (el) {
            el.style.left = `${e.clientX}px`;
            el.style.top = `${e.clientY}px`;
          }
        }}
      >
        {/* Header Tabs & Close */}
        <div className="flex justify-between items-center border-b-2 border-[#888888] pb-2">
          <div className="flex gap-2">
            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('inventory');
              }}
              className={`px-3 py-1 font-minecraft text-xs font-bold ${
                activeTab === 'inventory' ? 'mc-btn text-yellow-300' : 'mc-btn'
              }`}
            >
              Crafting & Bag
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('creative');
              }}
              className={`px-3 py-1 font-minecraft text-xs font-bold ${
                activeTab === 'creative' ? 'mc-btn text-yellow-300' : 'mc-btn'
              }`}
            >
              Creative Items
            </button>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="mc-btn px-2 py-0.5 font-minecraft text-sm"
          >
            ✕
          </button>
        </div>

        {/* Tab 1: Survival Inventory & 2x2 Crafting */}
        {activeTab === 'inventory' && (
          <div className="flex flex-col gap-4">
            {/* Top Row: Character preview & 2x2 Crafting Grid */}
            <div className="flex items-center justify-between px-3 py-2 bg-[#b0b0b0] rounded border-2 border-[#888888]">
              {/* Steve Avatar Box */}
              <div className="w-24 h-28 bg-[#8b8b8b] border-2 border-[#555] rounded flex flex-col items-center justify-center p-2 text-center shadow-inner">
                <div className="w-12 h-12 bg-[#c48c66] rounded-xs border border-black/40 flex items-center justify-center relative overflow-hidden">
                  {/* Steve Hair */}
                  <div className="absolute top-0 inset-x-0 h-3 bg-[#4a2e18]" />
                  {/* Steve Eyes */}
                  <div className="flex gap-2 z-10 mt-1">
                    <div className="w-1.5 h-1.5 bg-white flex items-center justify-center">
                      <div className="w-1 h-1 bg-[#2b5996]" />
                    </div>
                    <div className="w-1.5 h-1.5 bg-white flex items-center justify-center">
                      <div className="w-1 h-1 bg-[#2b5996]" />
                    </div>
                  </div>
                  {/* Steve Beard/Mouth */}
                  <div className="absolute bottom-1 w-3 h-1.5 bg-[#4a2e18]" />
                </div>
                <span className="font-minecraft text-[10px] mt-2 text-white drop-shadow">Player</span>
              </div>

              {/* 2x2 Crafting Grid */}
              <div className="flex items-center gap-3">
                <div className="flex flex-col items-center">
                  <span className="font-minecraft text-[11px] font-bold mb-1 text-[#222]">Crafting</span>
                  <div className="grid grid-cols-2 gap-1 p-1 bg-[#8b8b8b] border border-[#555] rounded">
                    {[0, 1].map((r) =>
                      [0, 1].map((c) => (
                        <div
                          key={`${r}-${c}`}
                          onClick={() =>
                            handleSlotClick(craftGrid[r][c], (newStack) => {
                              const next = craftGrid.map((row) => [...row]);
                              next[r][c] = newStack;
                              setCraftGrid(next);
                            })
                          }
                          className="w-10 h-10 mc-slot flex items-center justify-center cursor-pointer"
                        >
                          {craftGrid[r][c] && (
                            <div className="relative w-8 h-8 flex items-center justify-center">
                              <img
                                src={getItemDataUrl(craftGrid[r][c]!.id)}
                                alt=""
                                className="w-7 h-7 object-contain pixelated pointer-events-none"
                              />
                              {craftGrid[r][c]!.count > 1 && (
                                <span className="absolute bottom-0 right-0 font-minecraft text-[10px] font-bold text-white drop-shadow">
                                  {craftGrid[r][c]!.count}
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Arrow */}
                <div className="text-xl font-bold font-minecraft text-[#444]">➔</div>

                {/* Craft Result */}
                <div className="flex flex-col items-center">
                  <span className="font-minecraft text-[11px] font-bold mb-1 text-[#222]">Result</span>
                  <div
                    onClick={handleCraftResultClick}
                    className={`w-12 h-12 mc-slot flex items-center justify-center border-2 border-amber-600 cursor-pointer ${
                      craftResult ? 'hover:scale-105 ring-1 ring-yellow-400' : ''
                    }`}
                  >
                    {craftResult && (
                      <div className="relative w-10 h-10 flex items-center justify-center animate-pulse">
                        <img
                          src={getItemDataUrl(craftResult.id)}
                          alt=""
                          className="w-9 h-9 object-contain pixelated pointer-events-none drop-shadow"
                        />
                        {craftResult.count > 1 && (
                          <span className="absolute bottom-0 right-0 font-minecraft text-xs font-bold text-white drop-shadow">
                            {craftResult.count}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* 27 Inventory Slots (3 rows of 9) */}
            <div>
              <span className="font-minecraft text-[11px] font-bold text-[#333] mb-1 block">Inventory</span>
              <div className="grid grid-cols-9 gap-1 p-1.5 bg-[#8b8b8b] border-2 border-[#555] rounded">
                {inventory.map((slot, index) => (
                  <div
                    key={index}
                    onClick={() =>
                      handleSlotClick(slot, (newStack) => {
                        const next = [...inventory];
                        next[index] = newStack;
                        setInventory(next);
                      })
                    }
                    className="w-10 h-10 mc-slot flex items-center justify-center cursor-pointer hover:brightness-110"
                  >
                    {slot && (
                      <div className="relative w-8 h-8 flex items-center justify-center">
                        <img
                          src={getItemDataUrl(slot.id)}
                          alt=""
                          className="w-7 h-7 object-contain pixelated pointer-events-none"
                        />
                        {slot.count > 1 && (
                          <span className="absolute bottom-0 right-0 font-minecraft text-[10px] font-bold text-white drop-shadow">
                            {slot.count}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* 9 Hotbar Slots */}
            <div>
              <span className="font-minecraft text-[11px] font-bold text-[#333] mb-1 block">Hotbar</span>
              <div className="grid grid-cols-9 gap-1 p-1.5 bg-[#8b8b8b] border-2 border-[#555] rounded">
                {hotbar.map((slot, index) => (
                  <div
                    key={index}
                    onClick={() =>
                      handleSlotClick(slot, (newStack) => {
                        const next = [...hotbar];
                        next[index] = newStack;
                        setHotbar(next);
                      })
                    }
                    className="w-10 h-10 mc-slot flex items-center justify-center cursor-pointer hover:brightness-110"
                  >
                    {slot && (
                      <div className="relative w-8 h-8 flex items-center justify-center">
                        <img
                          src={getItemDataUrl(slot.id)}
                          alt=""
                          className="w-7 h-7 object-contain pixelated pointer-events-none"
                        />
                        {slot.count > 1 && (
                          <span className="absolute bottom-0 right-0 font-minecraft text-[10px] font-bold text-white drop-shadow">
                            {slot.count}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Creative Item Picker */}
        {activeTab === 'creative' && (
          <div className="flex flex-col gap-3">
            <input
              type="text"
              placeholder="Search blocks & items..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full px-3 py-1.5 bg-[#8b8b8b] border-2 border-[#555] rounded font-minecraft text-xs text-white placeholder-gray-300 focus:outline-none focus:ring-1 focus:ring-white"
            />

            <div className="h-64 overflow-y-auto p-2 bg-[#8b8b8b] border-2 border-[#555] rounded grid grid-cols-8 gap-1.5 content-start">
              {filteredCreativeItems.map((id) => {
                const def = ITEMS[id];
                return (
                  <button
                    key={id}
                    onClick={() => handleCreativeItemClick(id)}
                    title={def?.name || id}
                    className="w-11 h-11 mc-slot flex items-center justify-center cursor-pointer hover:scale-105 transition-transform"
                  >
                    <img
                      src={getItemDataUrl(id)}
                      alt={def?.name}
                      className="w-8 h-8 object-contain pixelated pointer-events-none"
                    />
                  </button>
                );
              })}
            </div>

            <p className="font-minecraft text-[10px] text-gray-700 text-center">
              Click any block to place 64x into your hotbar or inventory!
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
