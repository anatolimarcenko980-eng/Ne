/**
 * 3x3 Crafting Table Modal with full recipe matcher and Quick Recipe Book.
 */

import React, { useState } from 'react';
import { ItemStack } from '../types/game';
import { CRAFTING_RECIPES, findMatchingRecipe } from '../engine/crafting';
import { ITEMS } from '../engine/items';
import { sound } from '../engine/sound';
import { getItemDataUrl } from '../engine/textures';

interface CraftingTableModalProps {
  isOpen: boolean;
  onClose: () => void;
  hotbar: (ItemStack | null)[];
  setHotbar: React.Dispatch<React.SetStateAction<(ItemStack | null)[]>>;
  inventory: (ItemStack | null)[];
  setInventory: React.Dispatch<React.SetStateAction<(ItemStack | null)[]>>;
}

export const CraftingTableModal: React.FC<CraftingTableModalProps> = ({
  isOpen,
  onClose,
  hotbar,
  setHotbar,
  inventory,
  setInventory,
}) => {
  const [craftGrid, setCraftGrid] = useState<(ItemStack | null)[][]>([
    [null, null, null],
    [null, null, null],
    [null, null, null],
  ]);
  const [heldItem, setHeldItem] = useState<ItemStack | null>(null);

  if (!isOpen) return null;

  const craftResult = findMatchingRecipe(craftGrid);

  const handleSlotClick = (
    currentStack: ItemStack | null,
    setStack: (val: ItemStack | null) => void
  ) => {
    sound.playClick();
    if (!heldItem) {
      if (currentStack) {
        setHeldItem(currentStack);
        setStack(null);
      }
    } else {
      if (!currentStack) {
        setStack(heldItem);
        setHeldItem(null);
      } else if (currentStack.id === heldItem.id) {
        const max = ITEMS[heldItem.id]?.maxStack || 64;
        const space = max - currentStack.count;
        if (space > 0) {
          const move = Math.min(space, heldItem.count);
          setStack({ id: currentStack.id, count: currentStack.count + move });
          if (heldItem.count - move <= 0) {
            setHeldItem(null);
          } else {
            setHeldItem({ id: heldItem.id, count: heldItem.count - move });
          }
        } else {
          setStack(heldItem);
          setHeldItem(currentStack);
        }
      } else {
        setStack(heldItem);
        setHeldItem(currentStack);
      }
    }
  };

  const handleCraftResultClick = () => {
    if (!craftResult) return;
    sound.playPop();

    if (!heldItem) {
      setHeldItem({ ...craftResult });
    } else if (heldItem.id === craftResult.id) {
      const max = ITEMS[heldItem.id]?.maxStack || 64;
      if (heldItem.count + craftResult.count <= max) {
        setHeldItem({ id: heldItem.id, count: heldItem.count + craftResult.count });
      } else {
        return;
      }
    } else {
      return;
    }

    // Decrement 1 from each populated crafting grid slot
    setCraftGrid((prev) =>
      prev.map((row) =>
        row.map((slot) => {
          if (!slot) return null;
          if (slot.count <= 1) return null;
          return { ...slot, count: slot.count - 1 };
        })
      )
    );
  };

  // Quick recipe filler from recipe book
  const fillRecipe = (recipeIdx: number) => {
    sound.playClick();
    const recipe = CRAFTING_RECIPES[recipeIdx];
    if (!recipe) return;

    // Check if player has required items
    // Clear grid and populate pattern
    const newGrid: (ItemStack | null)[][] = [
      [null, null, null],
      [null, null, null],
      [null, null, null],
    ];

    for (let r = 0; r < recipe.pattern.length; r++) {
      for (let c = 0; c < recipe.pattern[r].length; c++) {
        const itemType = recipe.pattern[r][c];
        if (itemType) {
          newGrid[r][c] = { id: itemType, count: 1 };
        }
      }
    }

    setCraftGrid(newGrid);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-xs select-none p-4"
      onClick={() => {
        if (heldItem) {
          const idx = inventory.findIndex((s) => s === null);
          if (idx !== -1) {
            const next = [...inventory];
            next[idx] = heldItem;
            setInventory(next);
            setHeldItem(null);
          }
        }
      }}
    >
      {/* Floating held item cursor */}
      {heldItem && (
        <div
          className="fixed pointer-events-none z-50 -translate-x-1/2 -translate-y-1/2"
          id="held-craft-item"
        >
          <div className="relative w-10 h-10 flex items-center justify-center">
            <img
              src={getItemDataUrl(heldItem.id)}
              alt=""
              className="w-8 h-8 object-contain pixelated drop-shadow-md"
            />
            {heldItem.count > 1 && (
              <span className="absolute bottom-0 right-0 font-minecraft text-xs font-bold text-white drop-shadow">
                {heldItem.count}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Main Table Panel */}
      <div
        className="mc-panel w-full max-w-2xl p-5 rounded-lg flex flex-col gap-4 text-[#333333] shadow-2xl relative"
        onClick={(e) => e.stopPropagation()}
        onMouseMove={(e) => {
          const el = document.getElementById('held-craft-item');
          if (el) {
            el.style.left = `${e.clientX}px`;
            el.style.top = `${e.clientY}px`;
          }
        }}
      >
        {/* Header */}
        <div className="flex justify-between items-center border-b-2 border-[#888888] pb-2">
          <span className="font-minecraft text-sm font-bold text-[#222]">Crafting Table (3x3)</span>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="mc-btn px-2 py-0.5 font-minecraft text-sm"
          >
            ✕
          </button>
        </div>

        {/* 3x3 Grid & Recipe Sidebar */}
        <div className="flex gap-4">
          {/* Quick Recipe Book Bookmarks */}
          <div className="w-48 bg-[#b0b0b0] p-2 rounded border-2 border-[#888] flex flex-col gap-1">
            <span className="font-minecraft text-[10px] font-bold text-[#333] mb-1">Recipe Book</span>
            <div className="overflow-y-auto max-h-44 flex flex-col gap-1 pr-1">
              {CRAFTING_RECIPES.map((recipe, idx) => {
                const def = ITEMS[recipe.result.id];
                return (
                  <button
                    key={idx}
                    onClick={() => fillRecipe(idx)}
                    className="flex items-center gap-2 p-1 bg-[#8b8b8b] hover:bg-[#a0a0a0] border border-[#555] rounded text-left transition-colors"
                  >
                    <img
                      src={getItemDataUrl(recipe.result.id)}
                      alt=""
                      className="w-5 h-5 object-contain pixelated"
                    />
                    <span className="font-minecraft text-[10px] text-white truncate drop-shadow">
                      {def?.name || recipe.result.id}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Crafting Grid & Result Output */}
          <div className="flex-1 flex items-center justify-center gap-6 bg-[#b0b0b0] p-4 rounded border-2 border-[#888]">
            <div className="grid grid-cols-3 gap-1 p-1 bg-[#8b8b8b] border border-[#555] rounded">
              {[0, 1, 2].map((r) =>
                [0, 1, 2].map((c) => (
                  <div
                    key={`${r}-${c}`}
                    onClick={() =>
                      handleSlotClick(craftGrid[r][c], (newStack) => {
                        const next = craftGrid.map((row) => [...row]);
                        next[r][c] = newStack;
                        setCraftGrid(next);
                      })
                    }
                    className="w-10 h-10 mc-slot flex items-center justify-center cursor-pointer"
                  >
                    {craftGrid[r][c] && (
                      <div className="relative w-8 h-8 flex items-center justify-center">
                        <img
                          src={getItemDataUrl(craftGrid[r][c]!.id)}
                          alt=""
                          className="w-7 h-7 object-contain pixelated pointer-events-none"
                        />
                        {craftGrid[r][c]!.count > 1 && (
                          <span className="absolute bottom-0 right-0 font-minecraft text-[10px] font-bold text-white drop-shadow">
                            {craftGrid[r][c]!.count}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>

            <div className="text-2xl font-bold font-minecraft text-[#444]">➔</div>

            {/* Output */}
            <div
              onClick={handleCraftResultClick}
              className={`w-14 h-14 mc-slot flex items-center justify-center border-2 border-amber-600 cursor-pointer ${
                craftResult ? 'hover:scale-105 ring-2 ring-yellow-400' : ''
              }`}
            >
              {craftResult && (
                <div className="relative w-11 h-11 flex items-center justify-center animate-pulse">
                  <img
                    src={getItemDataUrl(craftResult.id)}
                    alt=""
                    className="w-10 h-10 object-contain pixelated pointer-events-none drop-shadow"
                  />
                  {craftResult.count > 1 && (
                    <span className="absolute bottom-0 right-0 font-minecraft text-xs font-bold text-white drop-shadow">
                      {craftResult.count}
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* 27 Inventory Slots */}
        <div>
          <span className="font-minecraft text-[11px] font-bold text-[#333] mb-1 block">Inventory</span>
          <div className="grid grid-cols-9 gap-1 p-1.5 bg-[#8b8b8b] border-2 border-[#555] rounded">
            {inventory.map((slot, index) => (
              <div
                key={index}
                onClick={() =>
                  handleSlotClick(slot, (newStack) => {
                    const next = [...inventory];
                    next[index] = newStack;
                    setInventory(next);
                  })
                }
                className="w-10 h-10 mc-slot flex items-center justify-center cursor-pointer hover:brightness-110"
              >
                {slot && (
                  <div className="relative w-8 h-8 flex items-center justify-center">
                    <img
                      src={getItemDataUrl(slot.id)}
                      alt=""
                      className="w-7 h-7 object-contain pixelated pointer-events-none"
                    />
                    {slot.count > 1 && (
                      <span className="absolute bottom-0 right-0 font-minecraft text-[10px] font-bold text-white drop-shadow">
                        {slot.count}
                      </span>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* 9 Hotbar Slots */}
        <div>
          <span className="font-minecraft text-[11px] font-bold text-[#333] mb-1 block">Hotbar</span>
          <div className="grid grid-cols-9 gap-1 p-1.5 bg-[#8b8b8b] border-2 border-[#555] rounded">
            {hotbar.map((slot, index) => (
              <div
                key={index}
                onClick={() =>
                  handleSlotClick(slot, (newStack) => {
                    const next = [...hotbar];
                    next[index] = newStack;
                    setHotbar(next);
                  })
                }
                className="w-10 h-10 mc-slot flex items-center justify-center cursor-pointer hover:brightness-110"
              >
                {slot && (
                  <div className="relative w-8 h-8 flex items-center justify-center">
                    <img
                      src={getItemDataUrl(slot.id)}
                      alt=""
                      className="w-7 h-7 object-contain pixelated pointer-events-none"
                    />
                    {slot.count > 1 && (
                      <span className="absolute bottom-0 right-0 font-minecraft text-[10px] font-bold text-white drop-shadow">
                        {slot.count}
                      </span>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
