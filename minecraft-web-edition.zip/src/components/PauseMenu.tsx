/**
 * Pause Menu with World Settings, Game Mode toggle, Time of Day controls,
 * Save/Load world state, and Keybindings cheat sheet.
 */

import React, { useRef } from 'react';
import { CameraPerspective, GameMode, WorldSettings } from '../types/game';
import { sound } from '../engine/sound';

interface PauseMenuProps {
  isOpen: boolean;
  onResume: () => void;
  gameMode: GameMode;
  setGameMode: (mode: GameMode) => void;
  settings: WorldSettings;
  setSettings: React.Dispatch<React.SetStateAction<WorldSettings>>;
  setTimeOfDay: (t: number) => void;
  onSaveWorld: () => void;
  onExportWorld: () => void;
  onImportWorld: (json: string) => void;
  onResetWorld: () => void;
  cameraMode: CameraPerspective;
  onCycleCamera: () => void;
  cameraDistance: number;
  onChangeCameraDistance: (d: number) => void;
}

export const PauseMenu: React.FC<PauseMenuProps> = ({
  isOpen,
  onResume,
  gameMode,
  setGameMode,
  settings,
  setSettings,
  setTimeOfDay,
  onSaveWorld,
  onExportWorld,
  onImportWorld,
  onResetWorld,
  cameraMode,
  onCycleCamera,
  cameraDistance,
  onChangeCameraDistance,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        if (text) {
          onImportWorld(text);
          sound.playLevelUp();
          onResume();
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs select-none p-4">
      <div className="mc-panel w-full max-w-lg p-6 rounded-lg flex flex-col gap-4 text-center shadow-2xl relative">
        <h2 className="font-minecraft text-xl font-bold text-[#222] tracking-wider">GAME PAUSED</h2>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5">
          <button
            onClick={() => {
              sound.playClick();
              onResume();
            }}
            className="mc-btn py-2 px-4 font-minecraft text-sm font-bold"
          >
            Back to Game
          </button>

          {/* Game Mode & Debug Toggle */}
          <div className="flex gap-2">
            <button
              onClick={() => {
                sound.playClick();
                setGameMode(gameMode === 'survival' ? 'creative' : 'survival');
              }}
              className="mc-btn flex-1 py-1.5 px-3 font-minecraft text-xs font-bold"
            >
              Game Mode:{' '}
              <span className={gameMode === 'creative' ? 'text-amber-300' : 'text-emerald-300'}>
                {gameMode.toUpperCase()}
              </span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                setSettings((s) => ({ ...s, showDebug: !s.showDebug }));
              }}
              className="mc-btn flex-1 py-1.5 px-3 font-minecraft text-xs font-bold"
            >
              Debug (F3): {settings.showDebug ? 'ON' : 'OFF'}
            </button>
          </div>

          {/* Camera Perspective & Distance Settings */}
          <div className="bg-[#a5a5a5] p-2 rounded border border-[#888] flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs font-minecraft">
              <span className="text-[#222] font-bold">Camera View:</span>
              <button
                onClick={() => {
                  sound.playClick();
                  onCycleCamera();
                }}
                className="mc-btn py-1 px-3 font-minecraft text-xs text-yellow-300"
              >
                {cameraMode === 'first_person'
                  ? '📷 1st Person'
                  : cameraMode === 'third_person_back'
                  ? '📷 3rd Person (Back)'
                  : '📷 3rd Person (Front)'}
              </button>
            </div>

            {cameraMode !== 'first_person' && (
              <div className="flex items-center justify-between text-xs font-minecraft">
                <span className="text-[#222]">Cam Distance: {cameraDistance.toFixed(1)}m</span>
                <input
                  type="range"
                  min="1.5"
                  max="7.0"
                  step="0.5"
                  value={cameraDistance}
                  onChange={(e) => onChangeCameraDistance(parseFloat(e.target.value))}
                  className="w-36 accent-emerald-500 cursor-pointer"
                />
              </div>
            )}
          </div>

          {/* Time of Day Presets */}
          <div className="bg-[#a5a5a5] p-2 rounded border border-[#888] flex flex-col gap-1.5">
            <span className="font-minecraft text-[11px] font-bold text-[#222]">Time of Day</span>
            <div className="grid grid-cols-4 gap-1.5">
              <button
                onClick={() => {
                  sound.playClick();
                  setTimeOfDay(0.0);
                }}
                className="mc-btn py-1 font-minecraft text-[10px]"
              >
                🌅 Dawn
              </button>
              <button
                onClick={() => {
                  sound.playClick();
                  setTimeOfDay(0.25);
                }}
                className="mc-btn py-1 font-minecraft text-[10px]"
              >
                ☀️ Noon
              </button>
              <button
                onClick={() => {
                  sound.playClick();
                  setTimeOfDay(0.5);
                }}
                className="mc-btn py-1 font-minecraft text-[10px]"
              >
                🌇 Sunset
              </button>
              <button
                onClick={() => {
                  sound.playClick();
                  setTimeOfDay(0.75);
                }}
                className="mc-btn py-1 font-minecraft text-[10px]"
              >
                🌙 Midnight
              </button>
            </div>
          </div>

          {/* Sound & FOV Sliders */}
          <div className="bg-[#a5a5a5] p-2 rounded border border-[#888] flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs font-minecraft">
              <span className="text-[#222]">Volume: {Math.round(settings.soundVolume * 100)}%</span>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={settings.soundVolume}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  setSettings((s) => ({ ...s, soundVolume: val }));
                  sound.volume = val;
                }}
                className="w-36 accent-emerald-500 cursor-pointer"
              />
            </div>
            <div className="flex items-center justify-between text-xs font-minecraft">
              <span className="text-[#222]">FOV: {settings.fov}°</span>
              <input
                type="range"
                min="60"
                max="100"
                step="5"
                value={settings.fov}
                onChange={(e) => {
                  const val = parseInt(e.target.value);
                  setSettings((s) => ({ ...s, fov: val }));
                }}
                className="w-36 accent-emerald-500 cursor-pointer"
              />
            </div>
          </div>

          {/* World Save / Load / Reset */}
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => {
                sound.playPop();
                onSaveWorld();
              }}
              className="mc-btn py-1.5 font-minecraft text-[11px]"
            >
              💾 Save World
            </button>
            <button
              onClick={() => {
                sound.playPop();
                onExportWorld();
              }}
              className="mc-btn py-1.5 font-minecraft text-[11px]"
            >
              📤 Export File
            </button>
            <button
              onClick={() => {
                fileInputRef.current?.click();
              }}
              className="mc-btn py-1.5 font-minecraft text-[11px]"
            >
              📥 Import File
            </button>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".json"
              className="hidden"
            />
          </div>

          <button
            onClick={() => {
              if (window.confirm('Reset world with a new random seed? Your edits will be replaced.')) {
                sound.playExplosion();
                onResetWorld();
                onResume();
              }
            }}
            className="mc-btn py-1.5 font-minecraft text-xs text-rose-300"
          >
            🎲 New Random World Seed
          </button>
        </div>

        {/* Controls Guide Collapsible */}
        <div className="mt-1 pt-2 border-t border-[#888] text-left">
          <span className="font-minecraft text-[11px] font-bold text-[#222] mb-1 block">Keybindings</span>
          <div className="grid grid-cols-2 gap-x-2 gap-y-0.5 font-minecraft text-[10px] text-[#444]">
            <div>• <strong className="text-black">WASD</strong>: Move</div>
            <div>• <strong className="text-black">Arrows</strong>: Move / Look Camera</div>
            <div>• <strong className="text-black">F5</strong>: Toggle Camera (1st/3rd)</div>
            <div>• <strong className="text-black">C</strong>: Zoom Camera</div>
            <div>• <strong className="text-black">Space</strong>: Jump / Fly up</div>
            <div>• <strong className="text-black">Shift</strong>: Sneak / Fly down</div>
            <div>• <strong className="text-black">Ctrl</strong>: Sprint</div>
            <div>• <strong className="text-black">Left Click</strong>: Mine / Attack</div>
            <div>• <strong className="text-black">Right Click</strong>: Place / Interact</div>
            <div>• <strong className="text-black">1-9</strong>: Select Hotbar</div>
            <div>• <strong className="text-black">E</strong>: Inventory / Catalog</div>
            <div>• <strong className="text-black">T or /</strong>: Chat & Commands</div>
            <div>• <strong className="text-black">F3</strong>: Debug Stats</div>
            <div>• <strong className="text-black">Double Space</strong>: Fly Toggle</div>
          </div>
        </div>
      </div>
    </div>
  );
};
