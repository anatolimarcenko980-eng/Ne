/**
 * Furnace Smelting Modal with real smelting ticks, fuel burning, and animated flame.
 */

import React, { useEffect, useState } from 'react';
import { ItemStack } from '../types/game';
import { SMELTING_RECIPES } from '../engine/crafting';
import { ITEMS } from '../engine/items';
import { sound } from '../engine/sound';
import { getItemDataUrl } from '../engine/textures';

interface FurnaceModalProps {
  isOpen: boolean;
  onClose: () => void;
  hotbar: (ItemStack | null)[];
  setHotbar: React.Dispatch<React.SetStateAction<(ItemStack | null)[]>>;
  inventory: (ItemStack | null)[];
  setInventory: React.Dispatch<React.SetStateAction<(ItemStack | null)[]>>;
}

export const FurnaceModal: React.FC<FurnaceModalProps> = ({
  isOpen,
  onClose,
  hotbar,
  setHotbar,
  inventory,
  setInventory,
}) => {
  const [inputSlot, setInputSlot] = useState<ItemStack | null>({ id: 'raw_porkchop', count: 4 });
  const [fuelSlot, setFuelSlot] = useState<ItemStack | null>({ id: 'coal', count: 8 });
  const [outputSlot, setOutputSlot] = useState<ItemStack | null>(null);
  const [heldItem, setHeldItem] = useState<ItemStack | null>(null);

  const [cookProgress, setCookProgress] = useState<number>(0); // 0 to 100
  const [fuelBurnTime, setFuelBurnTime] = useState<number>(100); // 0 to 100

  // Smelting loop tick
  useEffect(() => {
    if (!isOpen) return;

    const interval = setInterval(() => {
      // Find matching recipe for input
      if (!inputSlot) {
        setCookProgress(0);
        return;
      }

      const recipe = SMELTING_RECIPES.find((r) => r.input === inputSlot.id);
      if (!recipe) {
        setCookProgress(0);
        return;
      }

      // Check if output slot is compatible
      if (outputSlot && outputSlot.id !== recipe.output) return;
      if (outputSlot && outputSlot.count >= 64) return;

      // Fuel consumption
      if (fuelBurnTime <= 0) {
        if (fuelSlot && fuelSlot.count > 0) {
          setFuelSlot({ ...fuelSlot, count: fuelSlot.count - 1 });
          setFuelBurnTime(100);
        } else {
          setCookProgress(0);
          return;
        }
      } else {
        setFuelBurnTime((prev) => Math.max(0, prev - 4));
      }

      // Progress cooking
      setCookProgress((prev) => {
        if (prev >= 95) {
          // Finished 1 item!
          sound.playPop();

          // Decrement input
          if (inputSlot.count <= 1) {
            setInputSlot(null);
          } else {
            setInputSlot({ ...inputSlot, count: inputSlot.count - 1 });
          }

          // Add to output
          setOutputSlot((old) => ({
            id: recipe.output,
            count: (old?.count || 0) + 1,
          }));

          return 0;
        }
        return prev + 10;
      });
    }, 400);

    return () => clearInterval(interval);
  }, [isOpen, inputSlot, fuelSlot, outputSlot, fuelBurnTime]);

  if (!isOpen) return null;

  const handleSlotClick = (
    currentStack: ItemStack | null,
    setStack: (val: ItemStack | null) => void
  ) => {
    sound.playClick();
    if (!heldItem) {
      if (currentStack) {
        setHeldItem(currentStack);
        setStack(null);
      }
    } else {
      if (!currentStack) {
        setStack(heldItem);
        setHeldItem(null);
      } else if (currentStack.id === heldItem.id) {
        const max = ITEMS[heldItem.id]?.maxStack || 64;
        const space = max - currentStack.count;
        if (space > 0) {
          const move = Math.min(space, heldItem.count);
          setStack({ id: currentStack.id, count: currentStack.count + move });
          if (heldItem.count - move <= 0) {
            setHeldItem(null);
          } else {
            setHeldItem({ id: heldItem.id, count: heldItem.count - move });
          }
        } else {
          setStack(heldItem);
          setHeldItem(currentStack);
        }
      } else {
        setStack(heldItem);
        setHeldItem(currentStack);
      }
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-xs select-none p-4"
      onClick={() => {
        if (heldItem) {
          const idx = inventory.findIndex((s) => s === null);
          if (idx !== -1) {
            const next = [...inventory];
            next[idx] = heldItem;
            setInventory(next);
            setHeldItem(null);
          }
        }
      }}
    >
      {/* Floating held item */}
      {heldItem && (
        <div className="fixed pointer-events-none z-50 -translate-x-1/2 -translate-y-1/2" id="held-furnace-item">
          <div className="relative w-10 h-10 flex items-center justify-center">
            <img src={getItemDataUrl(heldItem.id)} alt="" className="w-8 h-8 object-contain pixelated drop-shadow" />
            {heldItem.count > 1 && (
              <span className="absolute bottom-0 right-0 font-minecraft text-xs font-bold text-white drop-shadow">
                {heldItem.count}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Main Panel */}
      <div
        className="mc-panel w-full max-w-xl p-5 rounded-lg flex flex-col gap-4 text-[#333333] shadow-2xl relative"
        onClick={(e) => e.stopPropagation()}
        onMouseMove={(e) => {
          const el = document.getElementById('held-furnace-item');
          if (el) {
            el.style.left = `${e.clientX}px`;
            el.style.top = `${e.clientY}px`;
          }
        }}
      >
        {/* Header */}
        <div className="flex justify-between items-center border-b-2 border-[#888888] pb-2">
          <span className="font-minecraft text-sm font-bold text-[#222]">Furnace</span>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="mc-btn px-2 py-0.5 font-minecraft text-sm"
          >
            ✕
          </button>
        </div>

        {/* Smelting Core */}
        <div className="flex items-center justify-center gap-8 bg-[#b0b0b0] p-4 rounded border-2 border-[#888]">
          {/* Input & Fuel Column */}
          <div className="flex flex-col items-center gap-2">
            {/* Input Slot */}
            <div
              onClick={() => handleSlotClick(inputSlot, setInputSlot)}
              className="w-12 h-12 mc-slot flex items-center justify-center cursor-pointer"
            >
              {inputSlot && (
                <div className="relative w-9 h-9 flex items-center justify-center">
                  <img src={getItemDataUrl(inputSlot.id)} alt="" className="w-8 h-8 object-contain pixelated" />
                  {inputSlot.count > 1 && (
                    <span className="absolute bottom-0 right-0 font-minecraft text-[10px] font-bold text-white drop-shadow">
                      {inputSlot.count}
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Fire flame indicator */}
            <div className="relative w-4 h-4 flex items-center justify-center text-lg">
              {fuelBurnTime > 0 ? (
                <span className="animate-bounce text-orange-500 drop-shadow">🔥</span>
              ) : (
                <span className="text-gray-500 opacity-40">🔥</span>
              )}
            </div>

            {/* Fuel Slot */}
            <div
              onClick={() => handleSlotClick(fuelSlot, setFuelSlot)}
              className="w-12 h-12 mc-slot flex items-center justify-center cursor-pointer"
            >
              {fuelSlot && (
                <div className="relative w-9 h-9 flex items-center justify-center">
                  <img src={getItemDataUrl(fuelSlot.id)} alt="" className="w-8 h-8 object-contain pixelated" />
                  {fuelSlot.count > 1 && (
                    <span className="absolute bottom-0 right-0 font-minecraft text-[10px] font-bold text-white drop-shadow">
                      {fuelSlot.count}
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Progress Arrow */}
          <div className="flex flex-col items-center">
            <div className="relative w-16 h-4 bg-[#777] rounded border border-[#555] overflow-hidden">
              <div
                className="h-full bg-linear-to-r from-amber-500 to-yellow-400 transition-all duration-300"
                style={{ width: `${cookProgress}%` }}
              />
            </div>
            <span className="font-minecraft text-[9px] text-[#444] mt-1">Cooking</span>
          </div>

          {/* Output Slot */}
          <div
            onClick={() => handleSlotClick(outputSlot, setOutputSlot)}
            className="w-14 h-14 mc-slot flex items-center justify-center border-2 border-amber-600 cursor-pointer"
          >
            {outputSlot && (
              <div className="relative w-11 h-11 flex items-center justify-center animate-pulse">
                <img src={getItemDataUrl(outputSlot.id)} alt="" className="w-10 h-10 object-contain pixelated" />
                {outputSlot.count > 1 && (
                  <span className="absolute bottom-0 right-0 font-minecraft text-xs font-bold text-white drop-shadow">
                    {outputSlot.count}
                  </span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* 27 Inventory Slots */}
        <div>
          <span className="font-minecraft text-[11px] font-bold text-[#333] mb-1 block">Inventory</span>
          <div className="grid grid-cols-9 gap-1 p-1.5 bg-[#8b8b8b] border-2 border-[#555] rounded">
            {inventory.map((slot, index) => (
              <div
                key={index}
                onClick={() =>
                  handleSlotClick(slot, (newStack) => {
                    const next = [...inventory];
                    next[index] = newStack;
                    setInventory(next);
                  })
                }
                className="w-10 h-10 mc-slot flex items-center justify-center cursor-pointer hover:brightness-110"
              >
                {slot && (
                  <div className="relative w-8 h-8 flex items-center justify-center">
                    <img src={getItemDataUrl(slot.id)} alt="" className="w-7 h-7 object-contain pixelated pointer-events-none" />
                    {slot.count > 1 && (
                      <span className="absolute bottom-0 right-0 font-minecraft text-[10px] font-bold text-white drop-shadow">
                        {slot.count}
                      </span>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* 9 Hotbar Slots */}
        <div>
          <span className="font-minecraft text-[11px] font-bold text-[#333] mb-1 block">Hotbar</span>
          <div className="grid grid-cols-9 gap-1 p-1.5 bg-[#8b8b8b] border-2 border-[#555] rounded">
            {hotbar.map((slot, index) => (
              <div
                key={index}
                onClick={() =>
                  handleSlotClick(slot, (newStack) => {
                    const next = [...hotbar];
                    next[index] = newStack;
                    setHotbar(next);
                  })
                }
                className="w-10 h-10 mc-slot flex items-center justify-center cursor-pointer hover:brightness-110"
              >
                {slot && (
                  <div className="relative w-8 h-8 flex items-center justify-center">
                    <img src={getItemDataUrl(slot.id)} alt="" className="w-7 h-7 object-contain pixelated pointer-events-none" />
                    {slot.count > 1 && (
                      <span className="absolute bottom-0 right-0 font-minecraft text-[10px] font-bold text-white drop-shadow">
                        {slot.count}
                      </span>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
