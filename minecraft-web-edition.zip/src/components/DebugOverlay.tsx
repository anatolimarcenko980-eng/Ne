/**
 * F3 Debug Screen overlay inspired by authentic Minecraft debug HUD.
 */

import React from 'react';
import * as THREE from 'three';

interface DebugOverlayProps {
  visible: boolean;
  fps: number;
  playerPos: THREE.Vector3;
  yaw: number;
  pitch: number;
  targetBlock: {
    blockPos: THREE.Vector3;
    blockType: string;
  } | null;
  timeOfDay: number;
  activeChunks: number;
  mobsCount: number;
  cameraMode?: string;
}

export const DebugOverlay: React.FC<DebugOverlayProps> = ({
  visible,
  fps,
  playerPos,
  yaw,
  pitch,
  targetBlock,
  timeOfDay,
  activeChunks,
  mobsCount,
  cameraMode,
}) => {
  if (!visible) return null;

  // Calculate cardinal direction
  const deg = (((yaw * 180) / Math.PI) % 360 + 360) % 360;
  let facing = 'south (Towards positive Z)';
  if (deg >= 45 && deg < 135) facing = 'west (Towards negative X)';
  else if (deg >= 135 && deg < 225) facing = 'north (Towards negative Z)';
  else if (deg >= 225 && deg < 315) facing = 'east (Towards positive X)';

  const timeHours = Math.floor(timeOfDay * 24);
  const timeMins = Math.floor((timeOfDay * 24 - timeHours) * 60);
  const formattedTime = `${timeHours.toString().padStart(2, '0')}:${timeMins.toString().padStart(2, '0')}`;

  return (
    <div className="absolute inset-0 pointer-events-none p-3 flex justify-between font-vt323 text-white text-base select-none z-40">
      {/* Left Column */}
      <div className="bg-black/60 p-2 rounded max-w-sm flex flex-col gap-0.5 border border-white/20 shadow">
        <div className="text-yellow-400 font-bold">Minecraft Web Edition (WebGL 3D)</div>
        <div>{fps} fps (T: 60 max)</div>
        <div className="mt-1">
          XYZ: {playerPos.x.toFixed(3)} / {playerPos.y.toFixed(3)} / {playerPos.z.toFixed(3)}
        </div>
        <div>
          Block: {Math.floor(playerPos.x)} {Math.floor(playerPos.y)} {Math.floor(playerPos.z)}
        </div>
        <div>
          Chunk: {Math.floor(playerPos.x / 16)} {Math.floor(playerPos.z / 16)} ({activeChunks} loaded)
        </div>
        <div>Facing: {facing}</div>
        <div>
          Rotation: ({((yaw * 180) / Math.PI).toFixed(1)} / {((pitch * 180) / Math.PI).toFixed(1)})
        </div>
        <div className="text-emerald-400">Biome: Plains / Green Hills</div>
        <div>Light: Day / Sun Level 15</div>
        <div>Local Time: {formattedTime} (Day cycle)</div>
        <div>Active Mobs: {mobsCount}</div>
        <div className="text-cyan-300">Camera: {cameraMode || '1st Person'} (F5)</div>
      </div>

      {/* Right Column */}
      {targetBlock && (
        <div className="bg-black/60 p-2 rounded max-w-xs flex flex-col gap-0.5 border border-white/20 self-start shadow">
          <div className="text-cyan-400 font-bold">Targeted Block</div>
          <div>Type: {targetBlock.blockType}</div>
          <div>
            Pos: {targetBlock.blockPos.x}, {targetBlock.blockPos.y}, {targetBlock.blockPos.z}
          </div>
        </div>
      )}
    </div>
  );
};
