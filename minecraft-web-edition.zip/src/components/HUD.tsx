/**
 * In-game HUD: Crosshair, Hearts, Hunger, XP Bar, Hotbar with item icons & counts.
 */

import React, { useEffect, useState } from 'react';
import { CameraPerspective, GameMode, ItemStack } from '../types/game';
import { ITEMS } from '../engine/items';
import { getItemDataUrl } from '../engine/textures';

interface HUDProps {
  health: number;
  maxHealth: number;
  hunger: number;
  maxHunger: number;
  xpLevel: number;
  xpProgress: number;
  hotbar: (ItemStack | null)[];
  selectedSlot: number;
  onSelectSlot: (slot: number) => void;
  gameMode: GameMode;
  isSwimming: boolean;
  activeItemName?: string;
  cameraMode: CameraPerspective;
  onCycleCamera: () => void;
  isZooming: boolean;
  onToggleZoom: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  health,
  maxHealth,
  hunger,
  maxHunger,
  xpLevel,
  xpProgress,
  hotbar,
  selectedSlot,
  onSelectSlot,
  gameMode,
  isSwimming,
  activeItemName,
  cameraMode,
  onCycleCamera,
  isZooming,
  onToggleZoom,
}) => {
  const [tooltip, setTooltip] = useState<string | null>(null);

  // Show tooltip briefly when active slot changes
  useEffect(() => {
    const item = hotbar[selectedSlot];
    if (item) {
      const def = ITEMS[item.id];
      setTooltip(def?.name || item.id);
      const timer = setTimeout(() => setTooltip(null), 2200);
      return () => clearTimeout(timer);
    } else {
      setTooltip(null);
    }
  }, [selectedSlot, hotbar]);

  // Render 10 hearts
  const renderHearts = () => {
    const hearts = [];
    const totalHearts = 10;
    const currentHearts = health / 2;

    for (let i = 0; i < totalHearts; i++) {
      const isFull = currentHearts >= i + 1;
      const isHalf = !isFull && currentHearts >= i + 0.5;

      hearts.push(
        <div key={i} className="relative w-4 h-4 inline-block">
          {/* Heart background */}
          <div className="absolute inset-0 bg-[#3a0b0b] rounded-[1px] border border-black" />
          {/* Filled heart */}
          {isFull && <div className="absolute inset-0 bg-[#e72424] border border-[#a81414]" />}
          {isHalf && <div className="absolute left-0 top-0 bottom-0 w-2 bg-[#e72424] border border-[#a81414]" />}
          {/* Specular shine */}
          {(isFull || isHalf) && <div className="absolute top-0.5 left-0.5 w-1 h-1 bg-white opacity-80" />}
        </div>
      );
    }
    return hearts;
  };

  // Render 10 hunger drumsticks
  const renderHunger = () => {
    const drumsticks = [];
    const total = 10;
    const current = hunger / 2;

    for (let i = 0; i < total; i++) {
      const isFull = current >= i + 1;
      const isHalf = !isFull && current >= i + 0.5;

      drumsticks.push(
        <div key={i} className="relative w-4 h-4 inline-block">
          {/* Bone & meat */}
          <div className="absolute inset-0 bg-[#301c0b] rounded-[1px] border border-black" />
          {isFull && <div className="absolute inset-0 bg-[#c4772d] border border-[#83460e]" />}
          {isHalf && <div className="absolute right-0 top-0 bottom-0 w-2 bg-[#c4772d] border border-[#83460e]" />}
          {(isFull || isHalf) && <div className="absolute top-0.5 right-0.5 w-1 h-1 bg-[#f4a259]" />}
        </div>
      );
    }
    return drumsticks;
  };

  return (
    <div className="absolute inset-0 pointer-events-none select-none overflow-hidden">
      {/* Water underwater vignette overlay */}
      {isSwimming && (
        <div className="absolute inset-0 bg-[#0d3b66] opacity-40 mix-blend-multiply pointer-events-none" />
      )}

      {/* Classic Crosshair (hidden in front selfie mode) */}
      {cameraMode !== 'third_person_front' && (
        <div className="mc-crosshair">
          <svg viewBox="0 0 16 16" className="w-4 h-4 text-white drop-shadow">
            <path d="M7 1h2v5H7zM7 10h2v5H7zM1 7h5v2H1zM10 7h5v2h-5z" fill="currentColor" />
          </svg>
        </div>
      )}

      {/* Top Right Camera & Quick Controls */}
      <div className="absolute top-3 right-3 flex items-center gap-2 pointer-events-auto z-40">
        {/* Camera Perspective Toggle */}
        <button
          onClick={onCycleCamera}
          className="mc-btn px-2.5 py-1.5 flex items-center gap-1.5 font-minecraft text-xs shadow-md"
          title="Toggle camera perspective (F5)"
        >
          <span>📷</span>
          <span>
            {cameraMode === 'first_person'
              ? '1st Person'
              : cameraMode === 'third_person_back'
              ? '3rd Person (Back)'
              : '3rd Person (Front)'}
          </span>
          <span className="text-[10px] text-gray-300 opacity-75 font-vt323">[F5]</span>
        </button>

        {/* Zoom Toggle */}
        <button
          onClick={onToggleZoom}
          className={`mc-btn px-2.5 py-1.5 flex items-center gap-1 font-minecraft text-xs shadow-md ${
            isZooming ? 'text-yellow-300 ring-1 ring-yellow-400' : ''
          }`}
          title="Toggle Zoom (Key C)"
        >
          <span>🔍</span>
          <span>Zoom</span>
          <span className="text-[10px] text-gray-300 opacity-75 font-vt323">[C]</span>
        </button>
      </div>

      {/* Bottom Center UI Container */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 pointer-events-auto">
        {/* Tooltip banner */}
        {tooltip && (
          <div className="px-3 py-1 bg-black/80 text-white font-minecraft text-sm rounded border border-gray-600 shadow-md animate-fade-in">
            {tooltip}
          </div>
        )}

        {/* Survival Status Bars (Health, Hunger, XP) */}
        {gameMode === 'survival' && (
          <div className="w-80 flex flex-col gap-1">
            {/* Health & Hunger row */}
            <div className="flex justify-between items-center px-1">
              {/* Hearts */}
              <div className="flex gap-0.5">{renderHearts()}</div>
              {/* Hunger */}
              <div className="flex gap-0.5 flex-row-reverse">{renderHunger()}</div>
            </div>

            {/* Experience Level & Bar */}
            <div className="relative w-full h-2.5 bg-black/80 rounded border border-black">
              {/* Green Progress */}
              <div
                className="h-full bg-gradient-to-r from-[#6fe236] to-[#a4f944]"
                style={{ width: `${Math.min(100, Math.max(0, xpProgress * 100))}%` }}
              />
              {/* Level Number */}
              {xpLevel > 0 && (
                <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 font-minecraft text-xs font-bold text-[#80ff00] drop-shadow-[0_1.5px_0_#000]">
                  {xpLevel}
                </span>
              )}
            </div>
          </div>
        )}

        {/* 9-Slot Minecraft Hotbar */}
        <div className="flex items-center gap-1 p-1 bg-[#222222]/90 rounded-md border-2 border-[#555555] shadow-2xl">
          {hotbar.map((slot, index) => {
            const isSelected = selectedSlot === index;
            const itemDef = slot ? ITEMS[slot.id] : null;

            return (
              <div
                key={index}
                onClick={() => onSelectSlot(index)}
                className={`relative w-11 h-11 flex items-center justify-center mc-slot cursor-pointer transition-all ${
                  isSelected ? 'mc-slot-selected ring-2 ring-white scale-105 z-10' : ''
                }`}
                title={itemDef ? itemDef.name : `Slot ${index + 1}`}
              >
                {/* Slot index key hint */}
                <span className="absolute top-0.5 left-1 text-[9px] text-gray-300 font-minecraft opacity-60">
                  {index + 1}
                </span>

                {/* Item Icon */}
                {slot && (
                  <img
                    src={getItemDataUrl(slot.id)}
                    alt={itemDef?.name || slot.id}
                    className="w-8 h-8 object-contain pixelated pointer-events-none drop-shadow"
                    style={{ imageRendering: 'pixelated' }}
                  />
                )}

                {/* Stack Count */}
                {slot && slot.count > 1 && (
                  <span className="absolute bottom-0.5 right-1 font-minecraft text-xs font-bold text-white drop-shadow-[0_1.5px_0_#000]">
                    {slot.count}
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
