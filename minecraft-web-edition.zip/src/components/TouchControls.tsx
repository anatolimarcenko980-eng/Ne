/**
 * On-screen Touch Controls for mobile and tablet players.
 */

import React, { useEffect, useState } from 'react';

interface TouchControlsProps {
  onDirectionChange: (dir: { forward: boolean; backward: boolean; left: boolean; right: boolean }) => void;
  onJump: (active: boolean) => void;
  onMine: (active: boolean) => void;
  onPlace: () => void;
  onInventory: () => void;
  onRotateCamera?: (dx: number, dy: number) => void;
  isCreative: boolean;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  onDirectionChange,
  onJump,
  onMine,
  onPlace,
  onInventory,
  onRotateCamera,
  isCreative,
}) => {
  const [isTouchDevice, setIsTouchDevice] = useState(false);
  const [dirState, setDirState] = useState({ forward: false, backward: false, left: false, right: false });
  const touchStartRef = React.useRef<{ x: number; y: number } | null>(null);

  useEffect(() => {
    if ('ontouchstart' in window || navigator.maxTouchPoints > 0) {
      setIsTouchDevice(true);
    }
  }, []);

  if (!isTouchDevice) return null;

  const updateDir = (key: 'forward' | 'backward' | 'left' | 'right', val: boolean) => {
    setDirState((prev) => {
      const next = { ...prev, [key]: val };
      onDirectionChange(next);
      return next;
    });
  };

  return (
    <div className="absolute inset-0 pointer-events-none z-30 select-none">
      {/* Right side touch-to-look drag zone */}
      <div
        className="absolute top-16 right-0 bottom-44 left-1/3 pointer-events-auto"
        onTouchStart={(e) => {
          const t = e.touches[0];
          touchStartRef.current = { x: t.clientX, y: t.clientY };
        }}
        onTouchMove={(e) => {
          if (!touchStartRef.current || !onRotateCamera) return;
          const t = e.touches[0];
          const dx = t.clientX - touchStartRef.current.x;
          const dy = t.clientY - touchStartRef.current.y;
          touchStartRef.current = { x: t.clientX, y: t.clientY };
          onRotateCamera(dx, dy);
        }}
        onTouchEnd={() => {
          touchStartRef.current = null;
        }}
        onTouchCancel={() => {
          touchStartRef.current = null;
        }}
      />

      {/* Left: Virtual D-Pad */}
      <div className="absolute bottom-20 left-4 pointer-events-auto flex flex-col items-center">
        <button
          onTouchStart={() => updateDir('forward', true)}
          onTouchEnd={() => updateDir('forward', false)}
          className="w-14 h-14 bg-black/50 active:bg-white/40 border-2 border-white/40 rounded flex items-center justify-center text-white text-xl"
        >
          ▲
        </button>
        <div className="flex gap-14 my-1">
          <button
            onTouchStart={() => updateDir('left', true)}
            onTouchEnd={() => updateDir('left', false)}
            className="w-14 h-14 bg-black/50 active:bg-white/40 border-2 border-white/40 rounded flex items-center justify-center text-white text-xl"
          >
            ◀
          </button>
          <button
            onTouchStart={() => updateDir('right', true)}
            onTouchEnd={() => updateDir('right', false)}
            className="w-14 h-14 bg-black/50 active:bg-white/40 border-2 border-white/40 rounded flex items-center justify-center text-white text-xl"
          >
            ▶
          </button>
        </div>
        <button
          onTouchStart={() => updateDir('backward', true)}
          onTouchEnd={() => updateDir('backward', false)}
          className="w-14 h-14 bg-black/50 active:bg-white/40 border-2 border-white/40 rounded flex items-center justify-center text-white text-xl"
        >
          ▼
        </button>
      </div>

      {/* Right: Action Buttons */}
      <div className="absolute bottom-20 right-4 pointer-events-auto flex flex-col items-end gap-3">
        {/* Inventory button */}
        <button
          onClick={onInventory}
          className="mc-btn px-4 py-2 font-minecraft text-xs font-bold"
        >
          🎒 Bag
        </button>

        {/* Place & Mine */}
        <div className="flex gap-2">
          <button
            onClick={onPlace}
            className="w-16 h-16 bg-blue-600/70 active:bg-blue-400 border-2 border-white rounded-full flex items-center justify-center font-minecraft text-xs text-white shadow-lg"
          >
            PLACE
          </button>
          <button
            onTouchStart={() => onMine(true)}
            onTouchEnd={() => onMine(false)}
            className="w-16 h-16 bg-rose-600/70 active:bg-rose-400 border-2 border-white rounded-full flex items-center justify-center font-minecraft text-xs text-white shadow-lg"
          >
            MINE
          </button>
        </div>

        {/* Jump Button */}
        <button
          onTouchStart={() => onJump(true)}
          onTouchEnd={() => onJump(false)}
          className="w-16 h-16 bg-emerald-600/70 active:bg-emerald-400 border-2 border-white rounded-full flex items-center justify-center font-minecraft text-xs text-white shadow-lg"
        >
          JUMP
        </button>
      </div>
    </div>
  );
};
