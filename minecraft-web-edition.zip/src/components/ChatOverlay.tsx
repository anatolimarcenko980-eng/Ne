/**
 * Chat and Slash Command Overlay for Minecraft Web Edition.
 */

import React, { useEffect, useRef, useState } from 'react';
import { GameMode, ItemType } from '../types/game';
import { ITEMS } from '../engine/items';
import { sound } from '../engine/sound';

export interface ChatMessage {
  id: string;
  sender?: string;
  text: string;
  color?: string;
}

interface ChatOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  messages: ChatMessage[];
  onSendMessage: (msg: string) => void;
  onExecuteCommand: (cmd: string, args: string[]) => void;
}

export const ChatOverlay: React.FC<ChatOverlayProps> = ({
  isOpen,
  onClose,
  messages,
  onSendMessage,
  onExecuteCommand,
}) => {
  const [input, setInput] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setInput('');
    }
  }, [isOpen]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed) {
      onClose();
      return;
    }

    if (trimmed.startsWith('/')) {
      const parts = trimmed.slice(1).split(/\s+/);
      const cmd = parts[0]?.toLowerCase();
      const args = parts.slice(1);
      onExecuteCommand(cmd, args);
    } else {
      onSendMessage(trimmed);
    }

    setInput('');
    onClose();
  };

  return (
    <div
      className={`absolute bottom-16 left-4 z-40 max-w-lg w-full flex flex-col pointer-events-none transition-opacity duration-200 ${
        isOpen ? 'pointer-events-auto' : 'opacity-90'
      }`}
    >
      {/* Messages List */}
      <div className="flex flex-col gap-1 max-h-48 overflow-y-auto p-2 bg-black/45 rounded font-minecraft text-xs text-white">
        {messages.slice(-15).map((m) => (
          <div key={m.id} className="leading-snug break-words">
            {m.sender && <span className="text-[#ffd700] mr-1">&lt;{m.sender}&gt;</span>}
            <span style={{ color: m.color || '#ffffff' }}>{m.text}</span>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input Box (only shown when chat open) */}
      {isOpen && (
        <form onSubmit={handleSubmit} className="mt-1 flex gap-1">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Escape') {
                e.stopPropagation();
                onClose();
              }
            }}
            placeholder="Press ENTER to send, / for commands..."
            className="flex-1 px-3 py-1.5 bg-black/80 border-2 border-white/40 rounded font-minecraft text-xs text-white placeholder-gray-400 focus:outline-none focus:border-white"
          />
          <button
            type="submit"
            className="mc-btn px-3 py-1 font-minecraft text-xs"
          >
            Send
          </button>
        </form>
      )}
    </div>
  );
};
