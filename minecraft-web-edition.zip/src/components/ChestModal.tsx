/**
 * Chest Storage Modal with 27 chest slots and player inventory transfer.
 */

import React, { useState } from 'react';
import { ItemStack } from '../types/game';
import { ITEMS } from '../engine/items';
import { sound } from '../engine/sound';
import { getItemDataUrl } from '../engine/textures';

interface ChestModalProps {
  isOpen: boolean;
  onClose: () => void;
  chestSlots: (ItemStack | null)[];
  setChestSlots: React.Dispatch<React.SetStateAction<(ItemStack | null)[]>>;
  hotbar: (ItemStack | null)[];
  setHotbar: React.Dispatch<React.SetStateAction<(ItemStack | null)[]>>;
  inventory: (ItemStack | null)[];
  setInventory: React.Dispatch<React.SetStateAction<(ItemStack | null)[]>>;
}

export const ChestModal: React.FC<ChestModalProps> = ({
  isOpen,
  onClose,
  chestSlots,
  setChestSlots,
  hotbar,
  setHotbar,
  inventory,
  setInventory,
}) => {
  const [heldItem, setHeldItem] = useState<ItemStack | null>(null);

  if (!isOpen) return null;

  const handleSlotClick = (
    currentStack: ItemStack | null,
    setStack: (val: ItemStack | null) => void
  ) => {
    sound.playClick();
    if (!heldItem) {
      if (currentStack) {
        setHeldItem(currentStack);
        setStack(null);
      }
    } else {
      if (!currentStack) {
        setStack(heldItem);
        setHeldItem(null);
      } else if (currentStack.id === heldItem.id) {
        const max = ITEMS[heldItem.id]?.maxStack || 64;
        const space = max - currentStack.count;
        if (space > 0) {
          const move = Math.min(space, heldItem.count);
          setStack({ id: currentStack.id, count: currentStack.count + move });
          if (heldItem.count - move <= 0) {
            setHeldItem(null);
          } else {
            setHeldItem({ id: heldItem.id, count: heldItem.count - move });
          }
        } else {
          setStack(heldItem);
          setHeldItem(currentStack);
        }
      } else {
        setStack(heldItem);
        setHeldItem(currentStack);
      }
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-xs select-none p-4"
      onClick={() => {
        if (heldItem) {
          const idx = inventory.findIndex((s) => s === null);
          if (idx !== -1) {
            const next = [...inventory];
            next[idx] = heldItem;
            setInventory(next);
            setHeldItem(null);
          }
        }
      }}
    >
      {/* Floating held item */}
      {heldItem && (
        <div className="fixed pointer-events-none z-50 -translate-x-1/2 -translate-y-1/2" id="held-chest-item">
          <div className="relative w-10 h-10 flex items-center justify-center">
            <img src={getItemDataUrl(heldItem.id)} alt="" className="w-8 h-8 object-contain pixelated drop-shadow" />
            {heldItem.count > 1 && (
              <span className="absolute bottom-0 right-0 font-minecraft text-xs font-bold text-white drop-shadow">
                {heldItem.count}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Main Panel */}
      <div
        className="mc-panel w-full max-w-xl p-5 rounded-lg flex flex-col gap-4 text-[#333333] shadow-2xl relative"
        onClick={(e) => e.stopPropagation()}
        onMouseMove={(e) => {
          const el = document.getElementById('held-chest-item');
          if (el) {
            el.style.left = `${e.clientX}px`;
            el.style.top = `${e.clientY}px`;
          }
        }}
      >
        {/* Header */}
        <div className="flex justify-between items-center border-b-2 border-[#888888] pb-2">
          <span className="font-minecraft text-sm font-bold text-[#222]">Chest (27 Slots)</span>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="mc-btn px-2 py-0.5 font-minecraft text-sm"
          >
            ✕
          </button>
        </div>

        {/* 27 Chest Slots (3 rows of 9) */}
        <div className="bg-[#b0b0b0] p-2 rounded border-2 border-[#888]">
          <span className="font-minecraft text-[11px] font-bold text-[#333] mb-1 block">Chest Storage</span>
          <div className="grid grid-cols-9 gap-1 p-1 bg-[#8b8b8b] border border-[#555] rounded">
            {chestSlots.map((slot, index) => (
              <div
                key={index}
                onClick={() =>
                  handleSlotClick(slot, (newStack) => {
                    const next = [...chestSlots];
                    next[index] = newStack;
                    setChestSlots(next);
                  })
                }
                className="w-10 h-10 mc-slot flex items-center justify-center cursor-pointer hover:brightness-110"
              >
                {slot && (
                  <div className="relative w-8 h-8 flex items-center justify-center">
                    <img src={getItemDataUrl(slot.id)} alt="" className="w-7 h-7 object-contain pixelated pointer-events-none" />
                    {slot.count > 1 && (
                      <span className="absolute bottom-0 right-0 font-minecraft text-[10px] font-bold text-white drop-shadow">
                        {slot.count}
                      </span>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* 27 Inventory Slots */}
        <div>
          <span className="font-minecraft text-[11px] font-bold text-[#333] mb-1 block">Inventory</span>
          <div className="grid grid-cols-9 gap-1 p-1.5 bg-[#8b8b8b] border-2 border-[#555] rounded">
            {inventory.map((slot, index) => (
              <div
                key={index}
                onClick={() =>
                  handleSlotClick(slot, (newStack) => {
                    const next = [...inventory];
                    next[index] = newStack;
                    setInventory(next);
                  })
                }
                className="w-10 h-10 mc-slot flex items-center justify-center cursor-pointer hover:brightness-110"
              >
                {slot && (
                  <div className="relative w-8 h-8 flex items-center justify-center">
                    <img src={getItemDataUrl(slot.id)} alt="" className="w-7 h-7 object-contain pixelated pointer-events-none" />
                    {slot.count > 1 && (
                      <span className="absolute bottom-0 right-0 font-minecraft text-[10px] font-bold text-white drop-shadow">
                        {slot.count}
                      </span>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* 9 Hotbar Slots */}
        <div>
          <span className="font-minecraft text-[11px] font-bold text-[#333] mb-1 block">Hotbar</span>
          <div className="grid grid-cols-9 gap-1 p-1.5 bg-[#8b8b8b] border-2 border-[#555] rounded">
            {hotbar.map((slot, index) => (
              <div
                key={index}
                onClick={() =>
                  handleSlotClick(slot, (newStack) => {
                    const next = [...hotbar];
                    next[index] = newStack;
                    setHotbar(next);
                  })
                }
                className="w-10 h-10 mc-slot flex items-center justify-center cursor-pointer hover:brightness-110"
              >
                {slot && (
                  <div className="relative w-8 h-8 flex items-center justify-center">
                    <img src={getItemDataUrl(slot.id)} alt="" className="w-7 h-7 object-contain pixelated pointer-events-none" />
                    {slot.count > 1 && (
                      <span className="absolute bottom-0 right-0 font-minecraft text-[10px] font-bold text-white drop-shadow">
                        {slot.count}
                      </span>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
