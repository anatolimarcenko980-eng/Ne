/**
 * Minecraft Web Edition - Main App Component.
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { CameraPerspective, GameMode, ItemStack, ItemType, WorldSettings } from './types/game';
import { ITEMS } from './engine/items';
import { MobManager } from './engine/mobs';
import { ParticleSystem } from './engine/particles';
import { Player } from './engine/player';
import { SkyEngine } from './engine/sky';
import { sound } from './engine/sound';
import { World } from './engine/world';
import { ChatMessage, ChatOverlay } from './components/ChatOverlay';
import { ChestModal } from './components/ChestModal';
import { CraftingTableModal } from './components/CraftingTableModal';
import { DebugOverlay } from './components/DebugOverlay';
import { FurnaceModal } from './components/FurnaceModal';
import { HUD } from './components/HUD';
import { InventoryModal } from './components/InventoryModal';
import { PauseMenu } from './components/PauseMenu';
import { TouchControls } from './components/TouchControls';

const SPLASHES = [
  'Now with 100% more voxels!',
  'WebGL Powered!',
  'Craft all the things!',
  'Beware of Creepers!',
  'Day & Night Cycle!',
  'Unlimited Creativity!',
  'Procedural Endless Terrain!',
  'Punch trees for wood!',
];

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<{
    renderer: THREE.WebGLRenderer;
    scene: THREE.Scene;
    world: World;
    player: Player;
    sky: SkyEngine;
    mobs: MobManager;
    particles: ParticleSystem;
  } | null>(null);

  // Game UI States
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [isInventoryOpen, setIsInventoryOpen] = useState<boolean>(false);
  const [isCraftingTableOpen, setIsCraftingTableOpen] = useState<boolean>(false);
  const [isFurnaceOpen, setIsFurnaceOpen] = useState<boolean>(false);
  const [isChestOpen, setIsChestOpen] = useState<boolean>(false);
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);

  // Camera States
  const [cameraMode, setCameraMode] = useState<CameraPerspective>('first_person');
  const [isZooming, setIsZooming] = useState<boolean>(false);
  const [cameraDistance, setCameraDistance] = useState<number>(3.5);

  // Persistent Chest inventory
  const [chestSlots, setChestSlots] = useState<(ItemStack | null)[]>(Array(27).fill(null));

  // Player Stats synced to React state
  const [health, setHealth] = useState<number>(20);
  const [hunger, setHunger] = useState<number>(20);
  const [xpLevel, setXpLevel] = useState<number>(0);
  const [xpProgress, setXpProgress] = useState<number>(0);
  const [gameMode, setGameMode] = useState<GameMode>('survival');
  const [hotbar, setHotbar] = useState<(ItemStack | null)[]>([]);
  const [inventory, setInventory] = useState<(ItemStack | null)[]>([]);
  const [selectedSlot, setSelectedSlot] = useState<number>(0);
  const [isSwimming, setIsSwimming] = useState<boolean>(false);

  // Settings & Debug
  const [settings, setSettings] = useState<WorldSettings>({
    seed: 42819,
    renderDistance: 3,
    fov: 75,
    dayNightSpeed: 1,
    showDebug: false,
    soundVolume: 0.6,
  });
  const [fps, setFps] = useState<number>(60);
  const [playerPos, setPlayerPos] = useState<THREE.Vector3>(new THREE.Vector3(8.5, 26, 8.5));
  const [playerYaw, setPlayerYaw] = useState<number>(0);
  const [playerPitch, setPlayerPitch] = useState<number>(0);
  const [targetBlock, setTargetBlock] = useState<{ blockPos: THREE.Vector3; blockType: string } | null>(null);
  const [timeOfDay, setTimeOfDayState] = useState<number>(0.2);

  // Chat messages
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: '1', text: 'Welcome to Minecraft Web Edition!', color: '#55ff55' },
    { id: '2', text: 'Press E for inventory, T for chat commands (/help).', color: '#ffff55' },
  ]);

  const [splashText] = useState(() => SPLASHES[Math.floor(Math.random() * SPLASHES.length)]);

  // Initialize Three.js Engine
  useEffect(() => {
    if (!containerRef.current) return;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    containerRef.current.appendChild(renderer.domElement);

    // Scene
    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0x78a7ff, 30, 85);

    // World & Systems
    const world = new World(settings.seed);
    scene.add(world.group);

    const particles = new ParticleSystem();
    scene.add(particles.group);

    const mobs = new MobManager(world);
    scene.add(mobs.group);

    const sky = new SkyEngine();
    scene.add(sky.group);

    const player = new Player(world, mobs, particles);
    player.addToScene(scene);

    // Wire player UI opening callbacks
    player.onOpenCraftingTable = () => {
      document.exitPointerLock();
      setIsCraftingTableOpen(true);
    };
    player.onOpenFurnace = () => {
      document.exitPointerLock();
      setIsFurnaceOpen(true);
    };
    player.onOpenChest = () => {
      document.exitPointerLock();
      setIsChestOpen(true);
    };

    // Pre-generate starter chunks around spawn
    world.updatePlayerChunks(player.position);

    // Initial state sync
    setHotbar([...player.hotbar]);
    setInventory([...player.inventory]);

    engineRef.current = { renderer, scene, world, player, sky, mobs, particles };

    // Animation Loop
    let lastTime = performance.now();
    let frameCount = 0;
    let fpsTime = lastTime;
    let animId: number;

    const animate = (now: number) => {
      animId = requestAnimationFrame(animate);

      const dt = Math.min((now - lastTime) / 1000, 0.1);
      lastTime = now;

      frameCount++;
      if (now - fpsTime >= 1000) {
        setFps(frameCount);
        frameCount = 0;
        fpsTime = now;
      }

      // Check if game is active
      const isModalOpen =
        isInventoryOpen ||
        isCraftingTableOpen ||
        isFurnaceOpen ||
        isChestOpen ||
        isPaused ||
        !document.pointerLockElement;

      if (!isModalOpen) {
        player.update(dt);
        particles.update(dt);
        mobs.update(
          dt,
          player.position,
          (dmg) => {
            player.takeDamage(dmg);
            setHealth(player.health);
          },
          (pos) => {
            particles.emitExplosion(pos);
            world.explode(pos, 3.5);
          }
        );
        sky.update(dt, player.position, scene);
        world.updatePlayerChunks(player.position);

        // Sync player status
        setHealth(player.health);
        setHunger(player.hunger);
        setIsSwimming(player.isSwimming);
        setXpLevel(player.xpLevel);
        setPlayerPos(player.position.clone());
        setPlayerYaw(player.yaw);
        setPlayerPitch(player.pitch);
        setTimeOfDayState(sky.time);

        if (player.targetBlock) {
          setTargetBlock({
            blockPos: player.targetBlock.blockPos,
            blockType: player.targetBlock.blockType,
          });
        } else {
          setTargetBlock(null);
        }
      }

      renderer.render(scene, player.camera);
    };

    animId = requestAnimationFrame(animate);

    // Handle Window Resize
    const handleResize = () => {
      if (!engineRef.current) return;
      const { renderer, player } = engineRef.current;
      player.camera.aspect = window.innerWidth / window.innerHeight;
      player.camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (containerRef.current?.contains(renderer.domElement)) {
        containerRef.current.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Update FOV when setting changes
  useEffect(() => {
    if (engineRef.current) {
      engineRef.current.player.camera.fov = settings.fov;
      engineRef.current.player.camera.updateProjectionMatrix();
    }
  }, [settings.fov]);

  // Sync hotbar & inventory changes back to Player engine
  useEffect(() => {
    if (engineRef.current) {
      engineRef.current.player.hotbar = hotbar;
      engineRef.current.player.inventory = inventory;
    }
  }, [hotbar, inventory]);

  // Sync game mode
  useEffect(() => {
    if (engineRef.current) {
      engineRef.current.player.gameMode = gameMode;
    }
  }, [gameMode]);

  // Pointer Lock change listener
  useEffect(() => {
    const handlePointerLockChange = () => {
      const locked = !!document.pointerLockElement;
      if (!locked) {
        // If not in a modal, show pause menu
        if (!isInventoryOpen && !isCraftingTableOpen && !isFurnaceOpen && !isChestOpen && !isChatOpen) {
          setIsPaused(true);
        }
      } else {
        setIsPaused(false);
      }
    };

    document.addEventListener('pointerlockchange', handlePointerLockChange);
    return () => document.removeEventListener('pointerlockchange', handlePointerLockChange);
  }, [isInventoryOpen, isCraftingTableOpen, isFurnaceOpen, isChestOpen, isChatOpen]);

  // Camera Control Functions
  const handleCycleCamera = () => {
    if (!engineRef.current) return;
    const next = engineRef.current.player.cycleCameraMode();
    setCameraMode(next);
    addChatMessage(
      `Camera View: ${
        next === 'first_person'
          ? 'First Person'
          : next === 'third_person_back'
          ? 'Third Person (Back)'
          : 'Third Person (Front)'
      }`,
      '#ffff55'
    );
  };

  const handleToggleZoom = () => {
    if (!engineRef.current) return;
    engineRef.current.player.isZooming = !engineRef.current.player.isZooming;
    setIsZooming(engineRef.current.player.isZooming);
  };

  const handleChangeCameraDistance = (dist: number) => {
    if (!engineRef.current) return;
    engineRef.current.player.cameraDistance = dist;
    setCameraDistance(dist);
  };

  // Keyboard Event Listeners
  useEffect(() => {
    let isDraggingLook = false;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (!engineRef.current) return;
      const { player } = engineRef.current;

      // When chat is open, do not intercept keys
      if (isChatOpen) return;

      // F5 Toggle Camera Perspective
      if (e.code === 'F5') {
        e.preventDefault();
        handleCycleCamera();
        return;
      }

      // KeyC: OptiFine Zoom
      if (e.code === 'KeyC') {
        player.isZooming = true;
        setIsZooming(true);
      }

      // Hotbar selection 1-9
      if (e.code >= 'Digit1' && e.code <= 'Digit9') {
        const slot = parseInt(e.code.replace('Digit', '')) - 1;
        setSelectedSlot(slot);
        player.selectedSlot = slot;
        sound.playClick();
        return;
      }

      // Inventory toggle 'KeyE'
      if (e.code === 'KeyE') {
        e.preventDefault();
        if (isInventoryOpen || isCraftingTableOpen || isFurnaceOpen || isChestOpen) {
          setIsInventoryOpen(false);
          setIsCraftingTableOpen(false);
          setIsFurnaceOpen(false);
          setIsChestOpen(false);
          requestPointerLock();
        } else {
          document.exitPointerLock();
          setIsInventoryOpen(true);
        }
        return;
      }

      // Chat open 'KeyT' or 'Slash'
      if (e.code === 'KeyT' || e.code === 'Slash') {
        e.preventDefault();
        document.exitPointerLock();
        setIsChatOpen(true);
        return;
      }

      // Debug F3 toggle
      if (e.code === 'F3') {
        e.preventDefault();
        setSettings((s) => ({ ...s, showDebug: !s.showDebug }));
        return;
      }

      // Space jump and double-tap for fly
      if (e.code === 'Space' || e.key === ' ') {
        player.handleSpacePress();
        player.keys['Space'] = true;
      }

      player.keys[e.code] = true;
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (!engineRef.current) return;
      if (e.code === 'KeyC') {
        engineRef.current.player.isZooming = false;
        setIsZooming(false);
      }
      if (e.code === 'Space' || e.key === ' ') {
        engineRef.current.player.keys['Space'] = false;
      }
      engineRef.current.player.keys[e.code] = false;
    };

    const handleMouseDown = (e: MouseEvent) => {
      if (!engineRef.current) return;
      const { player } = engineRef.current;

      if (!document.pointerLockElement) {
        // Drag to rotate/move camera when unlocked
        isDraggingLook = true;
        return;
      }

      if (e.button === 0) {
        player.isLeftMouseDown = true;
        player.onLeftClick();
      } else if (e.button === 2) {
        player.isRightMouseDown = true;
        player.onRightClick();
        setHotbar([...player.hotbar]);
      }
    };

    const handleMouseUp = (e: MouseEvent) => {
      isDraggingLook = false;
      if (!engineRef.current) return;
      const { player } = engineRef.current;
      if (e.button === 0) player.isLeftMouseDown = false;
      if (e.button === 2) player.isRightMouseDown = false;
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!engineRef.current) return;
      if (document.pointerLockElement || isDraggingLook) {
        engineRef.current.player.onMouseMove(e.movementX, e.movementY);
      }
    };

    const handleWheel = (e: WheelEvent) => {
      if (!engineRef.current) return;
      const { player } = engineRef.current;

      // If in 3rd person mode or holding Alt, mouse wheel moves camera distance!
      if (player.cameraMode !== 'first_person' || e.altKey) {
        player.setCameraDistance(e.deltaY * 0.005);
        setCameraDistance(player.cameraDistance);
        return;
      }

      // Otherwise scroll hotbar
      const dir = Math.sign(e.deltaY);
      setSelectedSlot((prev) => {
        const next = (prev + dir + 9) % 9;
        player.selectedSlot = next;
        sound.playClick();
        return next;
      });
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('wheel', handleWheel);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('wheel', handleWheel);
    };
  }, [isChatOpen, isInventoryOpen, isCraftingTableOpen, isFurnaceOpen, isChestOpen, cameraMode]);

  const requestPointerLock = () => {
    sound.enabled = true;
    containerRef.current?.requestPointerLock();
    setIsPlaying(true);
    setIsPaused(false);
  };

  // Command execution handler
  const handleExecuteCommand = (cmd: string, args: string[]) => {
    if (!engineRef.current) return;
    const { player, sky, mobs } = engineRef.current;

    switch (cmd) {
      case 'gamemode': {
        const mode = args[0]?.toLowerCase();
        if (mode === 'c' || mode === 'creative') {
          setGameMode('creative');
          addChatMessage(`Set game mode to Creative Mode.`, '#55ff55');
        } else if (mode === 's' || mode === 'survival') {
          setGameMode('survival');
          addChatMessage(`Set game mode to Survival Mode.`, '#55ff55');
        } else {
          addChatMessage(`Usage: /gamemode <survival|creative>`, '#ff5555');
        }
        break;
      }
      case 'time': {
        const sub = args[0]?.toLowerCase();
        const val = args[1]?.toLowerCase();
        if (sub === 'set') {
          if (val === 'day') {
            sky.time = 0.25;
            addChatMessage(`Set time to Day.`, '#ffff55');
          } else if (val === 'night') {
            sky.time = 0.75;
            addChatMessage(`Set time to Night.`, '#ffff55');
          } else {
            const num = parseFloat(val);
            if (!isNaN(num)) {
              sky.time = (num % 24000) / 24000;
              addChatMessage(`Set time to ${num}.`, '#ffff55');
            }
          }
        }
        break;
      }
      case 'give': {
        const item = args[0] as ItemType;
        const count = parseInt(args[1]) || 64;
        if (item && ITEMS[item]) {
          player.addToInventory(item, count);
          setHotbar([...player.hotbar]);
          setInventory([...player.inventory]);
          addChatMessage(`Gave ${count} [${ITEMS[item].name}] to player.`, '#55ff55');
        } else {
          addChatMessage(`Unknown item ID. Try: diamond_sword, tnt, oak_log, torch`, '#ff5555');
        }
        break;
      }
      case 'spawn': {
        const type = args[0]?.toLowerCase() as 'pig' | 'sheep' | 'zombie' | 'creeper';
        if (['pig', 'sheep', 'zombie', 'creeper'].includes(type)) {
          mobs.spawnMob(type, player.position.x + 2, player.position.y, player.position.z + 2);
          addChatMessage(`Spawned a ${type}!`, '#55ff55');
        } else {
          addChatMessage(`Usage: /spawn <pig|sheep|zombie|creeper>`, '#ff5555');
        }
        break;
      }
      case 'tp': {
        const x = parseFloat(args[0]);
        const y = parseFloat(args[1]);
        const z = parseFloat(args[2]);
        if (!isNaN(x) && !isNaN(y) && !isNaN(z)) {
          player.position.set(x, y, z);
          player.velocity.set(0, 0, 0);
          addChatMessage(`Teleported player to ${x}, ${y}, ${z}.`, '#55ff55');
        } else {
          addChatMessage(`Usage: /tp <x> <y> <z>`, '#ff5555');
        }
        break;
      }
      case 'clear': {
        player.hotbar = Array(9).fill(null);
        player.inventory = Array(27).fill(null);
        setHotbar([...player.hotbar]);
        setInventory([...player.inventory]);
        addChatMessage(`Cleared player inventory.`, '#ffff55');
        break;
      }
      case 'help': {
        addChatMessage(
          `Commands: /gamemode <mode>, /time set <day|night>, /give <item> [amt], /spawn <mob>, /tp <x y z>, /clear`,
          '#ffff55'
        );
        break;
      }
      default:
        addChatMessage(`Unknown command: /${cmd}. Type /help for help.`, '#ff5555');
    }
  };

  const addChatMessage = (text: string, color?: string, sender?: string) => {
    setMessages((prev) => [
      ...prev,
      {
        id: Math.random().toString(36).substring(2, 9),
        text,
        color,
        sender,
      },
    ]);
  };

  // World Save & Load handlers
  const handleSaveWorld = () => {
    if (!engineRef.current) return;
    const json = engineRef.current.world.exportWorld();
    localStorage.setItem('minecraft_web_world', json);
    localStorage.setItem('minecraft_web_inventory', JSON.stringify({ hotbar, inventory, chestSlots }));
    addChatMessage(`World successfully saved to local browser storage!`, '#55ff55');
  };

  const handleExportWorld = () => {
    if (!engineRef.current) return;
    const json = engineRef.current.world.exportWorld();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `minecraft-world-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportWorld = (json: string) => {
    if (!engineRef.current) return;
    engineRef.current.world.loadWorld(json);
    engineRef.current.world.updatePlayerChunks(engineRef.current.player.position);
    addChatMessage(`World imported and loaded successfully!`, '#55ff55');
  };

  const handleResetWorld = () => {
    if (!engineRef.current) return;
    const newSeed = Math.floor(Math.random() * 999999);
    setSettings((s) => ({ ...s, seed: newSeed }));
    engineRef.current.world.seed = newSeed;
    engineRef.current.world.noise.reseed(newSeed);
    engineRef.current.world.loadWorld(JSON.stringify({ seed: newSeed, modifications: [] }));
    engineRef.current.player.position.set(8.5, 26, 8.5);
    engineRef.current.world.updatePlayerChunks(engineRef.current.player.position);
    addChatMessage(`Generated new world with seed ${newSeed}!`, '#ffff55');
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-black select-none">
      {/* 3D WebGL Canvas */}
      <div ref={containerRef} className="w-full h-full cursor-crosshair" onClick={requestPointerLock} />

      {/* Main Title / Play Splash Screen (when not locked in game) */}
      {!isPlaying && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-black/85 backdrop-blur-md p-6">
          {/* Minecraft Title Header */}
          <div className="relative flex flex-col items-center mb-8">
            <h1 className="font-minecraft text-4xl sm:text-6xl text-white font-extrabold tracking-widest drop-shadow-[0_6px_0_#1a1a1a]">
              MINECRAFT
            </h1>
            <span className="font-minecraft text-lg sm:text-2xl text-emerald-400 font-bold -mt-1 tracking-wider drop-shadow-[0_2px_0_#000]">
              WEB EDITION
            </span>
            {/* Vibrating Yellow Splash Text */}
            <div className="absolute -bottom-4 right-0 sm:-right-8 transform rotate-[-12deg] animate-pulse">
              <span className="font-minecraft text-xs sm:text-sm text-yellow-300 font-bold drop-shadow-[0_2px_0_#000]">
                {splashText}
              </span>
            </div>
          </div>

          {/* Play & Options Buttons */}
          <div className="w-full max-w-xs flex flex-col gap-3">
            <button
              onClick={() => {
                sound.playClick();
                requestPointerLock();
              }}
              className="mc-btn py-3 font-minecraft text-base font-bold shadow-lg"
            >
              Play Singleplayer
            </button>

            <button
              onClick={() => {
                sound.playClick();
                setGameMode(gameMode === 'survival' ? 'creative' : 'survival');
              }}
              className="mc-btn py-2.5 font-minecraft text-xs font-bold"
            >
              Mode:{' '}
              <span className={gameMode === 'creative' ? 'text-amber-300' : 'text-emerald-300'}>
                {gameMode.toUpperCase()}
              </span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                setIsInventoryOpen(true);
              }}
              className="mc-btn py-2 font-minecraft text-xs font-bold"
            >
              Item Catalog
            </button>
          </div>

          {/* Quick Controls Cheat Sheet */}
          <div className="mt-8 p-3 bg-black/50 border border-white/20 rounded max-w-sm text-center font-minecraft text-[11px] text-gray-300">
            <p className="text-white font-bold mb-1">🎮 Controls</p>
            <p>WASD to Move • SPACE to Jump • Arrows / Mouse to Look</p>
            <p>F5: Toggle Camera (1st/3rd person) • C: Zoom</p>
            <p>LEFT CLICK: Mine/Attack • RIGHT CLICK: Place/Interact</p>
            <p>E: Inventory • 1-9: Hotbar • T: Chat • ESC: Pause</p>
          </div>
        </div>
      )}

      {/* In-Game HUD */}
      {isPlaying && (
        <HUD
          health={health}
          maxHealth={20}
          hunger={hunger}
          maxHunger={20}
          xpLevel={xpLevel}
          xpProgress={xpProgress}
          hotbar={hotbar}
          selectedSlot={selectedSlot}
          onSelectSlot={(s) => {
            setSelectedSlot(s);
            if (engineRef.current) engineRef.current.player.selectedSlot = s;
          }}
          gameMode={gameMode}
          isSwimming={isSwimming}
          cameraMode={cameraMode}
          onCycleCamera={handleCycleCamera}
          isZooming={isZooming}
          onToggleZoom={handleToggleZoom}
        />
      )}

      {/* F3 Debug Overlay */}
      <DebugOverlay
        visible={settings.showDebug}
        fps={fps}
        playerPos={playerPos}
        yaw={playerYaw}
        pitch={playerPitch}
        targetBlock={targetBlock}
        timeOfDay={timeOfDay}
        activeChunks={engineRef.current?.world.chunks.size || 0}
        mobsCount={engineRef.current?.mobs.mobs.length || 0}
        cameraMode={
          cameraMode === 'first_person'
            ? 'First Person'
            : cameraMode === 'third_person_back'
            ? 'Third Person (Back)'
            : 'Third Person (Front)'
        }
      />

      {/* Chat & Commands Overlay */}
      <ChatOverlay
        isOpen={isChatOpen}
        onClose={() => {
          setIsChatOpen(false);
          requestPointerLock();
        }}
        messages={messages}
        onSendMessage={(text) => addChatMessage(text, '#ffffff', 'Player')}
        onExecuteCommand={handleExecuteCommand}
      />

      {/* Inventory & Creative Catalog Modal */}
      <InventoryModal
        isOpen={isInventoryOpen}
        onClose={() => {
          setIsInventoryOpen(false);
          requestPointerLock();
        }}
        hotbar={hotbar}
        setHotbar={setHotbar}
        inventory={inventory}
        setInventory={setInventory}
        gameMode={gameMode}
      />

      {/* 3x3 Crafting Table Modal */}
      <CraftingTableModal
        isOpen={isCraftingTableOpen}
        onClose={() => {
          setIsCraftingTableOpen(false);
          requestPointerLock();
        }}
        hotbar={hotbar}
        setHotbar={setHotbar}
        inventory={inventory}
        setInventory={setInventory}
      />

      {/* Furnace Smelting Modal */}
      <FurnaceModal
        isOpen={isFurnaceOpen}
        onClose={() => {
          setIsFurnaceOpen(false);
          requestPointerLock();
        }}
        hotbar={hotbar}
        setHotbar={setHotbar}
        inventory={inventory}
        setInventory={setInventory}
      />

      {/* Chest Container Modal */}
      <ChestModal
        isOpen={isChestOpen}
        onClose={() => {
          setIsChestOpen(false);
          requestPointerLock();
        }}
        chestSlots={chestSlots}
        setChestSlots={setChestSlots}
        hotbar={hotbar}
        setHotbar={setHotbar}
        inventory={inventory}
        setInventory={setInventory}
      />

      {/* Pause Menu */}
      <PauseMenu
        isOpen={isPaused && isPlaying && !isInventoryOpen && !isCraftingTableOpen && !isFurnaceOpen && !isChestOpen && !isChatOpen}
        onResume={requestPointerLock}
        gameMode={gameMode}
        setGameMode={setGameMode}
        settings={settings}
        setSettings={setSettings}
        setTimeOfDay={(t) => {
          if (engineRef.current) engineRef.current.sky.time = t;
        }}
        onSaveWorld={handleSaveWorld}
        onExportWorld={handleExportWorld}
        onImportWorld={handleImportWorld}
        onResetWorld={handleResetWorld}
        cameraMode={cameraMode}
        onCycleCamera={handleCycleCamera}
        cameraDistance={cameraDistance}
        onChangeCameraDistance={handleChangeCameraDistance}
      />

      {/* Mobile Touch Controls */}
      <TouchControls
        onDirectionChange={(dirs) => {
          if (!engineRef.current) return;
          const { keys } = engineRef.current.player;
          keys['KeyW'] = dirs.forward;
          keys['KeyS'] = dirs.backward;
          keys['KeyA'] = dirs.left;
          keys['KeyD'] = dirs.right;
        }}
        onJump={(active) => {
          if (!engineRef.current) return;
          if (active) engineRef.current.player.handleSpacePress();
          engineRef.current.player.keys['Space'] = active;
        }}
        onMine={(active) => {
          if (!engineRef.current) return;
          engineRef.current.player.isLeftMouseDown = active;
          if (active) engineRef.current.player.onLeftClick();
        }}
        onPlace={() => {
          if (!engineRef.current) return;
          engineRef.current.player.onRightClick();
          setHotbar([...engineRef.current.player.hotbar]);
        }}
        onInventory={() => {
          document.exitPointerLock();
          setIsInventoryOpen(true);
        }}
        onRotateCamera={(dx, dy) => {
          if (engineRef.current) {
            engineRef.current.player.onMouseMove(dx, dy);
          }
        }}
        isCreative={gameMode === 'creative'}
      />
    </div>
  );
}
