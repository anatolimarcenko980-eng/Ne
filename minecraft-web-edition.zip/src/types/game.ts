/**
 * Types and definitions for Minecraft Web Edition
 */

export type BlockType =
  | 'air'
  | 'grass'
  | 'dirt'
  | 'stone'
  | 'cobblestone'
  | 'bedrock'
  | 'oak_log'
  | 'oak_planks'
  | 'oak_leaves'
  | 'sand'
  | 'sandstone'
  | 'gravel'
  | 'glass'
  | 'bricks'
  | 'bookshelf'
  | 'tnt'
  | 'obsidian'
  | 'diamond_ore'
  | 'iron_ore'
  | 'coal_ore'
  | 'gold_ore'
  | 'redstone_ore'
  | 'crafting_table'
  | 'furnace'
  | 'chest'
  | 'torch'
  | 'dandelion'
  | 'rose'
  | 'water'
  | 'oak_door';

export type ItemType =
  | BlockType
  | 'stick'
  | 'coal'
  | 'iron_ingot'
  | 'gold_ingot'
  | 'diamond'
  | 'raw_porkchop'
  | 'cooked_porkchop'
  | 'apple'
  | 'bread'
  | 'gunpowder'
  | 'wooden_pickaxe'
  | 'stone_pickaxe'
  | 'iron_pickaxe'
  | 'diamond_pickaxe'
  | 'wooden_sword'
  | 'stone_sword'
  | 'iron_sword'
  | 'diamond_sword'
  | 'wooden_axe'
  | 'stone_axe'
  | 'iron_axe'
  | 'diamond_axe'
  | 'wooden_shovel'
  | 'stone_shovel'
  | 'iron_shovel'
  | 'diamond_shovel';

export interface ItemStack {
  id: ItemType;
  count: number;
}

export type GameMode = 'survival' | 'creative';

export type CameraPerspective = 'first_person' | 'third_person_back' | 'third_person_front';

export interface BlockDef {
  id: BlockType;
  name: string;
  isSolid: boolean;
  isTransparent?: boolean;
  isLightSource?: boolean;
  hardness: number; // break time factor in survival
  dropItem: ItemType;
  dropCount?: number;
  soundCategory: 'stone' | 'wood' | 'dirt' | 'grass' | 'sand' | 'glass';
}

export interface ItemDef {
  id: ItemType;
  name: string;
  isBlock: boolean;
  maxStack: number;
  toolType?: 'pickaxe' | 'sword' | 'axe' | 'shovel';
  toolSpeedMultiplier?: number;
  attackDamage?: number;
  foodValue?: number;
}

export interface MobEntity {
  id: string;
  type: 'pig' | 'sheep' | 'zombie' | 'creeper';
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  vx: number;
  vy: number;
  vz: number;
  health: number;
  maxHealth: number;
  isHurt: number; // timer for red flash
  fuseTimer?: number; // for creeper
  walkCycle: number;
  targetPlayer?: boolean;
}

export interface WorldSettings {
  seed: number;
  renderDistance: number; // in chunks or radius
  fov: number;
  dayNightSpeed: number; // 1 = standard (~10 min), 2 = fast, 0 = freeze
  showDebug: boolean;
  soundVolume: number;
}
