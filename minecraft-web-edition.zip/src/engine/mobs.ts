/**
 * Mobs & Living Entities: Pigs, Sheep, Zombies, and Creepers with voxel geometry, AI, and animations.
 */

import * as THREE from 'three';
import { ItemType, MobEntity } from '../types/game';
import { sound } from './sound';
import { World } from './world';

export class MobManager {
  public group: THREE.Group = new THREE.Group();
  public mobs: MobEntity[] = [];
  private mobMeshes = new Map<string, THREE.Group>();
  private world: World;
  private spawnTimer: number = 0;

  constructor(world: World) {
    this.world = world;
  }

  // Create 3D Voxel Mob Mesh
  private createMobMesh(type: MobEntity['type']): THREE.Group {
    const root = new THREE.Group();

    if (type === 'pig') {
      const pigPink = new THREE.MeshLambertMaterial({ color: 0xf0a19c });
      const pigDark = new THREE.MeshLambertMaterial({ color: 0xd9827c });

      // Body
      const bodyGeo = new THREE.BoxGeometry(0.8, 0.6, 1.1);
      const body = new THREE.Mesh(bodyGeo, pigPink);
      body.position.set(0, 0.6, 0);
      root.add(body);

      // Head
      const headGeo = new THREE.BoxGeometry(0.5, 0.5, 0.5);
      const head = new THREE.Mesh(headGeo, pigPink);
      head.position.set(0, 0.8, 0.65);
      // Snout
      const snoutGeo = new THREE.BoxGeometry(0.3, 0.2, 0.15);
      const snout = new THREE.Mesh(snoutGeo, pigDark);
      snout.position.set(0, -0.05, 0.3);
      head.add(snout);
      root.add(head);

      // 4 Legs
      const legGeo = new THREE.BoxGeometry(0.2, 0.4, 0.2);
      const legPositions = [
        [-0.25, 0.2, 0.35],
        [0.25, 0.2, 0.35],
        [-0.25, 0.2, -0.35],
        [0.25, 0.2, -0.35],
      ];
      legPositions.forEach(([lx, ly, lz], idx) => {
        const leg = new THREE.Mesh(legGeo, pigDark);
        leg.position.set(lx, ly, lz);
        leg.name = `leg_${idx}`;
        root.add(leg);
      });
    } else if (type === 'sheep') {
      const woolMat = new THREE.MeshLambertMaterial({ color: 0xeeeeee });
      const skinMat = new THREE.MeshLambertMaterial({ color: 0xd7bda8 });

      // Body (Wool)
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.7, 1.2), woolMat);
      body.position.set(0, 0.7, 0);
      root.add(body);

      // Head
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.45, 0.45), skinMat);
      head.position.set(0, 0.95, 0.65);
      root.add(head);

      // Legs
      const legGeo = new THREE.BoxGeometry(0.2, 0.5, 0.2);
      const legPositions = [
        [-0.28, 0.25, 0.4],
        [0.28, 0.25, 0.4],
        [-0.28, 0.25, -0.4],
        [0.28, 0.25, -0.4],
      ];
      legPositions.forEach(([lx, ly, lz], idx) => {
        const leg = new THREE.Mesh(legGeo, skinMat);
        leg.position.set(lx, ly, lz);
        leg.name = `leg_${idx}`;
        root.add(leg);
      });
    } else if (type === 'zombie') {
      const skinMat = new THREE.MeshLambertMaterial({ color: 0x48793b });
      const shirtMat = new THREE.MeshLambertMaterial({ color: 0x2e86ab });
      const pantsMat = new THREE.MeshLambertMaterial({ color: 0x364156 });

      // Body
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.7, 0.25), shirtMat);
      body.position.set(0, 1.0, 0);
      root.add(body);

      // Head
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.45, 0.45), skinMat);
      head.position.set(0, 1.55, 0);
      root.add(head);

      // Arms (held outstretched forward)
      const armGeo = new THREE.BoxGeometry(0.18, 0.6, 0.18);
      const armL = new THREE.Mesh(armGeo, skinMat);
      armL.position.set(-0.35, 1.1, 0.25);
      armL.rotation.x = -Math.PI / 2;
      root.add(armL);

      const armR = new THREE.Mesh(armGeo, skinMat);
      armR.position.set(0.35, 1.1, 0.25);
      armR.rotation.x = -Math.PI / 2;
      root.add(armR);

      // Legs
      const legGeo = new THREE.BoxGeometry(0.2, 0.7, 0.2);
      const legL = new THREE.Mesh(legGeo, pantsMat);
      legL.position.set(-0.15, 0.35, 0);
      legL.name = 'leg_0';
      root.add(legL);

      const legR = new THREE.Mesh(legGeo, pantsMat);
      legR.position.set(0.15, 0.35, 0);
      legR.name = 'leg_1';
      root.add(legR);
    } else if (type === 'creeper') {
      const creeperMat = new THREE.MeshLambertMaterial({ color: 0x3a9e3a });
      const darkFace = new THREE.MeshLambertMaterial({ color: 0x1f5c1f });

      // Body
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.7, 0.25), creeperMat);
      body.position.set(0, 0.7, 0);
      root.add(body);

      // Head
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.45, 0.45), creeperMat);
      head.position.set(0, 1.25, 0);

      // Face markings
      const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.2, 0.05), darkFace);
      mouth.position.set(0, -0.05, 0.23);
      head.add(mouth);
      root.add(head);

      // 4 Feet
      const footGeo = new THREE.BoxGeometry(0.2, 0.35, 0.2);
      const footPositions = [
        [-0.15, 0.18, 0.15],
        [0.15, 0.18, 0.15],
        [-0.15, 0.18, -0.15],
        [0.15, 0.18, -0.15],
      ];
      footPositions.forEach(([lx, ly, lz], idx) => {
        const foot = new THREE.Mesh(footGeo, creeperMat);
        foot.position.set(lx, ly, lz);
        foot.name = `leg_${idx}`;
        root.add(foot);
      });
    }

    return root;
  }

  public spawnMob(type: MobEntity['type'], x: number, y: number, z: number): MobEntity {
    const id = Math.random().toString(36).substring(2, 9);
    const mob: MobEntity = {
      id,
      type,
      x,
      y,
      z,
      yaw: Math.random() * Math.PI * 2,
      pitch: 0,
      vx: 0,
      vy: 0,
      vz: 0,
      health: type === 'pig' || type === 'sheep' ? 10 : 20,
      maxHealth: type === 'pig' || type === 'sheep' ? 10 : 20,
      isHurt: 0,
      fuseTimer: type === 'creeper' ? 0 : undefined,
      walkCycle: 0,
    };

    const mesh = this.createMobMesh(type);
    mesh.position.set(x, y, z);
    this.mobMeshes.set(id, mesh);
    this.group.add(mesh);
    this.mobs.push(mob);

    return mob;
  }

  public hitMob(id: string, damage: number, knockbackDir: THREE.Vector3): { dead: boolean; drops: ItemType[] } {
    const mob = this.mobs.find((m) => m.id === id);
    if (!mob) return { dead: false, drops: [] };

    mob.health -= damage;
    mob.isHurt = 0.25; // 0.25s red flash
    mob.vx += knockbackDir.x * 5;
    mob.vy += 3;
    mob.vz += knockbackDir.z * 5;

    sound.playHurt();

    if (mob.health <= 0) {
      this.removeMob(id);
      const drops: ItemType[] = [];
      if (mob.type === 'pig') {
        drops.push('raw_porkchop');
      } else if (mob.type === 'sheep') {
        drops.push('oak_leaves'); // wool substitute
      } else if (mob.type === 'zombie') {
        drops.push('iron_ingot');
      } else if (mob.type === 'creeper') {
        drops.push('gunpowder');
      }
      return { dead: true, drops };
    }

    return { dead: false, drops: [] };
  }

  public removeMob(id: string) {
    const idx = this.mobs.findIndex((m) => m.id === id);
    if (idx !== -1) {
      this.mobs.splice(idx, 1);
    }
    const mesh = this.mobMeshes.get(id);
    if (mesh) {
      this.group.remove(mesh);
      this.mobMeshes.delete(id);
    }
  }

  public update(
    dt: number,
    playerPos: THREE.Vector3,
    onPlayerDamage: (dmg: number) => void,
    onExplosion: (pos: THREE.Vector3) => void
  ) {
    // Spawning logic (keep ~6-10 mobs near player)
    this.spawnTimer += dt;
    if (this.spawnTimer > 4.0 && this.mobs.length < 8) {
      this.spawnTimer = 0;
      const angle = Math.random() * Math.PI * 2;
      const dist = 14 + Math.random() * 18;
      const sx = Math.floor(playerPos.x + Math.cos(angle) * dist);
      const sz = Math.floor(playerPos.z + Math.sin(angle) * dist);

      // Find surface y
      for (let sy = 40; sy >= 3; sy--) {
        if (this.world.isSolid(sx, sy, sz) && !this.world.isSolid(sx, sy + 1, sz) && !this.world.isSolid(sx, sy + 2, sz)) {
          const types: MobEntity['type'][] = ['pig', 'sheep', 'zombie', 'creeper'];
          const type = types[Math.floor(Math.random() * types.length)];
          this.spawnMob(type, sx + 0.5, sy + 1, sz + 0.5);
          break;
        }
      }
    }

    for (let i = this.mobs.length - 1; i >= 0; i--) {
      const mob = this.mobs[i];
      const mesh = this.mobMeshes.get(mob.id);
      if (!mesh) continue;

      const dx = playerPos.x - mob.x;
      const dz = playerPos.z - mob.z;
      const distToPlayer = Math.sqrt(dx * dx + dz * dz);

      // Despawn if too far
      if (distToPlayer > 60) {
        this.removeMob(mob.id);
        continue;
      }

      // Hurt timer
      if (mob.isHurt > 0) {
        mob.isHurt -= dt;
      }

      // AI Logic
      const isHostile = mob.type === 'zombie' || mob.type === 'creeper';
      let moveSpeed = 1.6;

      if (isHostile && distToPlayer < 18) {
        // Chase player
        mob.yaw = Math.atan2(dx, dz);
        moveSpeed = 2.4;

        // Creeper Explosion
        if (mob.type === 'creeper') {
          if (distToPlayer < 3.2) {
            if (mob.fuseTimer === 0) {
              sound.playFuse();
            }
            mob.fuseTimer = (mob.fuseTimer || 0) + dt;

            // Flash white/swell
            const swell = 1 + (mob.fuseTimer / 1.5) * 0.4;
            mesh.scale.set(swell, swell, swell);

            if (mob.fuseTimer >= 1.5) {
              // BOOM!
              const explPos = new THREE.Vector3(mob.x, mob.y, mob.z);
              this.removeMob(mob.id);
              onExplosion(explPos);
              if (distToPlayer < 5) {
                onPlayerDamage(Math.floor((5 - distToPlayer) * 3));
              }
              continue;
            }
          } else if (mob.fuseTimer && mob.fuseTimer > 0) {
            mob.fuseTimer = Math.max(0, mob.fuseTimer - dt * 2);
            mesh.scale.set(1, 1, 1);
          }
        }

        // Zombie Melee Attack
        if (mob.type === 'zombie' && distToPlayer < 1.4 && Math.abs(playerPos.y - mob.y) < 1.5) {
          onPlayerDamage(3);
        }
      } else {
        // Passive wandering
        if (Math.random() < 0.02) {
          mob.yaw += (Math.random() - 0.5) * 2;
        }
      }

      // Desired velocity
      const targetVx = Math.sin(mob.yaw) * moveSpeed;
      const targetVz = Math.cos(mob.yaw) * moveSpeed;

      mob.vx = THREE.MathUtils.lerp(mob.vx, targetVx, dt * 5);
      mob.vz = THREE.MathUtils.lerp(mob.vz, targetVz, dt * 5);
      mob.vy -= 18 * dt; // gravity

      // Step & Jump over obstacle
      const nextX = mob.x + mob.vx * dt;
      const nextZ = mob.z + mob.vz * dt;
      const blockInFront = this.world.isSolid(Math.floor(nextX), Math.floor(mob.y), Math.floor(nextZ));
      const blockAboveFront = this.world.isSolid(Math.floor(nextX), Math.floor(mob.y + 1), Math.floor(nextZ));

      if (blockInFront && !blockAboveFront) {
        mob.vy = 5.2; // jump
      }

      // Simple collision & movement integration
      mob.x += mob.vx * dt;
      mob.z += mob.vz * dt;
      mob.y += mob.vy * dt;

      // Ground check
      const groundY = Math.floor(mob.y);
      if (this.world.isSolid(Math.floor(mob.x), groundY, Math.floor(mob.z))) {
        mob.y = groundY + 1;
        mob.vy = 0;
      }

      // Sync mesh
      mesh.position.set(mob.x, mob.y, mob.z);
      mesh.rotation.y = mob.yaw;

      // Hurt visual (red flash)
      mesh.traverse((child) => {
        if (child instanceof THREE.Mesh && child.material) {
          if (mob.isHurt > 0) {
            child.material.color.setHex(0xff3333);
          } else {
            // Restore default
            if (mob.type === 'pig') child.material.color.setHex(0xf0a19c);
            else if (mob.type === 'sheep') child.material.color.setHex(0xeeeeee);
            else if (mob.type === 'zombie') child.material.color.setHex(0x48793b);
            else if (mob.type === 'creeper') child.material.color.setHex(0x3a9e3a);
          }
        }
      });

      // Leg walk animation
      const isMoving = Math.abs(mob.vx) > 0.1 || Math.abs(mob.vz) > 0.1;
      if (isMoving) {
        mob.walkCycle += dt * 10;
        const legSwing = Math.sin(mob.walkCycle) * 0.5;
        const leg0 = mesh.getObjectByName('leg_0');
        const leg1 = mesh.getObjectByName('leg_1');
        const leg2 = mesh.getObjectByName('leg_2');
        const leg3 = mesh.getObjectByName('leg_3');
        if (leg0) leg0.rotation.x = legSwing;
        if (leg1) leg1.rotation.x = -legSwing;
        if (leg2) leg2.rotation.x = -legSwing;
        if (leg3) leg3.rotation.x = legSwing;
      }
    }
  }
}
