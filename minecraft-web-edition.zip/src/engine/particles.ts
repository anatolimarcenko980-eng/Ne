/**
 * Particle system for block breaking, explosions, and splashes in Minecraft Web Edition.
 */

import * as THREE from 'three';
import { BlockType } from '../types/game';

interface Particle {
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  color: THREE.Color;
  size: number;
  life: number;
  maxLife: number;
}

const BLOCK_COLORS: Record<string, number> = {
  grass: 0x58a834,
  dirt: 0x866043,
  stone: 0x828282,
  cobblestone: 0x737373,
  oak_log: 0x694e30,
  oak_planks: 0xa58050,
  oak_leaves: 0x2d7d1e,
  sand: 0xdbc48f,
  glass: 0xdcf0ff,
  tnt: 0xd93b27,
  diamond_ore: 0x4eebe6,
  iron_ore: 0xd8af93,
  coal_ore: 0x333333,
  gold_ore: 0xffd700,
  redstone_ore: 0xe61414,
  water: 0x285fd7,
};

export class ParticleSystem {
  public group: THREE.Group = new THREE.Group();
  private particles: Particle[] = [];
  private instancedMesh: THREE.InstancedMesh;
  private maxParticles = 600;
  private dummy = new THREE.Object3D();

  constructor() {
    const geo = new THREE.BoxGeometry(0.12, 0.12, 0.12);
    const mat = new THREE.MeshBasicMaterial();
    this.instancedMesh = new THREE.InstancedMesh(geo, mat, this.maxParticles);
    this.instancedMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.group.add(this.instancedMesh);

    // Initialize all off-screen
    for (let i = 0; i < this.maxParticles; i++) {
      this.dummy.position.set(0, -999, 0);
      this.dummy.scale.set(0, 0, 0);
      this.dummy.updateMatrix();
      this.instancedMesh.setMatrixAt(i, this.dummy.matrix);
    }
    this.instancedMesh.instanceMatrix.needsUpdate = true;
  }

  public emitBlockBreak(pos: THREE.Vector3, block: BlockType) {
    const baseColorHex = BLOCK_COLORS[block] || 0x888888;
    const baseColor = new THREE.Color(baseColorHex);

    const count = 16;
    for (let i = 0; i < count; i++) {
      if (this.particles.length >= this.maxParticles) {
        this.particles.shift();
      }

      const pPos = pos.clone().add(
        new THREE.Vector3(
          (Math.random() - 0.5) * 0.8,
          (Math.random() - 0.5) * 0.8,
          (Math.random() - 0.5) * 0.8
        )
      );

      const pVel = new THREE.Vector3(
        (Math.random() - 0.5) * 4,
        Math.random() * 3 + 1,
        (Math.random() - 0.5) * 4
      );

      // Color variation
      const col = baseColor.clone().offsetHSL(
        0,
        (Math.random() - 0.5) * 0.1,
        (Math.random() - 0.5) * 0.15
      );

      this.particles.push({
        position: pPos,
        velocity: pVel,
        color: col,
        size: 0.1 + Math.random() * 0.08,
        life: 0,
        maxLife: 0.5 + Math.random() * 0.4,
      });
    }
  }

  public emitExplosion(pos: THREE.Vector3) {
    const count = 60;
    for (let i = 0; i < count; i++) {
      if (this.particles.length >= this.maxParticles) {
        this.particles.shift();
      }

      const angleTheta = Math.random() * Math.PI * 2;
      const anglePhi = Math.random() * Math.PI;
      const speed = 4 + Math.random() * 10;

      const pVel = new THREE.Vector3(
        Math.sin(anglePhi) * Math.cos(angleTheta) * speed,
        Math.cos(anglePhi) * speed + 2,
        Math.sin(anglePhi) * Math.sin(angleTheta) * speed
      );

      const isFire = Math.random() > 0.4;
      const col = isFire
        ? new THREE.Color(Math.random() > 0.5 ? 0xff4500 : 0xffa500)
        : new THREE.Color(0x555555);

      this.particles.push({
        position: pos.clone(),
        velocity: pVel,
        color: col,
        size: 0.18 + Math.random() * 0.15,
        life: 0,
        maxLife: 0.8 + Math.random() * 0.6,
      });
    }
  }

  public update(dt: number) {
    const gravity = -18;

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life += dt;
      if (p.life >= p.maxLife) {
        this.particles.splice(i, 1);
        continue;
      }

      p.velocity.y += gravity * dt;
      p.position.addScaledVector(p.velocity, dt);
    }

    // Render up to maxParticles
    for (let i = 0; i < this.maxParticles; i++) {
      if (i < this.particles.length) {
        const p = this.particles[i];
        const scale = p.size * (1 - p.life / p.maxLife);
        this.dummy.position.copy(p.position);
        this.dummy.scale.set(scale, scale, scale);
        this.dummy.updateMatrix();
        this.instancedMesh.setMatrixAt(i, this.dummy.matrix);
        this.instancedMesh.setColorAt(i, p.color);
      } else {
        this.dummy.position.set(0, -999, 0);
        this.dummy.scale.set(0, 0, 0);
        this.dummy.updateMatrix();
        this.instancedMesh.setMatrixAt(i, this.dummy.matrix);
      }
    }

    this.instancedMesh.instanceMatrix.needsUpdate = true;
    if (this.instancedMesh.instanceColor) {
      this.instancedMesh.instanceColor.needsUpdate = true;
    }
  }
}
