/**
 * Voxel World Engine with procedural terrain, chunk meshing, face culling, and DDA raycasting.
 */

import * as THREE from 'three';
import { BlockType } from '../types/game';
import { getAtlasMaterial, getBlockFaceUV, getWaterMaterial } from './atlas';
import { BLOCKS } from './items';
import { SimplexNoise } from './noise';

export const CHUNK_SIZE_X = 16;
export const CHUNK_SIZE_Y = 48;
export const CHUNK_SIZE_Z = 16;
export const WATER_LEVEL = 14;

export class Chunk {
  public cx: number;
  public cz: number;
  public blocks: Uint8Array;
  public mesh: THREE.Mesh | null = null;
  public waterMesh: THREE.Mesh | null = null;
  public dirty: boolean = true;

  constructor(cx: number, cz: number) {
    this.cx = cx;
    this.cz = cz;
    this.blocks = new Uint8Array(CHUNK_SIZE_X * CHUNK_SIZE_Y * CHUNK_SIZE_Z);
  }

  public getIndex(x: number, y: number, z: number): number {
    return x + z * CHUNK_SIZE_X + y * CHUNK_SIZE_X * CHUNK_SIZE_Z;
  }

  public getBlock(x: number, y: number, z: number): number {
    if (x < 0 || x >= CHUNK_SIZE_X || y < 0 || y >= CHUNK_SIZE_Y || z < 0 || z >= CHUNK_SIZE_Z) {
      return 0;
    }
    return this.blocks[this.getIndex(x, y, z)];
  }

  public setBlock(x: number, y: number, z: number, id: number) {
    if (x < 0 || x >= CHUNK_SIZE_X || y < 0 || y >= CHUNK_SIZE_Y || z < 0 || z >= CHUNK_SIZE_Z) {
      return;
    }
    this.blocks[this.getIndex(x, y, z)] = id;
    this.dirty = true;
  }
}

// Numerical IDs for high speed memory storage
export const BLOCK_IDS: BlockType[] = [
  'air',
  'grass',
  'dirt',
  'stone',
  'cobblestone',
  'bedrock',
  'oak_log',
  'oak_planks',
  'oak_leaves',
  'sand',
  'sandstone',
  'gravel',
  'glass',
  'bricks',
  'bookshelf',
  'tnt',
  'obsidian',
  'diamond_ore',
  'iron_ore',
  'coal_ore',
  'gold_ore',
  'redstone_ore',
  'crafting_table',
  'furnace',
  'chest',
  'torch',
  'dandelion',
  'rose',
  'water',
  'oak_door',
];

const BLOCK_TO_ID = new Map<BlockType, number>();
BLOCK_IDS.forEach((name, id) => BLOCK_TO_ID.set(name, id));

export function getBlockId(name: BlockType): number {
  return BLOCK_TO_ID.get(name) || 0;
}

export function getBlockName(id: number): BlockType {
  return BLOCK_IDS[id] || 'air';
}

export class World {
  public chunks = new Map<string, Chunk>();
  public group = new THREE.Group();
  public noise: SimplexNoise;
  public seed: number;
  public chunkRadius = 3; // 7x7 chunks around player = 112x112 blocks
  private modifiedBlocks = new Map<string, number>();

  constructor(seed: number = 42819) {
    this.seed = seed;
    this.noise = new SimplexNoise(seed);
  }

  public getChunkKey(cx: number, cz: number): string {
    return `${cx},${cz}`;
  }

  public getBlockKey(x: number, y: number, z: number): string {
    return `${x},${y},${z}`;
  }

  public getChunk(cx: number, cz: number): Chunk | undefined {
    return this.chunks.get(this.getChunkKey(cx, cz));
  }

  public getBlock(x: number, y: number, z: number): BlockType {
    if (y < 0 || y >= CHUNK_SIZE_Y) return 'air';
    const cx = Math.floor(x / CHUNK_SIZE_X);
    const cz = Math.floor(z / CHUNK_SIZE_Z);
    const chunk = this.getChunk(cx, cz);
    if (!chunk) return 'air';

    const lx = ((x % CHUNK_SIZE_X) + CHUNK_SIZE_X) % CHUNK_SIZE_X;
    const lz = ((z % CHUNK_SIZE_Z) + CHUNK_SIZE_Z) % CHUNK_SIZE_Z;
    const id = chunk.getBlock(lx, y, lz);
    return getBlockName(id);
  }

  public setBlock(x: number, y: number, z: number, type: BlockType) {
    if (y < 0 || y >= CHUNK_SIZE_Y) return;
    const cx = Math.floor(x / CHUNK_SIZE_X);
    const cz = Math.floor(z / CHUNK_SIZE_Z);
    const chunk = this.getChunk(cx, cz);
    const id = getBlockId(type);

    this.modifiedBlocks.set(this.getBlockKey(x, y, z), id);

    if (chunk) {
      const lx = ((x % CHUNK_SIZE_X) + CHUNK_SIZE_X) % CHUNK_SIZE_X;
      const lz = ((z % CHUNK_SIZE_Z) + CHUNK_SIZE_Z) % CHUNK_SIZE_Z;
      chunk.setBlock(lx, y, lz, id);

      // If on chunk boundary, also mark neighboring chunk dirty
      if (lx === 0) this.markDirty(cx - 1, cz);
      if (lx === CHUNK_SIZE_X - 1) this.markDirty(cx + 1, cz);
      if (lz === 0) this.markDirty(cx, cz - 1);
      if (lz === CHUNK_SIZE_Z - 1) this.markDirty(cx, cz + 1);
    }
  }

  private markDirty(cx: number, cz: number) {
    const neighbor = this.getChunk(cx, cz);
    if (neighbor) neighbor.dirty = true;
  }

  public isSolid(x: number, y: number, z: number): boolean {
    const block = this.getBlock(x, y, z);
    return BLOCKS[block]?.isSolid ?? false;
  }

  // Generate terrain for a single chunk
  public generateChunk(cx: number, cz: number): Chunk {
    const chunk = new Chunk(cx, cz);
    const startX = cx * CHUNK_SIZE_X;
    const startZ = cz * CHUNK_SIZE_Z;

    for (let lx = 0; lx < CHUNK_SIZE_X; lx++) {
      for (let lz = 0; lz < CHUNK_SIZE_Z; lz++) {
        const wx = startX + lx;
        const wz = startZ + lz;

        // Bedrock
        chunk.setBlock(lx, 0, lz, getBlockId('bedrock'));

        // Biome / height map calculation
        const baseHeight = 18;
        const hillNoise = this.noise.fbm2D(wx * 0.015, wz * 0.015, 4, 0.45) * 16;
        const mountainNoise = Math.max(0, this.noise.noise2D(wx * 0.008, wz * 0.008)) * 12;
        const height = Math.floor(baseHeight + hillNoise + mountainNoise);
        const clampedHeight = Math.min(CHUNK_SIZE_Y - 8, Math.max(3, height));

        const isBeach = clampedHeight <= WATER_LEVEL + 1;

        // Fill column
        for (let y = 1; y <= clampedHeight; y++) {
          // 3D Cave Noise
          const cave = this.noise.noise3D(wx * 0.045, y * 0.065, wz * 0.045);
          if (cave > 0.48 && y > 2 && y < clampedHeight - 2) {
            continue; // air pocket cave
          }

          let blockType: BlockType = 'stone';

          if (y === clampedHeight) {
            blockType = isBeach ? 'sand' : 'grass';
          } else if (y > clampedHeight - 4) {
            blockType = isBeach ? 'sand' : 'dirt';
          } else {
            // Stone layer - populate ores
            const oreRnd = Math.abs(Math.sin(wx * 37.1 + y * 91.7 + wz * 13.3));
            if (y < 8 && oreRnd < 0.018) {
              blockType = 'diamond_ore';
            } else if (y < 12 && oreRnd < 0.025) {
              blockType = 'gold_ore';
            } else if (y < 14 && oreRnd < 0.035) {
              blockType = 'redstone_ore';
            } else if (y < 22 && oreRnd < 0.055) {
              blockType = 'iron_ore';
            } else if (oreRnd < 0.08) {
              blockType = 'coal_ore';
            }
          }

          chunk.setBlock(lx, y, lz, getBlockId(blockType));
        }

        // Fill water up to WATER_LEVEL
        if (clampedHeight < WATER_LEVEL) {
          for (let y = clampedHeight + 1; y <= WATER_LEVEL; y++) {
            chunk.setBlock(lx, y, lz, getBlockId('water'));
          }
        }

        // Foliage (Flowers & Trees)
        if (!isBeach && clampedHeight > WATER_LEVEL && chunk.getBlock(lx, clampedHeight, lz) === getBlockId('grass')) {
          const plantRnd = Math.abs(Math.sin(wx * 19.3 + wz * 53.7));
          if (plantRnd < 0.025) {
            // Dandelion
            chunk.setBlock(lx, clampedHeight + 1, lz, getBlockId('dandelion'));
          } else if (plantRnd < 0.05) {
            // Rose
            chunk.setBlock(lx, clampedHeight + 1, lz, getBlockId('rose'));
          } else if (plantRnd < 0.075 && lx >= 2 && lx <= CHUNK_SIZE_X - 3 && lz >= 2 && lz <= CHUNK_SIZE_Z - 3) {
            // Oak Tree!
            const treeHeight = 4 + Math.floor(Math.abs(Math.sin(wx + wz)) * 3);
            if (clampedHeight + treeHeight + 3 < CHUNK_SIZE_Y) {
              // Trunk
              for (let ty = 1; ty <= treeHeight; ty++) {
                chunk.setBlock(lx, clampedHeight + ty, lz, getBlockId('oak_log'));
              }
              // Leaves Canopy
              for (let oy = -2; oy <= 1; oy++) {
                const radius = oy === 1 ? 1 : 2;
                for (let ox = -radius; ox <= radius; ox++) {
                  for (let oz = -radius; oz <= radius; oz++) {
                    if (ox === 0 && oz === 0 && oy < 1) continue;
                    // Don't cut corner leaves on wide layers
                    if (Math.abs(ox) === radius && Math.abs(oz) === radius && Math.random() > 0.4) continue;
                    const leafY = clampedHeight + treeHeight + oy;
                    if (chunk.getBlock(lx + ox, leafY, lz + oz) === 0) {
                      chunk.setBlock(lx + ox, leafY, lz + oz, getBlockId('oak_leaves'));
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    // Apply saved modifications for this chunk
    for (let lx = 0; lx < CHUNK_SIZE_X; lx++) {
      for (let ly = 0; ly < CHUNK_SIZE_Y; ly++) {
        for (let lz = 0; lz < CHUNK_SIZE_Z; lz++) {
          const key = this.getBlockKey(startX + lx, ly, startZ + lz);
          if (this.modifiedBlocks.has(key)) {
            chunk.setBlock(lx, ly, lz, this.modifiedBlocks.get(key)!);
          }
        }
      }
    }

    return chunk;
  }

  // Ensure chunks around player are loaded
  public updatePlayerChunks(playerPos: THREE.Vector3) {
    const pcx = Math.floor(playerPos.x / CHUNK_SIZE_X);
    const pcz = Math.floor(playerPos.z / CHUNK_SIZE_Z);

    for (let dx = -this.chunkRadius; dx <= this.chunkRadius; dx++) {
      for (let dz = -this.chunkRadius; dz <= this.chunkRadius; dz++) {
        const cx = pcx + dx;
        const cz = pcz + dz;
        const key = this.getChunkKey(cx, cz);
        if (!this.chunks.has(key)) {
          const chunk = this.generateChunk(cx, cz);
          this.chunks.set(key, chunk);
        }
      }
    }

    // Rebuild any dirty meshes
    this.rebuildDirtyMeshes();
  }

  // Mesh builder with visible face culling
  public buildChunkMesh(chunk: Chunk) {
    const positions: number[] = [];
    const normals: number[] = [];
    const uvs: number[] = [];

    const waterPositions: number[] = [];
    const waterNormals: number[] = [];
    const waterUvs: number[] = [];

    const startX = chunk.cx * CHUNK_SIZE_X;
    const startZ = chunk.cz * CHUNK_SIZE_Z;

    for (let y = 0; y < CHUNK_SIZE_Y; y++) {
      for (let z = 0; z < CHUNK_SIZE_Z; z++) {
        for (let x = 0; x < CHUNK_SIZE_X; x++) {
          const id = chunk.getBlock(x, y, z);
          if (id === 0) continue; // air

          const blockType = getBlockName(id);
          const wx = startX + x;
          const wy = y;
          const wz = startZ + z;

          const isWater = blockType === 'water';
          const isFlower = blockType === 'dandelion' || blockType === 'rose';

          if (isFlower) {
            // Render X-cross sprite quad for flowers
            this.addCrossQuad(wx, wy, wz, blockType, positions, normals, uvs);
            continue;
          }

          // Check 6 adjacent faces
          // 0: px (+X)
          if (this.shouldRenderFace(wx + 1, wy, wz, blockType)) {
            this.addFace(0, wx, wy, wz, blockType, isWater ? waterPositions : positions, isWater ? waterNormals : normals, isWater ? waterUvs : uvs);
          }
          // 1: nx (-X)
          if (this.shouldRenderFace(wx - 1, wy, wz, blockType)) {
            this.addFace(1, wx, wy, wz, blockType, isWater ? waterPositions : positions, isWater ? waterNormals : normals, isWater ? waterUvs : uvs);
          }
          // 2: py (+Y)
          if (this.shouldRenderFace(wx, wy + 1, wz, blockType)) {
            this.addFace(2, wx, wy, wz, blockType, isWater ? waterPositions : positions, isWater ? waterNormals : normals, isWater ? waterUvs : uvs);
          }
          // 3: ny (-Y)
          if (this.shouldRenderFace(wx, wy - 1, wz, blockType)) {
            this.addFace(3, wx, wy, wz, blockType, isWater ? waterPositions : positions, isWater ? waterNormals : normals, isWater ? waterUvs : uvs);
          }
          // 4: pz (+Z)
          if (this.shouldRenderFace(wx, wy, wz + 1, blockType)) {
            this.addFace(4, wx, wy, wz, blockType, isWater ? waterPositions : positions, isWater ? waterNormals : normals, isWater ? waterUvs : uvs);
          }
          // 5: nz (-Z)
          if (this.shouldRenderFace(wx, wy, wz - 1, blockType)) {
            this.addFace(5, wx, wy, wz, blockType, isWater ? waterPositions : positions, isWater ? waterNormals : normals, isWater ? waterUvs : uvs);
          }
        }
      }
    }

    // Solid/Opaque Mesh
    if (chunk.mesh) {
      this.group.remove(chunk.mesh);
      chunk.mesh.geometry.dispose();
      chunk.mesh = null;
    }

    if (positions.length > 0) {
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      geo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
      geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));

      chunk.mesh = new THREE.Mesh(geo, getAtlasMaterial());
      chunk.mesh.castShadow = true;
      chunk.mesh.receiveShadow = true;
      this.group.add(chunk.mesh);
    }

    // Water Mesh
    if (chunk.waterMesh) {
      this.group.remove(chunk.waterMesh);
      chunk.waterMesh.geometry.dispose();
      chunk.waterMesh = null;
    }

    if (waterPositions.length > 0) {
      const wGeo = new THREE.BufferGeometry();
      wGeo.setAttribute('position', new THREE.Float32BufferAttribute(waterPositions, 3));
      wGeo.setAttribute('normal', new THREE.Float32BufferAttribute(waterNormals, 3));
      wGeo.setAttribute('uv', new THREE.Float32BufferAttribute(waterUvs, 2));

      chunk.waterMesh = new THREE.Mesh(wGeo, getWaterMaterial());
      this.group.add(chunk.waterMesh);
    }

    chunk.dirty = false;
  }

  private shouldRenderFace(nx: number, ny: number, nz: number, currentBlock: BlockType): boolean {
    if (ny < 0 || ny >= CHUNK_SIZE_Y) return true;
    const neighbor = this.getBlock(nx, ny, nz);
    if (neighbor === 'air') return true;

    const nDef = BLOCKS[neighbor];
    const cDef = BLOCKS[currentBlock];

    if (currentBlock === 'water') {
      return neighbor !== 'water';
    }

    // If neighbor is transparent (glass, leaves, water), render face
    if (nDef && nDef.isTransparent && neighbor !== currentBlock) {
      return true;
    }

    return !nDef || !nDef.isSolid;
  }

  private addFace(
    face: 0 | 1 | 2 | 3 | 4 | 5,
    x: number,
    y: number,
    z: number,
    block: BlockType,
    pos: number[],
    norm: number[],
    uvs: number[]
  ) {
    const [u0, v0, u1, v1] = getBlockFaceUV(block, face);

    // Quad vertices (2 triangles = 6 vertices)
    let p: number[][] = [];
    let n: number[] = [0, 0, 0];

    switch (face) {
      case 0: // +X
        p = [
          [x + 1, y, z],
          [x + 1, y + 1, z],
          [x + 1, y + 1, z + 1],
          [x + 1, y, z],
          [x + 1, y + 1, z + 1],
          [x + 1, y, z + 1],
        ];
        n = [1, 0, 0];
        break;
      case 1: // -X
        p = [
          [x, y, z + 1],
          [x, y + 1, z + 1],
          [x, y + 1, z],
          [x, y, z + 1],
          [x, y + 1, z],
          [x, y, z],
        ];
        n = [-1, 0, 0];
        break;
      case 2: // +Y (Top)
        p = [
          [x, y + 1, z + 1],
          [x + 1, y + 1, z + 1],
          [x + 1, y + 1, z],
          [x, y + 1, z + 1],
          [x + 1, y + 1, z],
          [x, y + 1, z],
        ];
        n = [0, 1, 0];
        break;
      case 3: // -Y (Bottom)
        p = [
          [x, y, z],
          [x + 1, y, z],
          [x + 1, y, z + 1],
          [x, y, z],
          [x + 1, y, z + 1],
          [x, y, z + 1],
        ];
        n = [0, -1, 0];
        break;
      case 4: // +Z
        p = [
          [x + 1, y, z + 1],
          [x + 1, y + 1, z + 1],
          [x, y + 1, z + 1],
          [x + 1, y, z + 1],
          [x, y + 1, z + 1],
          [x, y, z + 1],
        ];
        n = [0, 0, 1];
        break;
      case 5: // -Z
        p = [
          [x, y, z],
          [x, y + 1, z],
          [x + 1, y + 1, z],
          [x, y, z],
          [x + 1, y + 1, z],
          [x + 1, y, z],
        ];
        n = [0, 0, -1];
        break;
    }

    for (let i = 0; i < 6; i++) {
      pos.push(p[i][0], p[i][1], p[i][2]);
      norm.push(n[0], n[1], n[2]);
    }

    // Standard quad UV coordinates
    uvs.push(
      u0, v0,
      u0, v1,
      u1, v1,
      u0, v0,
      u1, v1,
      u1, v0
    );
  }

  private addCrossQuad(
    x: number,
    y: number,
    z: number,
    block: BlockType,
    pos: number[],
    norm: number[],
    uvs: number[]
  ) {
    const [u0, v0, u1, v1] = getBlockFaceUV(block, 2);

    // Diagonal 1
    pos.push(
      x, y, z,
      x, y + 1, z,
      x + 1, y + 1, z + 1,
      x, y, z,
      x + 1, y + 1, z + 1,
      x + 1, y, z + 1
    );
    // Diagonal 2
    pos.push(
      x + 1, y, z,
      x + 1, y + 1, z,
      x, y + 1, z + 1,
      x + 1, y, z,
      x, y + 1, z + 1,
      x, y, z + 1
    );

    for (let i = 0; i < 12; i++) {
      norm.push(0, 1, 0);
    }

    for (let i = 0; i < 2; i++) {
      uvs.push(u0, v0, u0, v1, u1, v1, u0, v0, u1, v1, u1, v0);
    }
  }

  public rebuildDirtyMeshes() {
    this.chunks.forEach((chunk) => {
      if (chunk.dirty) {
        this.buildChunkMesh(chunk);
      }
    });
  }

  // Fast Voxel DDA (Digital Differential Analyzer) Raycaster
  public raycast(
    origin: THREE.Vector3,
    direction: THREE.Vector3,
    maxDistance: number = 6.0
  ): {
    hit: boolean;
    blockPos: THREE.Vector3;
    placePos: THREE.Vector3;
    blockType: BlockType;
    normal: THREE.Vector3;
  } | null {
    let t = 0.0;
    let ix = Math.floor(origin.x);
    let iy = Math.floor(origin.y);
    let iz = Math.floor(origin.z);

    const stepX = direction.x > 0 ? 1 : -1;
    const stepY = direction.y > 0 ? 1 : -1;
    const stepZ = direction.z > 0 ? 1 : -1;

    const txDelta = Math.abs(1 / (direction.x || 1e-9));
    const tyDelta = Math.abs(1 / (direction.y || 1e-9));
    const tzDelta = Math.abs(1 / (direction.z || 1e-9));

    const xDist = stepX > 0 ? ix + 1 - origin.x : origin.x - ix;
    const yDist = stepY > 0 ? iy + 1 - origin.y : origin.y - iy;
    const zDist = stepZ > 0 ? iz + 1 - origin.z : origin.z - iz;

    let txMax = txDelta < Infinity ? txDelta * xDist : Infinity;
    let tyMax = tyDelta < Infinity ? tyDelta * yDist : Infinity;
    let tzMax = tzDelta < Infinity ? tzDelta * zDist : Infinity;

    let steppedIndex = -1;

    while (t <= maxDistance) {
      const block = this.getBlock(ix, iy, iz);
      if (block !== 'air' && block !== 'water') {
        const normal = new THREE.Vector3(
          steppedIndex === 0 ? -stepX : 0,
          steppedIndex === 1 ? -stepY : 0,
          steppedIndex === 2 ? -stepZ : 0
        );
        const hitPos = new THREE.Vector3(ix, iy, iz);
        const placePos = hitPos.clone().add(normal);

        return {
          hit: true,
          blockPos: hitPos,
          placePos,
          blockType: block,
          normal,
        };
      }

      if (txMax < tyMax) {
        if (txMax < tzMax) {
          ix += stepX;
          t = txMax;
          txMax += txDelta;
          steppedIndex = 0;
        } else {
          iz += stepZ;
          t = tzMax;
          tzMax += tzDelta;
          steppedIndex = 2;
        }
      } else {
        if (tyMax < tzMax) {
          iy += stepY;
          t = tyMax;
          tyMax += tyDelta;
          steppedIndex = 1;
        } else {
          iz += stepZ;
          t = tzMax;
          tzMax += tzDelta;
          steppedIndex = 2;
        }
      }
    }

    return null;
  }

  // Explode terrain at position (TNT blast)
  public explode(center: THREE.Vector3, radius: number = 3.5): { x: number; y: number; z: number; type: BlockType }[] {
    const destroyed: { x: number; y: number; z: number; type: BlockType }[] = [];
    const rInt = Math.ceil(radius);

    for (let dx = -rInt; dx <= rInt; dx++) {
      for (let dy = -rInt; dy <= rInt; dy++) {
        for (let dz = -rInt; dz <= rInt; dz++) {
          const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
          if (dist <= radius) {
            const bx = Math.floor(center.x + dx);
            const by = Math.floor(center.y + dy);
            const bz = Math.floor(center.z + dz);

            const b = this.getBlock(bx, by, bz);
            if (b !== 'air' && b !== 'bedrock' && b !== 'obsidian') {
              destroyed.push({ x: bx, y: by, z: bz, type: b });
              this.setBlock(bx, by, bz, 'air');
            }
          }
        }
      }
    }

    return destroyed;
  }

  // Export world state to JSON string
  public exportWorld(): string {
    const data = {
      seed: this.seed,
      modifications: Array.from(this.modifiedBlocks.entries()),
    };
    return JSON.stringify(data);
  }

  // Load world from JSON string
  public loadWorld(json: string) {
    try {
      const data = JSON.parse(json);
      this.seed = data.seed || 1337;
      this.noise.reseed(this.seed);
      this.modifiedBlocks.clear();
      if (Array.isArray(data.modifications)) {
        data.modifications.forEach(([k, v]: [string, number]) => {
          this.modifiedBlocks.set(k, v);
        });
      }
      // Clear chunk cache and regenerate
      this.chunks.forEach((chunk) => {
        if (chunk.mesh) this.group.remove(chunk.mesh);
        if (chunk.waterMesh) this.group.remove(chunk.waterMesh);
      });
      this.chunks.clear();
    } catch (e) {
      console.error('Failed to load world:', e);
    }
  }
}
