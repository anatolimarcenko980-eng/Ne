/**
 * First-person 3D hand & held item renderer with bobbing and swing animation.
 */

import * as THREE from 'three';
import { ItemType } from '../types/game';
import { getAtlasMaterial, getBlockFaceUV } from './atlas';
import { BLOCKS, ITEMS } from './items';
import { getItemCanvas } from './textures';

export class HeldItemRenderer {
  public group: THREE.Group = new THREE.Group();
  private handMesh: THREE.Mesh;
  private itemMesh: THREE.Mesh | null = null;
  private currentItem: ItemType | null = null;

  public swingProgress: number = 0;
  public isSwinging: boolean = false;
  private bobTime: number = 0;

  constructor() {
    // Steve's pixelated hand/arm
    const armGeo = new THREE.BoxGeometry(0.2, 0.6, 0.2);
    // Steve skin color
    const skinMat = new THREE.MeshLambertMaterial({ color: 0xc48c66 });
    this.handMesh = new THREE.Mesh(armGeo, skinMat);
    this.handMesh.position.set(0.38, -0.4, -0.6);
    this.handMesh.rotation.set(0.4, -0.2, 0.1);
    this.group.add(this.handMesh);
  }

  public setItem(item: ItemType | null) {
    if (this.currentItem === item && this.itemMesh) return;
    this.currentItem = item;

    if (this.itemMesh) {
      this.group.remove(this.itemMesh);
      this.itemMesh.geometry.dispose();
      this.itemMesh = null;
    }

    if (!item) {
      this.handMesh.visible = true;
      return;
    }

    const itemDef = ITEMS[item];
    const isBlock = itemDef?.isBlock && BLOCKS[item as keyof typeof BLOCKS];

    if (isBlock) {
      // Hide bare hand and show mini 3D block
      this.handMesh.visible = false;

      const blockGeo = new THREE.BoxGeometry(0.3, 0.3, 0.3);
      // Generate block UVs
      const uvs: number[] = [];
      for (let f = 0; f < 6; f++) {
        const [u0, v0, u1, v1] = getBlockFaceUV(item as keyof typeof BLOCKS, f as 0 | 1 | 2 | 3 | 4 | 5);
        uvs.push(
          u0, v1,
          u1, v1,
          u0, v0,
          u1, v0
        );
      }
      blockGeo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));

      this.itemMesh = new THREE.Mesh(blockGeo, getAtlasMaterial());
      this.itemMesh.position.set(0.38, -0.32, -0.55);
      this.itemMesh.rotation.set(0.3, -0.5, 0.2);
      this.group.add(this.itemMesh);
    } else {
      // Flat item sprite (tool, food, etc.)
      this.handMesh.visible = true;

      const itemCanvas = getItemCanvas(item);
      const tex = new THREE.CanvasTexture(itemCanvas);
      tex.magFilter = THREE.NearestFilter;
      tex.minFilter = THREE.NearestFilter;

      const spriteMat = new THREE.MeshLambertMaterial({
        map: tex,
        transparent: true,
        alphaTest: 0.1,
        side: THREE.DoubleSide,
      });

      const planeGeo = new THREE.PlaneGeometry(0.45, 0.45);
      this.itemMesh = new THREE.Mesh(planeGeo, spriteMat);
      this.itemMesh.position.set(0.36, -0.28, -0.52);
      this.itemMesh.rotation.set(0.35, -0.4, 0.25);
      this.group.add(this.itemMesh);
    }
  }

  public swing() {
    this.isSwinging = true;
    this.swingProgress = 0;
  }

  public update(dt: number, isMoving: boolean, isSprinting: boolean) {
    // Bobbing animation
    if (isMoving) {
      const speed = isSprinting ? 12 : 7.5;
      this.bobTime += dt * speed;
    } else {
      this.bobTime = 0;
    }

    const bobX = Math.cos(this.bobTime) * 0.025;
    const bobY = Math.abs(Math.sin(this.bobTime)) * 0.035;

    // Swing animation
    let swingOffset = 0;
    let swingRot = 0;
    if (this.isSwinging) {
      this.swingProgress += dt * 6.0;
      if (this.swingProgress >= 1.0) {
        this.isSwinging = false;
        this.swingProgress = 0;
      } else {
        const sinP = Math.sin(this.swingProgress * Math.PI);
        swingOffset = sinP * 0.15;
        swingRot = sinP * 0.8;
      }
    }

    const targetObj = this.itemMesh ? this.itemMesh : this.handMesh;

    if (this.itemMesh) {
      this.itemMesh.position.x = 0.38 + bobX - swingOffset * 0.5;
      this.itemMesh.position.y = -0.32 + bobY - swingOffset;
      this.itemMesh.position.z = -0.55 + swingOffset * 0.5;
      this.itemMesh.rotation.x = 0.3 + swingRot;
      this.itemMesh.rotation.y = -0.5 + swingRot * 0.4;

      // also position hand slightly behind if visible
      if (this.handMesh.visible) {
        this.handMesh.position.set(0.44 + bobX, -0.44 + bobY - swingOffset, -0.62);
      }
    } else {
      this.handMesh.position.x = 0.38 + bobX - swingOffset * 0.5;
      this.handMesh.position.y = -0.4 + bobY - swingOffset;
      this.handMesh.position.z = -0.6 + swingOffset * 0.5;
      this.handMesh.rotation.x = 0.4 + swingRot * 1.2;
      this.handMesh.rotation.y = -0.2 + swingRot * 0.5;
    }
  }
}
