/**
 * High-performance Texture Atlas for Minecraft Web Edition.
 * Combines all block textures into a single 128x128 / 256x256 atlas texture.
 * Enables single-draw-call chunk rendering with 60 FPS performance!
 */

import * as THREE from 'three';
import { BlockType } from '../types/game';
import {
  generateBedrockCanvas,
  generateBookshelfCanvas,
  generateBricksCanvas,
  generateCobblestoneCanvas,
  generateCraftingTableSide,
  generateCraftingTableTop,
  generateDirtCanvas,
  generateDoorCanvas,
  generateFlowerCanvas,
  generateFurnaceFront,
  generateGlassCanvas,
  generateGrassSideCanvas,
  generateGrassTopCanvas,
  generateGravelCanvas,
  generateOakLeavesCanvas,
  generateOakLogSideCanvas,
  generateOakLogTopCanvas,
  generateOakPlanksCanvas,
  generateObsidianCanvas,
  generateOreCanvas,
  generateSandCanvas,
  generateSandstoneCanvas,
  generateStoneCanvas,
  generateTNTCanvas,
  generateTorchCanvas,
  generateWaterCanvas,
} from './textures';

// Face indices: 0: px (+X), 1: nx (-X), 2: py (+Y), 3: ny (-Y), 4: pz (+Z), 5: nz (-Z)
export type FaceIndex = 0 | 1 | 2 | 3 | 4 | 5;

// Total slots in 16x16 grid of 16x16 textures = 256x256 atlas
const ATLAS_SIZE = 16; // 16 tiles across
const TILE_PX = 16;

interface TileCoord {
  col: number;
  row: number;
}

let atlasTexture: THREE.CanvasTexture | null = null;
let atlasCanvas: HTMLCanvasElement | null = null;
let atlasMaterial: THREE.MeshLambertMaterial | null = null;
let waterMaterial: THREE.MeshLambertMaterial | null = null;

// Registry of texture tiles
const tileMap = new Map<string, TileCoord>();
let nextSlot = 0;

function registerTile(id: string, generator: () => HTMLCanvasElement): TileCoord {
  if (tileMap.has(id)) return tileMap.get(id)!;
  const col = nextSlot % ATLAS_SIZE;
  const row = Math.floor(nextSlot / ATLAS_SIZE);
  nextSlot++;
  const coord = { col, row };
  tileMap.set(id, coord);
  return coord;
}

// Pre-register all tiles
const TILES = {
  dirt: registerTile('dirt', generateDirtCanvas),
  grass_top: registerTile('grass_top', generateGrassTopCanvas),
  grass_side: registerTile('grass_side', generateGrassSideCanvas),
  stone: registerTile('stone', generateStoneCanvas),
  cobblestone: registerTile('cobble', generateCobblestoneCanvas),
  bedrock: registerTile('bedrock', generateBedrockCanvas),
  oak_log_side: registerTile('log_side', generateOakLogSideCanvas),
  oak_log_top: registerTile('log_top', generateOakLogTopCanvas),
  oak_planks: registerTile('planks', generateOakPlanksCanvas),
  oak_leaves: registerTile('leaves', generateOakLeavesCanvas),
  sand: registerTile('sand', generateSandCanvas),
  sandstone: registerTile('sandstone', generateSandstoneCanvas),
  gravel: registerTile('gravel', generateGravelCanvas),
  glass: registerTile('glass', generateGlassCanvas),
  bricks: registerTile('bricks', generateBricksCanvas),
  bookshelf_side: registerTile('bookshelf_side', generateBookshelfCanvas),
  tnt_side: registerTile('tnt_side', () => generateTNTCanvas('side')),
  tnt_top: registerTile('tnt_top', () => generateTNTCanvas('top')),
  tnt_bottom: registerTile('tnt_bottom', () => generateTNTCanvas('bottom')),
  obsidian: registerTile('obsidian', generateObsidianCanvas),
  diamond_ore: registerTile('ore_diamond', () => generateOreCanvas([78, 235, 230])),
  iron_ore: registerTile('ore_iron', () => generateOreCanvas([216, 175, 147])),
  coal_ore: registerTile('ore_coal', () => generateOreCanvas([40, 40, 40])),
  gold_ore: registerTile('ore_gold', () => generateOreCanvas([255, 215, 0])),
  redstone_ore: registerTile('ore_redstone', () => generateOreCanvas([230, 20, 20])),
  craft_top: registerTile('craft_top', generateCraftingTableTop),
  craft_side: registerTile('craft_side', generateCraftingTableSide),
  furnace_front: registerTile('furnace_front', generateFurnaceFront),
  torch: registerTile('torch', generateTorchCanvas),
  dandelion: registerTile('dandelion', () => generateFlowerCanvas('dandelion')),
  rose: registerTile('rose', () => generateFlowerCanvas('rose')),
  water: registerTile('water', generateWaterCanvas),
  door: registerTile('door', generateDoorCanvas),
};

export function initAtlas(): THREE.CanvasTexture {
  if (atlasTexture) return atlasTexture;

  atlasCanvas = document.createElement('canvas');
  atlasCanvas.width = ATLAS_SIZE * TILE_PX;
  atlasCanvas.height = ATLAS_SIZE * TILE_PX;
  const ctx = atlasCanvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;

  // Draw all registered tiles
  const generators: Record<string, () => HTMLCanvasElement> = {
    dirt: generateDirtCanvas,
    grass_top: generateGrassTopCanvas,
    grass_side: generateGrassSideCanvas,
    stone: generateStoneCanvas,
    cobble: generateCobblestoneCanvas,
    bedrock: generateBedrockCanvas,
    log_side: generateOakLogSideCanvas,
    log_top: generateOakLogTopCanvas,
    planks: generateOakPlanksCanvas,
    leaves: generateOakLeavesCanvas,
    sand: generateSandCanvas,
    sandstone: generateSandstoneCanvas,
    gravel: generateGravelCanvas,
    glass: generateGlassCanvas,
    bricks: generateBricksCanvas,
    bookshelf_side: generateBookshelfCanvas,
    tnt_side: () => generateTNTCanvas('side'),
    tnt_top: () => generateTNTCanvas('top'),
    tnt_bottom: () => generateTNTCanvas('bottom'),
    obsidian: generateObsidianCanvas,
    ore_diamond: () => generateOreCanvas([78, 235, 230]),
    ore_iron: () => generateOreCanvas([216, 175, 147]),
    ore_coal: () => generateOreCanvas([40, 40, 40]),
    ore_gold: () => generateOreCanvas([255, 215, 0]),
    ore_redstone: () => generateOreCanvas([230, 20, 20]),
    craft_top: generateCraftingTableTop,
    craft_side: generateCraftingTableSide,
    furnace_front: generateFurnaceFront,
    torch: generateTorchCanvas,
    dandelion: () => generateFlowerCanvas('dandelion'),
    rose: () => generateFlowerCanvas('rose'),
    water: generateWaterCanvas,
    door: generateDoorCanvas,
  };

  tileMap.forEach((coord, id) => {
    const gen = generators[id];
    if (gen) {
      const tile = gen();
      ctx.drawImage(tile, coord.col * TILE_PX, coord.row * TILE_PX);
    }
  });

  atlasTexture = new THREE.CanvasTexture(atlasCanvas);
  atlasTexture.magFilter = THREE.NearestFilter;
  atlasTexture.minFilter = THREE.NearestFilter;
  atlasTexture.colorSpace = THREE.SRGBColorSpace;
  return atlasTexture;
}

export function getAtlasMaterial(): THREE.MeshLambertMaterial {
  if (atlasMaterial) return atlasMaterial;
  const tex = initAtlas();
  atlasMaterial = new THREE.MeshLambertMaterial({
    map: tex,
    transparent: true,
    alphaTest: 0.2,
    side: THREE.FrontSide,
  });
  return atlasMaterial;
}

export function getWaterMaterial(): THREE.MeshLambertMaterial {
  if (waterMaterial) return waterMaterial;
  const tex = initAtlas();
  waterMaterial = new THREE.MeshLambertMaterial({
    map: tex,
    transparent: true,
    opacity: 0.65,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  return waterMaterial;
}

// Return UV coordinates [u0, v0, u1, v1] for a specific block and face
export function getBlockFaceUV(block: BlockType, face: FaceIndex): [number, number, number, number] {
  let tile: TileCoord = TILES.stone;

  switch (block) {
    case 'grass':
      if (face === 2) tile = TILES.grass_top;
      else if (face === 3) tile = TILES.dirt;
      else tile = TILES.grass_side;
      break;
    case 'dirt':
      tile = TILES.dirt;
      break;
    case 'stone':
      tile = TILES.stone;
      break;
    case 'cobblestone':
      tile = TILES.cobblestone;
      break;
    case 'bedrock':
      tile = TILES.bedrock;
      break;
    case 'oak_log':
      if (face === 2 || face === 3) tile = TILES.oak_log_top;
      else tile = TILES.oak_log_side;
      break;
    case 'oak_planks':
      tile = TILES.oak_planks;
      break;
    case 'oak_leaves':
      tile = TILES.oak_leaves;
      break;
    case 'sand':
      tile = TILES.sand;
      break;
    case 'sandstone':
      tile = TILES.sandstone;
      break;
    case 'gravel':
      tile = TILES.gravel;
      break;
    case 'glass':
      tile = TILES.glass;
      break;
    case 'bricks':
      tile = TILES.bricks;
      break;
    case 'bookshelf':
      if (face === 2 || face === 3) tile = TILES.oak_planks;
      else tile = TILES.bookshelf_side;
      break;
    case 'tnt':
      if (face === 2) tile = TILES.tnt_top;
      else if (face === 3) tile = TILES.tnt_bottom;
      else tile = TILES.tnt_side;
      break;
    case 'obsidian':
      tile = TILES.obsidian;
      break;
    case 'diamond_ore':
      tile = TILES.diamond_ore;
      break;
    case 'iron_ore':
      tile = TILES.iron_ore;
      break;
    case 'coal_ore':
      tile = TILES.coal_ore;
      break;
    case 'gold_ore':
      tile = TILES.gold_ore;
      break;
    case 'redstone_ore':
      tile = TILES.redstone_ore;
      break;
    case 'crafting_table':
      if (face === 2) tile = TILES.craft_top;
      else if (face === 3) tile = TILES.oak_planks;
      else tile = TILES.craft_side;
      break;
    case 'furnace':
      if (face === 4) tile = TILES.furnace_front;
      else if (face === 2 || face === 3) tile = TILES.stone;
      else tile = TILES.cobblestone;
      break;
    case 'chest':
      if (face === 4) tile = TILES.furnace_front; // chest front
      else tile = TILES.oak_planks;
      break;
    case 'torch':
      tile = TILES.torch;
      break;
    case 'dandelion':
      tile = TILES.dandelion;
      break;
    case 'rose':
      tile = TILES.rose;
      break;
    case 'water':
      tile = TILES.water;
      break;
    case 'oak_door':
      tile = TILES.door;
      break;
    default:
      tile = TILES.stone;
  }

  const u0 = tile.col / ATLAS_SIZE;
  const u1 = (tile.col + 1) / ATLAS_SIZE;
  // Three.js UV origin is bottom-left
  const v1 = 1 - tile.row / ATLAS_SIZE;
  const v0 = 1 - (tile.row + 1) / ATLAS_SIZE;

  return [u0, v0, u1, v1];
}
