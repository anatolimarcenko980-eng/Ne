/**
 * Procedural 16x16 Minecraft Pixel-Art Texture Generator using Three.js CanvasTexture.
 * Crisp nearest-neighbor pixelated rendering, no external assets needed!
 */

import * as THREE from 'three';
import { BlockType, ItemType } from '../types/game';

// Helper to create a 16x16 2D canvas
function createPixelCanvas(): { canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D } {
  const canvas = document.createElement('canvas');
  canvas.width = 16;
  canvas.height = 16;
  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;
  return { canvas, ctx };
}

// Helper to draw random variations of a base color
function noiseColor(r: number, g: number, b: number, variance: number): string {
  const v = (Math.random() - 0.5) * variance;
  const clamp = (val: number) => Math.max(0, Math.min(255, Math.floor(val)));
  return `rgb(${clamp(r + v)},${clamp(g + v)},${clamp(b + v)})`;
}

// Generate data URL or CanvasTexture
const textureCache: Map<string, THREE.CanvasTexture> = new Map();
const dataUrlCache: Map<string, string> = new Map();

export function getTexture(key: string, generator: () => HTMLCanvasElement): THREE.CanvasTexture {
  if (textureCache.has(key)) {
    return textureCache.get(key)!;
  }
  const canvas = generator();
  const texture = new THREE.CanvasTexture(canvas);
  texture.magFilter = THREE.NearestFilter;
  texture.minFilter = THREE.NearestFilter;
  texture.colorSpace = THREE.SRGBColorSpace;
  textureCache.set(key, texture);
  return texture;
}

export function getItemDataUrl(item: ItemType): string {
  if (dataUrlCache.has(item)) {
    return dataUrlCache.get(item)!;
  }
  const canvas = getItemCanvas(item);
  const url = canvas.toDataURL();
  dataUrlCache.set(item, url);
  return url;
}

// --- Textures for Blocks ---

export function generateDirtCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      ctx.fillStyle = noiseColor(134, 96, 67, 30);
      ctx.fillRect(x, y, 1, 1);
    }
  }
  return canvas;
}

export function generateGrassTopCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      ctx.fillStyle = noiseColor(88, 168, 52, 28);
      ctx.fillRect(x, y, 1, 1);
    }
  }
  return canvas;
}

export function generateGrassSideCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  // Dirt bottom
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      ctx.fillStyle = noiseColor(134, 96, 67, 30);
      ctx.fillRect(x, y, 1, 1);
    }
  }
  // Grass rim on top with dripping edges
  for (let x = 0; x < 16; x++) {
    const depth = 2 + (x % 3 === 0 ? 2 : x % 2 === 0 ? 1 : 0);
    for (let y = 0; y <= depth; y++) {
      ctx.fillStyle = noiseColor(88, 168, 52, 28);
      ctx.fillRect(x, y, 1, 1);
    }
  }
  return canvas;
}

export function generateStoneCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      ctx.fillStyle = noiseColor(122, 122, 122, 25);
      ctx.fillRect(x, y, 1, 1);
    }
  }
  return canvas;
}

export function generateCobblestoneCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      const isMortar = (x + y) % 4 === 0 || (x % 4 === 0 && y % 3 === 0);
      if (isMortar) {
        ctx.fillStyle = noiseColor(65, 65, 65, 15);
      } else {
        ctx.fillStyle = noiseColor(130, 130, 130, 35);
      }
      ctx.fillRect(x, y, 1, 1);
    }
  }
  return canvas;
}

export function generateBedrockCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      ctx.fillStyle = noiseColor(30, 30, 30, 35);
      ctx.fillRect(x, y, 1, 1);
    }
  }
  return canvas;
}

export function generateOakLogSideCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  for (let x = 0; x < 16; x++) {
    const isBarkGroove = x % 4 === 0;
    for (let y = 0; y < 16; y++) {
      if (isBarkGroove) {
        ctx.fillStyle = noiseColor(65, 45, 27, 20);
      } else {
        ctx.fillStyle = noiseColor(105, 78, 48, 25);
      }
      ctx.fillRect(x, y, 1, 1);
    }
  }
  return canvas;
}

export function generateOakLogTopCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      const dist = Math.sqrt((x - 7.5) ** 2 + (y - 7.5) ** 2);
      if (dist > 6.5) {
        ctx.fillStyle = noiseColor(75, 52, 32, 20); // bark ring
      } else if (dist > 4.5 && dist < 5.5) {
        ctx.fillStyle = noiseColor(140, 110, 70, 20); // growth ring
      } else if (dist > 2 && dist < 3) {
        ctx.fillStyle = noiseColor(145, 115, 75, 20);
      } else {
        ctx.fillStyle = noiseColor(175, 142, 98, 25); // heartwood
      }
      ctx.fillRect(x, y, 1, 1);
    }
  }
  return canvas;
}

export function generateOakPlanksCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  for (let y = 0; y < 16; y++) {
    const isSeam = y % 4 === 0;
    for (let x = 0; x < 16; x++) {
      if (isSeam) {
        ctx.fillStyle = '#6e4f2e';
      } else {
        ctx.fillStyle = noiseColor(165, 128, 80, 20);
      }
      ctx.fillRect(x, y, 1, 1);
    }
  }
  // add plank dividing lines
  ctx.fillStyle = '#6e4f2e';
  ctx.fillRect(7, 0, 1, 4);
  ctx.fillRect(11, 4, 1, 4);
  ctx.fillRect(4, 8, 1, 4);
  ctx.fillRect(13, 12, 1, 4);
  return canvas;
}

export function generateOakLeavesCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  ctx.clearRect(0, 0, 16, 16);
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      if ((x * 7 + y * 13) % 5 === 0) {
        // slight cutouts/transparency for classic leaf foliage
        ctx.fillStyle = 'rgba(0, 0, 0, 0)';
      } else {
        ctx.fillStyle = noiseColor(45, 125, 30, 35);
        ctx.fillRect(x, y, 1, 1);
      }
    }
  }
  return canvas;
}

export function generateSandCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      ctx.fillStyle = noiseColor(219, 205, 148, 25);
      ctx.fillRect(x, y, 1, 1);
    }
  }
  return canvas;
}

export function generateSandstoneCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      if (y === 0 || y === 15) {
        ctx.fillStyle = '#bfae77';
      } else {
        ctx.fillStyle = noiseColor(215, 198, 140, 18);
      }
      ctx.fillRect(x, y, 1, 1);
    }
  }
  return canvas;
}

export function generateGravelCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      ctx.fillStyle = noiseColor(120, 115, 115, 45);
      ctx.fillRect(x, y, 1, 1);
    }
  }
  return canvas;
}

export function generateGlassCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  ctx.clearRect(0, 0, 16, 16);
  ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
  ctx.fillRect(0, 0, 16, 16);

  // Border
  ctx.fillStyle = 'rgba(220, 240, 255, 0.7)';
  ctx.strokeRect(0.5, 0.5, 15, 15);

  // Highlight glints
  ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
  ctx.fillRect(2, 2, 2, 2);
  ctx.fillRect(4, 4, 1, 1);
  ctx.fillRect(3, 8, 1, 1);
  ctx.fillRect(11, 11, 2, 2);
  return canvas;
}

export function generateBricksCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  ctx.fillStyle = '#b7b7b7'; // Mortar
  ctx.fillRect(0, 0, 16, 16);

  for (let row = 0; row < 4; row++) {
    const y = row * 4;
    const offset = (row % 2) * 4;
    for (let col = -1; col < 3; col++) {
      const x = col * 8 + offset;
      for (let by = y + 1; by < y + 4; by++) {
        for (let bx = x + 1; bx < x + 8; bx++) {
          if (bx >= 0 && bx < 16 && by >= 0 && by < 16) {
            ctx.fillStyle = noiseColor(155, 68, 55, 22);
            ctx.fillRect(bx, by, 1, 1);
          }
        }
      }
    }
  }
  return canvas;
}

export function generateBookshelfCanvas(): HTMLCanvasElement {
  const canvas = generateOakPlanksCanvas();
  const ctx = canvas.getContext('2d')!;

  // Bookshelf cavity
  ctx.fillStyle = '#2e1e12';
  ctx.fillRect(1, 2, 14, 5);
  ctx.fillRect(1, 9, 14, 5);

  const bookColors = ['#9e2a2b', '#2a5a9e', '#2b7a35', '#b3822a', '#78358e'];
  // Upper shelf books
  for (let x = 2; x < 14; x += 2) {
    ctx.fillStyle = bookColors[(x * 3) % bookColors.length];
    ctx.fillRect(x, 2, 1.8, 5);
    ctx.fillStyle = '#d4c79b';
    ctx.fillRect(x, 3, 1.8, 1);
  }
  // Lower shelf books
  for (let x = 2; x < 14; x += 2) {
    ctx.fillStyle = bookColors[(x * 5) % bookColors.length];
    ctx.fillRect(x, 9, 1.8, 5);
    ctx.fillStyle = '#d4c79b';
    ctx.fillRect(x, 12, 1.8, 1);
  }
  return canvas;
}

export function generateTNTCanvas(type: 'side' | 'top' | 'bottom'): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  if (type === 'top' || type === 'bottom') {
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        ctx.fillStyle = noiseColor(185, 45, 30, 20);
        ctx.fillRect(x, y, 1, 1);
      }
    }
    if (type === 'top') {
      ctx.fillStyle = '#222';
      ctx.fillRect(7, 7, 2, 2);
      ctx.fillStyle = '#777';
      ctx.fillRect(8, 6, 1, 2);
    }
    return canvas;
  }

  // Side
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      if (y >= 5 && y <= 10) {
        ctx.fillStyle = '#f0f0f0'; // White band
      } else {
        ctx.fillStyle = noiseColor(185, 45, 30, 20);
      }
      ctx.fillRect(x, y, 1, 1);
    }
  }

  // Draw "TNT" pixel letters
  ctx.fillStyle = '#000000';
  // T
  ctx.fillRect(2, 6, 3, 1);
  ctx.fillRect(3, 7, 1, 3);
  // N
  ctx.fillRect(6, 6, 1, 4);
  ctx.fillRect(7, 7, 1, 1);
  ctx.fillRect(8, 8, 1, 1);
  ctx.fillRect(9, 6, 1, 4);
  // T
  ctx.fillRect(11, 6, 3, 1);
  ctx.fillRect(12, 7, 1, 3);

  return canvas;
}

export function generateObsidianCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      const isPurple = (x * y + x) % 7 === 0;
      if (isPurple) {
        ctx.fillStyle = noiseColor(45, 20, 65, 18);
      } else {
        ctx.fillStyle = noiseColor(20, 15, 30, 15);
      }
      ctx.fillRect(x, y, 1, 1);
    }
  }
  return canvas;
}

export function generateOreCanvas(oreColor: [number, number, number]): HTMLCanvasElement {
  const canvas = generateStoneCanvas();
  const ctx = canvas.getContext('2d')!;

  const spots = [
    [4, 3], [5, 3], [4, 4],
    [10, 4], [11, 4], [10, 5],
    [3, 10], [4, 10], [4, 11],
    [11, 10], [12, 11], [11, 12],
    [7, 7], [8, 7], [8, 8],
  ];

  spots.forEach(([x, y]) => {
    ctx.fillStyle = noiseColor(oreColor[0], oreColor[1], oreColor[2], 25);
    ctx.fillRect(x, y, 1, 1);
  });

  return canvas;
}

export function generateCraftingTableTop(): HTMLCanvasElement {
  const canvas = generateOakPlanksCanvas();
  const ctx = canvas.getContext('2d')!;

  // Dark border
  ctx.strokeStyle = '#4a331c';
  ctx.lineWidth = 1;
  ctx.strokeRect(1.5, 1.5, 13, 13);

  // 3x3 grid
  ctx.beginPath();
  for (let i = 5; i <= 11; i += 4) {
    ctx.moveTo(i, 2);
    ctx.lineTo(i, 14);
    ctx.moveTo(2, i);
    ctx.lineTo(14, i);
  }
  ctx.strokeStyle = '#5a3d21';
  ctx.stroke();

  return canvas;
}

export function generateCraftingTableSide(): HTMLCanvasElement {
  const canvas = generateOakPlanksCanvas();
  const ctx = canvas.getContext('2d')!;

  // Draw tools on side
  ctx.fillStyle = '#8b5a2b';
  ctx.fillRect(3, 4, 10, 8);
  ctx.fillStyle = '#404040';
  ctx.fillRect(5, 5, 2, 6);
  ctx.fillRect(9, 7, 2, 4);

  return canvas;
}

export function generateFurnaceFront(): HTMLCanvasElement {
  const canvas = generateCobblestoneCanvas();
  const ctx = canvas.getContext('2d')!;

  // Opening
  ctx.fillStyle = '#222222';
  ctx.fillRect(3, 5, 10, 8);
  ctx.fillStyle = '#111111';
  ctx.fillRect(4, 6, 8, 6);

  return canvas;
}

export function generateChestFront(): HTMLCanvasElement {
  const canvas = generateOakPlanksCanvas();
  const ctx = canvas.getContext('2d')!;

  // Trim
  ctx.strokeStyle = '#382512';
  ctx.strokeRect(1.5, 1.5, 13, 13);
  // Latch
  ctx.fillStyle = '#c0c0c0';
  ctx.fillRect(7, 6, 2, 4);
  ctx.fillStyle = '#333333';
  ctx.fillRect(7, 8, 2, 1);

  return canvas;
}

export function generateTorchCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  ctx.clearRect(0, 0, 16, 16);

  // Wooden stick
  ctx.fillStyle = '#6b4723';
  ctx.fillRect(7, 5, 2, 9);

  // Flame head
  ctx.fillStyle = '#d97d20';
  ctx.fillRect(6, 2, 4, 3);
  ctx.fillStyle = '#ffd13b';
  ctx.fillRect(7, 1, 2, 3);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(7, 2, 1, 1);

  return canvas;
}

export function generateFlowerCanvas(type: 'dandelion' | 'rose'): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  ctx.clearRect(0, 0, 16, 16);

  // Stem
  ctx.fillStyle = '#2e7d32';
  ctx.fillRect(7, 6, 2, 9);
  ctx.fillRect(5, 10, 2, 2);
  ctx.fillRect(9, 8, 2, 2);

  // Petals
  const petColor = type === 'rose' ? '#d32f2f' : '#fbc02d';
  const centerColor = type === 'rose' ? '#8b0000' : '#f57f17';

  ctx.fillStyle = petColor;
  ctx.fillRect(6, 2, 4, 4);
  ctx.fillStyle = centerColor;
  ctx.fillRect(7, 3, 2, 2);

  return canvas;
}

export function generateWaterCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      ctx.fillStyle = noiseColor(40, 95, 215, 25);
      ctx.fillRect(x, y, 1, 1);
    }
  }
  return canvas;
}

export function generateDoorCanvas(): HTMLCanvasElement {
  const canvas = generateOakPlanksCanvas();
  const ctx = canvas.getContext('2d')!;

  // Window slit
  ctx.fillStyle = '#111111';
  ctx.fillRect(4, 3, 3, 4);
  ctx.fillRect(9, 3, 3, 4);

  // Handle
  ctx.fillStyle = '#e6b800';
  ctx.fillRect(12, 9, 2, 2);

  return canvas;
}

// Crack stages (0-9)
export function generateCrackCanvas(stage: number): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  ctx.clearRect(0, 0, 16, 16);
  ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';

  const step = Math.min(9, Math.max(0, stage));
  const count = (step + 1) * 3;

  for (let i = 0; i < count; i++) {
    const x = Math.floor(Math.abs(Math.sin(i * 12.3)) * 14) + 1;
    const y = Math.floor(Math.abs(Math.cos(i * 7.7)) * 14) + 1;
    ctx.fillRect(x, y, 1, 1);
    ctx.fillRect(x + 1, y, 1, 1);
    if (i % 2 === 0) {
      ctx.fillRect(x, y + 1, 1, 1);
    }
  }

  return canvas;
}

// Map BlockType to 6 materials [px, nx, py, ny, pz, nz] = [right, left, top, bottom, front, back]
export function getBlockMaterials(block: BlockType): THREE.Material[] {
  const cacheKey = `mats_${block}`;
  // We construct standard MeshLambertMaterials
  const makeMat = (tex: THREE.CanvasTexture, transparent = false, opacity = 1.0) =>
    new THREE.MeshLambertMaterial({
      map: tex,
      transparent,
      opacity,
      alphaTest: transparent ? 0.1 : 0,
    });

  switch (block) {
    case 'grass': {
      const top = getTexture('grass_top', generateGrassTopCanvas);
      const side = getTexture('grass_side', generateGrassSideCanvas);
      const bottom = getTexture('dirt', generateDirtCanvas);
      return [makeMat(side), makeMat(side), makeMat(top), makeMat(bottom), makeMat(side), makeMat(side)];
    }
    case 'dirt': {
      const dirt = getTexture('dirt', generateDirtCanvas);
      return Array(6).fill(null).map(() => makeMat(dirt));
    }
    case 'stone': {
      const stone = getTexture('stone', generateStoneCanvas);
      return Array(6).fill(null).map(() => makeMat(stone));
    }
    case 'cobblestone': {
      const cobble = getTexture('cobble', generateCobblestoneCanvas);
      return Array(6).fill(null).map(() => makeMat(cobble));
    }
    case 'bedrock': {
      const bedrock = getTexture('bedrock', generateBedrockCanvas);
      return Array(6).fill(null).map(() => makeMat(bedrock));
    }
    case 'oak_log': {
      const side = getTexture('oak_log_side', generateOakLogSideCanvas);
      const top = getTexture('oak_log_top', generateOakLogTopCanvas);
      return [makeMat(side), makeMat(side), makeMat(top), makeMat(top), makeMat(side), makeMat(side)];
    }
    case 'oak_planks': {
      const planks = getTexture('oak_planks', generateOakPlanksCanvas);
      return Array(6).fill(null).map(() => makeMat(planks));
    }
    case 'oak_leaves': {
      const leaves = getTexture('oak_leaves', generateOakLeavesCanvas);
      return Array(6).fill(null).map(() => makeMat(leaves, true, 0.95));
    }
    case 'sand': {
      const sand = getTexture('sand', generateSandCanvas);
      return Array(6).fill(null).map(() => makeMat(sand));
    }
    case 'sandstone': {
      const sandstone = getTexture('sandstone', generateSandstoneCanvas);
      return Array(6).fill(null).map(() => makeMat(sandstone));
    }
    case 'gravel': {
      const gravel = getTexture('gravel', generateGravelCanvas);
      return Array(6).fill(null).map(() => makeMat(gravel));
    }
    case 'glass': {
      const glass = getTexture('glass', generateGlassCanvas);
      return Array(6).fill(null).map(() => makeMat(glass, true, 0.4));
    }
    case 'bricks': {
      const bricks = getTexture('bricks', generateBricksCanvas);
      return Array(6).fill(null).map(() => makeMat(bricks));
    }
    case 'bookshelf': {
      const side = getTexture('bookshelf', generateBookshelfCanvas);
      const top = getTexture('oak_planks', generateOakPlanksCanvas);
      return [makeMat(side), makeMat(side), makeMat(top), makeMat(top), makeMat(side), makeMat(side)];
    }
    case 'tnt': {
      const side = getTexture('tnt_side', () => generateTNTCanvas('side'));
      const top = getTexture('tnt_top', () => generateTNTCanvas('top'));
      const bottom = getTexture('tnt_bottom', () => generateTNTCanvas('bottom'));
      return [makeMat(side), makeMat(side), makeMat(top), makeMat(bottom), makeMat(side), makeMat(side)];
    }
    case 'obsidian': {
      const obsidian = getTexture('obsidian', generateObsidianCanvas);
      return Array(6).fill(null).map(() => makeMat(obsidian));
    }
    case 'diamond_ore': {
      const ore = getTexture('ore_diamond', () => generateOreCanvas([78, 235, 230]));
      return Array(6).fill(null).map(() => makeMat(ore));
    }
    case 'iron_ore': {
      const ore = getTexture('ore_iron', () => generateOreCanvas([216, 175, 147]));
      return Array(6).fill(null).map(() => makeMat(ore));
    }
    case 'coal_ore': {
      const ore = getTexture('ore_coal', () => generateOreCanvas([40, 40, 40]));
      return Array(6).fill(null).map(() => makeMat(ore));
    }
    case 'gold_ore': {
      const ore = getTexture('ore_gold', () => generateOreCanvas([255, 215, 0]));
      return Array(6).fill(null).map(() => makeMat(ore));
    }
    case 'redstone_ore': {
      const ore = getTexture('ore_redstone', () => generateOreCanvas([230, 20, 20]));
      return Array(6).fill(null).map(() => makeMat(ore));
    }
    case 'crafting_table': {
      const top = getTexture('craft_top', generateCraftingTableTop);
      const side = getTexture('craft_side', generateCraftingTableSide);
      const bottom = getTexture('oak_planks', generateOakPlanksCanvas);
      return [makeMat(side), makeMat(side), makeMat(top), makeMat(bottom), makeMat(side), makeMat(side)];
    }
    case 'furnace': {
      const front = getTexture('furnace_front', generateFurnaceFront);
      const cobble = getTexture('cobble', generateCobblestoneCanvas);
      return [makeMat(cobble), makeMat(cobble), makeMat(cobble), makeMat(cobble), makeMat(front), makeMat(cobble)];
    }
    case 'chest': {
      const front = getTexture('chest_front', generateChestFront);
      const side = getTexture('oak_planks', generateOakPlanksCanvas);
      return [makeMat(side), makeMat(side), makeMat(side), makeMat(side), makeMat(front), makeMat(side)];
    }
    case 'water': {
      const water = getTexture('water', generateWaterCanvas);
      return Array(6).fill(null).map(() => makeMat(water, true, 0.6));
    }
    case 'oak_door': {
      const door = getTexture('door', generateDoorCanvas);
      return Array(6).fill(null).map(() => makeMat(door));
    }
    default: {
      const stone = getTexture('stone', generateStoneCanvas);
      return Array(6).fill(null).map(() => makeMat(stone));
    }
  }
}

// Generate item sprite for 2D UI slots
export function getItemCanvas(item: ItemType): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  ctx.clearRect(0, 0, 16, 16);

  // If it's a block type, render mini isometric cube or frontal view
  if (
    item === 'grass' || item === 'dirt' || item === 'stone' || item === 'cobblestone' ||
    item === 'bedrock' || item === 'oak_log' || item === 'oak_planks' || item === 'oak_leaves' ||
    item === 'sand' || item === 'sandstone' || item === 'gravel' || item === 'glass' ||
    item === 'bricks' || item === 'bookshelf' || item === 'tnt' || item === 'obsidian' ||
    item === 'diamond_ore' || item === 'iron_ore' || item === 'coal_ore' || item === 'gold_ore' ||
    item === 'redstone_ore' || item === 'crafting_table' || item === 'furnace' || item === 'chest'
  ) {
    // Mini isometric voxel block icon
    // Top face
    let topColor = '#58a834';
    let leftColor = '#866043';
    let rightColor = '#6e4f37';

    if (item === 'stone') {
      topColor = '#8a8a8a'; leftColor = '#6a6a6a'; rightColor = '#525252';
    } else if (item === 'cobblestone') {
      topColor = '#7a7a7a'; leftColor = '#5a5a5a'; rightColor = '#4a4a4a';
    } else if (item === 'oak_planks') {
      topColor = '#b88b56'; leftColor = '#9a6f3d'; rightColor = '#7d582e';
    } else if (item === 'oak_log') {
      topColor = '#a78453'; leftColor = '#604427'; rightColor = '#46311b';
    } else if (item === 'oak_leaves') {
      topColor = '#3e8e2b'; leftColor = '#2b6e1b'; rightColor = '#1f5313';
    } else if (item === 'sand') {
      topColor = '#e3d59e'; leftColor = '#c7b77b'; rightColor = '#aa9b62';
    } else if (item === 'glass') {
      topColor = 'rgba(200, 230, 255, 0.7)'; leftColor = 'rgba(150, 190, 220, 0.7)'; rightColor = 'rgba(110, 150, 180, 0.7)';
    } else if (item === 'tnt') {
      topColor = '#b32c1c'; leftColor = '#d93b27'; rightColor = '#941f12';
    } else if (item === 'diamond_ore') {
      topColor = '#8a8a8a'; leftColor = '#6a6a6a'; rightColor = '#525252';
    } else if (item === 'iron_ore') {
      topColor = '#8a8a8a'; leftColor = '#6a6a6a'; rightColor = '#525252';
    } else if (item === 'crafting_table') {
      topColor = '#b88b56'; leftColor = '#8b5a2b'; rightColor = '#6e4620';
    } else if (item === 'furnace') {
      topColor = '#7a7a7a'; leftColor = '#3a3a3a'; rightColor = '#5a5a5a';
    } else if (item === 'chest') {
      topColor = '#b88b56'; leftColor = '#8a5c2b'; rightColor = '#6f471e';
    }

    // Draw cube
    ctx.fillStyle = topColor;
    ctx.beginPath();
    ctx.moveTo(8, 2);
    ctx.lineTo(14, 5);
    ctx.lineTo(8, 8);
    ctx.lineTo(2, 5);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = leftColor;
    ctx.beginPath();
    ctx.moveTo(2, 5);
    ctx.lineTo(8, 8);
    ctx.lineTo(8, 14);
    ctx.lineTo(2, 11);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = rightColor;
    ctx.beginPath();
    ctx.moveTo(8, 8);
    ctx.lineTo(14, 5);
    ctx.lineTo(14, 11);
    ctx.lineTo(8, 14);
    ctx.closePath();
    ctx.fill();

    // Specular / ore glint
    if (item === 'diamond_ore') {
      ctx.fillStyle = '#4eebe6';
      ctx.fillRect(4, 7, 2, 2);
      ctx.fillRect(10, 8, 2, 2);
    } else if (item === 'iron_ore') {
      ctx.fillStyle = '#d8af93';
      ctx.fillRect(4, 7, 2, 2);
      ctx.fillRect(10, 8, 2, 2);
    } else if (item === 'gold_ore') {
      ctx.fillStyle = '#ffd700';
      ctx.fillRect(4, 7, 2, 2);
      ctx.fillRect(10, 8, 2, 2);
    } else if (item === 'coal_ore') {
      ctx.fillStyle = '#111';
      ctx.fillRect(4, 7, 2, 2);
      ctx.fillRect(10, 8, 2, 2);
    }

    return canvas;
  }

  // Flowers / Torch
  if (item === 'torch') {
    return generateTorchCanvas();
  }
  if (item === 'dandelion') {
    return generateFlowerCanvas('dandelion');
  }
  if (item === 'rose') {
    return generateFlowerCanvas('rose');
  }

  // Tools & Items
  if (item === 'stick') {
    ctx.fillStyle = '#6b4723';
    for (let i = 0; i < 10; i++) {
      ctx.fillRect(3 + i, 12 - i, 2, 2);
    }
    return canvas;
  }

  if (item === 'coal') {
    ctx.fillStyle = '#222222';
    ctx.beginPath();
    ctx.arc(8, 8, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#444444';
    ctx.fillRect(6, 6, 3, 2);
    return canvas;
  }

  if (item === 'iron_ingot' || item === 'gold_ingot') {
    const isGold = item === 'gold_ingot';
    ctx.fillStyle = isGold ? '#d4af37' : '#c0c0c0';
    ctx.fillRect(3, 6, 10, 5);
    ctx.fillStyle = isGold ? '#ffd700' : '#e0e0e0';
    ctx.fillRect(4, 7, 8, 2);
    return canvas;
  }

  if (item === 'diamond') {
    ctx.fillStyle = '#4eebe6';
    ctx.beginPath();
    ctx.moveTo(8, 2);
    ctx.lineTo(13, 6);
    ctx.lineTo(8, 14);
    ctx.lineTo(3, 6);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#a6f7f5';
    ctx.fillRect(7, 5, 2, 3);
    return canvas;
  }

  if (item.includes('pickaxe')) {
    const matColor = item.includes('diamond') ? '#4eebe6' : item.includes('iron') ? '#d4d4d4' : item.includes('stone') ? '#888888' : '#a06e3b';
    // Stick
    ctx.fillStyle = '#6b4723';
    for (let i = 0; i < 9; i++) {
      ctx.fillRect(2 + i, 13 - i, 2, 2);
    }
    // Head
    ctx.fillStyle = matColor;
    ctx.fillRect(8, 2, 6, 2);
    ctx.fillRect(12, 3, 2, 4);
    ctx.fillRect(6, 4, 3, 2);
    ctx.fillRect(5, 6, 2, 2);
    return canvas;
  }

  if (item.includes('sword')) {
    const matColor = item.includes('diamond') ? '#4eebe6' : item.includes('iron') ? '#d4d4d4' : item.includes('stone') ? '#888888' : '#a06e3b';
    // Blade
    ctx.fillStyle = matColor;
    for (let i = 0; i < 9; i++) {
      ctx.fillRect(4 + i, 11 - i, 2, 2);
    }
    // Guard
    ctx.fillStyle = '#4a331c';
    ctx.fillRect(4, 11, 4, 2);
    ctx.fillRect(3, 12, 2, 2);
    // Hilt
    ctx.fillStyle = '#6b4723';
    ctx.fillRect(2, 13, 2, 2);
    return canvas;
  }

  if (item.includes('axe')) {
    const matColor = item.includes('diamond') ? '#4eebe6' : item.includes('iron') ? '#d4d4d4' : item.includes('stone') ? '#888888' : '#a06e3b';
    ctx.fillStyle = '#6b4723';
    for (let i = 0; i < 9; i++) {
      ctx.fillRect(2 + i, 13 - i, 2, 2);
    }
    ctx.fillStyle = matColor;
    ctx.fillRect(8, 2, 5, 4);
    ctx.fillRect(10, 6, 3, 3);
    return canvas;
  }

  if (item.includes('shovel')) {
    const matColor = item.includes('diamond') ? '#4eebe6' : item.includes('iron') ? '#d4d4d4' : item.includes('stone') ? '#888888' : '#a06e3b';
    ctx.fillStyle = '#6b4723';
    for (let i = 0; i < 9; i++) {
      ctx.fillRect(2 + i, 13 - i, 2, 2);
    }
    ctx.fillStyle = matColor;
    ctx.fillRect(10, 2, 4, 4);
    return canvas;
  }

  if (item === 'apple') {
    ctx.fillStyle = '#d32f2f';
    ctx.beginPath();
    ctx.arc(8, 9, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#4caf50';
    ctx.fillRect(8, 2, 1, 3);
    return canvas;
  }

  if (item === 'bread') {
    ctx.fillStyle = '#c79145';
    ctx.fillRect(2, 6, 12, 5);
    ctx.fillStyle = '#8f5c23';
    ctx.fillRect(4, 7, 2, 3);
    ctx.fillRect(7, 7, 2, 3);
    ctx.fillRect(10, 7, 2, 3);
    return canvas;
  }

  if (item === 'raw_porkchop' || item === 'cooked_porkchop') {
    ctx.fillStyle = item === 'cooked_porkchop' ? '#8d5524' : '#e57373';
    ctx.beginPath();
    ctx.arc(7, 8, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.fillRect(10, 9, 3, 2);
    return canvas;
  }

  if (item === 'gunpowder') {
    ctx.fillStyle = '#555555';
    for (let i = 0; i < 8; i++) {
      ctx.fillRect(4 + (i % 4) * 2, 5 + Math.floor(i / 4) * 3, 2, 2);
    }
    return canvas;
  }

  // Fallback
  ctx.fillStyle = '#aaa';
  ctx.fillRect(3, 3, 10, 10);
  return canvas;
}

// --- Creeper Authentic Textures matching Creeper_JE2_BE1.webp ---

export function generateCreeperSkinCanvas(): HTMLCanvasElement {
  const { canvas, ctx } = createPixelCanvas();
  const palette = [
    '#54c636', '#4bb92e', '#62db44', '#3ea526', '#35921e',
    '#277817', '#1c5e0f', '#8cb483', '#77a270', '#638c5c',
    '#a3cc99', '#bdf2a8', '#31851b'
  ];

  // Draw 2x2 macro-pixel patches for authentic 16x16 Minecraft pixelation
  for (let y = 0; y < 16; y += 2) {
    for (let x = 0; x < 16; x += 2) {
      const col = palette[Math.floor(Math.random() * palette.length)];
      ctx.fillStyle = col;
      ctx.fillRect(x, y, 2, 2);
    }
  }

  // Add subtle single-pixel variations
  for (let i = 0; i < 20; i++) {
    const rx = Math.floor(Math.random() * 16);
    const ry = Math.floor(Math.random() * 16);
    ctx.fillStyle = palette[Math.floor(Math.random() * palette.length)];
    ctx.fillRect(rx, ry, 1, 1);
  }

  return canvas;
}

export function generateCreeperFaceCanvas(): HTMLCanvasElement {
  // Start with mottled green skin
  const canvas = generateCreeperSkinCanvas();
  const ctx = canvas.getContext('2d')!;

  // Dark border / shadow for the mouth & eyes
  const shadowColor = '#0b1f07';
  const blackColor = '#060a05';

  // 1. Left Eye (2x2 Minecraft pixels = 4x4 canvas pixels at x: 2..5, y: 3..6)
  ctx.fillStyle = shadowColor;
  ctx.fillRect(1, 2, 6, 6);
  ctx.fillStyle = blackColor;
  ctx.fillRect(2, 3, 4, 4);

  // 2. Right Eye (x: 10..13, y: 3..6)
  ctx.fillStyle = shadowColor;
  ctx.fillRect(9, 2, 6, 6);
  ctx.fillStyle = blackColor;
  ctx.fillRect(10, 3, 4, 4);

  // 3. Center Nose Bridge (x: 6..9, y: 7..8)
  ctx.fillStyle = shadowColor;
  ctx.fillRect(5, 6, 6, 4);
  ctx.fillStyle = blackColor;
  ctx.fillRect(6, 7, 4, 2);

  // 4. Upper Mouth (x: 4..11, y: 9..10)
  ctx.fillStyle = shadowColor;
  ctx.fillRect(3, 8, 10, 4);
  ctx.fillStyle = blackColor;
  ctx.fillRect(4, 9, 8, 2);

  // 5. Wide Mouth Frown (x: 2..13, y: 11..12)
  ctx.fillStyle = shadowColor;
  ctx.fillRect(1, 10, 14, 4);
  ctx.fillStyle = blackColor;
  ctx.fillRect(2, 11, 12, 2);

  // 6. Bottom Corners of Frown (Left: x: 2..5, y: 13..15; Right: x: 10..13, y: 13..15)
  ctx.fillStyle = shadowColor;
  ctx.fillRect(1, 12, 6, 4);
  ctx.fillRect(9, 12, 6, 4);
  ctx.fillStyle = blackColor;
  ctx.fillRect(2, 13, 4, 3);
  ctx.fillRect(10, 13, 4, 3);

  // Re-fill chin in center (x: 6..9, y: 13..15) with light sage green mottled
  ctx.fillStyle = '#638c5c';
  ctx.fillRect(6, 13, 4, 3);
  ctx.fillStyle = '#4bb92e';
  ctx.fillRect(7, 13, 2, 2);

  return canvas;
}

export function generateCreeperFootCanvas(): HTMLCanvasElement {
  const canvas = generateCreeperSkinCanvas();
  const ctx = canvas.getContext('2d')!;

  // 4 distinct black claw marks / toes on bottom edge (y: 12..15)
  // Claw 1: x: 0..3
  // Claw 2: x: 4..7
  // Claw 3: x: 8..11
  // Claw 4: x: 12..15
  const clawColor = '#0a0d08';
  const highlightColor = '#222820';

  const toes = [
    { start: 0, w: 3 },
    { start: 4, w: 3 },
    { start: 8, w: 3 },
    { start: 12, w: 3 },
  ];

  toes.forEach(({ start, w }) => {
    ctx.fillStyle = clawColor;
    ctx.fillRect(start, 12, w, 4);
    ctx.fillStyle = highlightColor;
    ctx.fillRect(start, 12, w, 1);
  });

  return canvas;
}

export function getCreeperTextures() {
  const skin = getTexture('creeper_skin', generateCreeperSkinCanvas);
  const face = getTexture('creeper_face', generateCreeperFaceCanvas);
  const foot = getTexture('creeper_foot', generateCreeperFootCanvas);
  return { skin, face, foot };
}

