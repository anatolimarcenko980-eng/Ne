/**
 * First-person Player Controller with AABB physics, collision resolution,
 * mining/placing logic, water swimming, and inventory integration.
 */

import * as THREE from 'three';
import { CameraPerspective, GameMode, ItemStack, ItemType } from '../types/game';
import { generateCrackCanvas } from './textures';
import { BLOCKS, ITEMS } from './items';
import { sound } from './sound';
import { World, WATER_LEVEL } from './world';
import { HeldItemRenderer } from './heldItem';
import { MobManager } from './mobs';
import { ParticleSystem } from './particles';
import { PlayerModel } from './playerModel';

export class Player {
  public camera: THREE.PerspectiveCamera;
  public position: THREE.Vector3;
  public velocity: THREE.Vector3 = new THREE.Vector3();
  public isGrounded: boolean = false;
  public isSwimming: boolean = false;
  public isFlying: boolean = false;
  public isSprinting: boolean = false;
  public isSneaking: boolean = false;

  // Camera Movement & Perspective
  public cameraMode: CameraPerspective = 'first_person';
  public cameraDistance: number = 3.5;
  public isZooming: boolean = false;
  public baseFov: number = 75;
  public playerModel: PlayerModel;

  // Health, Hunger, Game Mode
  public health: number = 20;
  public maxHealth: number = 20;
  public hunger: number = 20;
  public maxHunger: number = 20;
  public xpLevel: number = 0;
  public xpProgress: number = 0; // 0 to 1
  public gameMode: GameMode = 'survival';

  // Rotation
  public yaw: number = 0;
  public pitch: number = 0;

  // Inventory
  public hotbar: (ItemStack | null)[] = Array(9).fill(null);
  public inventory: (ItemStack | null)[] = Array(27).fill(null);
  public selectedSlot: number = 0;

  // Targeting & Mining
  public targetBlock: {
    hit: boolean;
    blockPos: THREE.Vector3;
    placePos: THREE.Vector3;
    blockType: string;
    normal: THREE.Vector3;
  } | null = null;

  public miningProgress: number = 0; // 0 to 1
  private miningTimer: number = 0;
  private miningTarget: THREE.Vector3 | null = null;
  private digSoundTimer: number = 0;

  // Rendering Helpers
  public heldItem: HeldItemRenderer;
  private selectionBox: THREE.LineSegments;
  private crackMesh: THREE.Mesh;
  private crackTextures: THREE.CanvasTexture[] = [];

  // Keys state
  public keys: Record<string, boolean> = {};
  public isLeftMouseDown: boolean = false;
  public isRightMouseDown: boolean = false;

  // Dependencies
  private world: World;
  private mobs: MobManager;
  private particles: ParticleSystem;

  // Double tap space tracking for fly & jump buffering
  private lastSpaceTime: number = 0;
  private stepSoundTimer: number = 0;
  public jumpBufferTime: number = 0;
  public coyoteTime: number = 0;

  // UI callbacks
  public onOpenCraftingTable?: () => void;
  public onOpenFurnace?: () => void;
  public onOpenChest?: () => void;

  constructor(world: World, mobs: MobManager, particles: ParticleSystem) {
    this.world = world;
    this.mobs = mobs;
    this.particles = particles;

    this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.05, 500);
    this.position = new THREE.Vector3(8.5, 26, 8.5);
    this.camera.position.copy(this.position);

    this.heldItem = new HeldItemRenderer();
    this.camera.add(this.heldItem.group);

    this.playerModel = new PlayerModel();

    // Target Block Outline Wireframe
    const boxGeo = new THREE.BoxGeometry(1.002, 1.002, 1.002);
    const edges = new THREE.EdgesGeometry(boxGeo);
    const lineMat = new THREE.LineBasicMaterial({ color: 0x000000, linewidth: 2 });
    this.selectionBox = new THREE.LineSegments(edges, lineMat);
    this.selectionBox.visible = false;

    // Crack Overlay Mesh
    for (let i = 0; i < 10; i++) {
      const cCanvas = generateCrackCanvas(i);
      const tex = new THREE.CanvasTexture(cCanvas);
      tex.magFilter = THREE.NearestFilter;
      this.crackTextures.push(tex);
    }
    const crackMat = new THREE.MeshBasicMaterial({
      map: this.crackTextures[0],
      transparent: true,
      depthTest: true,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    });
    this.crackMesh = new THREE.Mesh(new THREE.BoxGeometry(1.005, 1.005, 1.005), crackMat);
    this.crackMesh.visible = false;

    // Setup initial starting items in hotbar
    this.initStartingInventory();
  }

  public initStartingInventory() {
    this.hotbar[0] = { id: 'diamond_pickaxe', count: 1 };
    this.hotbar[1] = { id: 'diamond_sword', count: 1 };
    this.hotbar[2] = { id: 'diamond_axe', count: 1 };
    this.hotbar[3] = { id: 'diamond_shovel', count: 1 };
    this.hotbar[4] = { id: 'oak_planks', count: 64 };
    this.hotbar[5] = { id: 'cobblestone', count: 64 };
    this.hotbar[6] = { id: 'torch', count: 64 };
    this.hotbar[7] = { id: 'cooked_porkchop', count: 16 };
    this.hotbar[8] = { id: 'tnt', count: 16 };
  }

  public getHeldItem(): ItemStack | null {
    return this.hotbar[this.selectedSlot] || null;
  }

  public addToInventory(item: ItemType, count: number = 1): boolean {
    const itemDef = ITEMS[item];
    const maxStack = itemDef?.maxStack || 64;

    // 1. Try stacking into hotbar
    for (let i = 0; i < 9; i++) {
      const slot = this.hotbar[i];
      if (slot && slot.id === item && slot.count < maxStack) {
        const add = Math.min(count, maxStack - slot.count);
        slot.count += add;
        count -= add;
        if (count === 0) {
          sound.playPop();
          return true;
        }
      }
    }

    // 2. Try stacking into inventory
    for (let i = 0; i < 27; i++) {
      const slot = this.inventory[i];
      if (slot && slot.id === item && slot.count < maxStack) {
        const add = Math.min(count, maxStack - slot.count);
        slot.count += add;
        count -= add;
        if (count === 0) {
          sound.playPop();
          return true;
        }
      }
    }

    // 3. Place into empty hotbar slot
    for (let i = 0; i < 9; i++) {
      if (!this.hotbar[i]) {
        this.hotbar[i] = { id: item, count };
        sound.playPop();
        return true;
      }
    }

    // 4. Place into empty inventory slot
    for (let i = 0; i < 27; i++) {
      if (!this.inventory[i]) {
        this.inventory[i] = { id: item, count };
        sound.playPop();
        return true;
      }
    }

    return false;
  }

  public onMouseMove(dx: number, dy: number) {
    const sensitivity = 0.0022;
    this.yaw -= dx * sensitivity;
    this.pitch -= dy * sensitivity;
    const maxPitch = (Math.PI / 2) * 0.98;
    this.pitch = Math.max(-maxPitch, Math.min(maxPitch, this.pitch));
  }

  public cycleCameraMode(): CameraPerspective {
    if (this.cameraMode === 'first_person') {
      this.cameraMode = 'third_person_back';
    } else if (this.cameraMode === 'third_person_back') {
      this.cameraMode = 'third_person_front';
    } else {
      this.cameraMode = 'first_person';
    }
    sound.playClick();
    return this.cameraMode;
  }

  public setCameraDistance(delta: number) {
    this.cameraDistance = Math.max(1.2, Math.min(8.0, this.cameraDistance + delta));
  }

  public handleSpacePress() {
    const now = performance.now();
    if (this.gameMode === 'creative' && now - this.lastSpaceTime < 350) {
      // Double tap space toggles flight in creative!
      this.isFlying = !this.isFlying;
      this.velocity.y = 0;
    }
    this.lastSpaceTime = now;
    this.jumpBufferTime = 0.18; // buffer jump for 180ms
  }

  // Accurate AABB Collision Detection against solid voxel blocks
  private resolveCollisions(dt: number) {
    const halfW = 0.3;
    const eyeH = this.isSneaking ? 1.4 : 1.62;
    const totalH = 1.8;

    // 1. Resolve X movement
    this.position.x += this.velocity.x * dt;
    let feetY = this.position.y - eyeH;
    let headY = feetY + totalH;

    let minX = Math.floor(this.position.x - halfW);
    let maxX = Math.floor(this.position.x + halfW);
    let minY = Math.floor(feetY);
    let maxY = Math.floor(headY - 0.001);
    let minZ = Math.floor(this.position.z - halfW);
    let maxZ = Math.floor(this.position.z + halfW);

    for (let y = minY; y <= maxY; y++) {
      for (let z = minZ; z <= maxZ; z++) {
        for (let x = minX; x <= maxX; x++) {
          if (this.world.isSolid(x, y, z)) {
            const overlapY = headY > y + 0.001 && feetY < y + 1 - 0.001;
            const overlapZ = (this.position.z + halfW) > z + 0.001 && (this.position.z - halfW) < z + 1 - 0.001;
            if (overlapY && overlapZ) {
              if (this.velocity.x > 0) {
                this.position.x = x - halfW;
              } else if (this.velocity.x < 0) {
                this.position.x = x + 1 + halfW;
              }
              this.velocity.x = 0;
            }
          }
        }
      }
    }

    // 2. Resolve Z movement
    this.position.z += this.velocity.z * dt;
    feetY = this.position.y - eyeH;
    headY = feetY + totalH;

    minX = Math.floor(this.position.x - halfW);
    maxX = Math.floor(this.position.x + halfW);
    minY = Math.floor(feetY);
    maxY = Math.floor(headY - 0.001);
    minZ = Math.floor(this.position.z - halfW);
    maxZ = Math.floor(this.position.z + halfW);

    for (let y = minY; y <= maxY; y++) {
      for (let z = minZ; z <= maxZ; z++) {
        for (let x = minX; x <= maxX; x++) {
          if (this.world.isSolid(x, y, z)) {
            const overlapY = headY > y + 0.001 && feetY < y + 1 - 0.001;
            const overlapX = (this.position.x + halfW) > x + 0.001 && (this.position.x - halfW) < x + 1 - 0.001;
            if (overlapY && overlapX) {
              if (this.velocity.z > 0) {
                this.position.z = z - halfW;
              } else if (this.velocity.z < 0) {
                this.position.z = z + 1 + halfW;
              }
              this.velocity.z = 0;
            }
          }
        }
      }
    }

    // 3. Resolve Y movement
    this.position.y += this.velocity.y * dt;
    feetY = this.position.y - eyeH;
    headY = feetY + totalH;

    minX = Math.floor(this.position.x - halfW);
    maxX = Math.floor(this.position.x + halfW);
    minY = Math.floor(feetY);
    maxY = Math.floor(headY);
    minZ = Math.floor(this.position.z - halfW);
    maxZ = Math.floor(this.position.z + halfW);

    this.isGrounded = false;

    for (let y = minY; y <= maxY; y++) {
      for (let z = minZ; z <= maxZ; z++) {
        for (let x = minX; x <= maxX; x++) {
          if (this.world.isSolid(x, y, z)) {
            // Strictly check X and Z overlap so walls beside player never act as ceilings
            const overlapX = (this.position.x + halfW) > x + 0.001 && (this.position.x - halfW) < x + 1 - 0.001;
            const overlapZ = (this.position.z + halfW) > z + 0.001 && (this.position.z - halfW) < z + 1 - 0.001;

            if (overlapX && overlapZ) {
              if (this.velocity.y < 0) {
                // Falling onto top of solid block (y + 1)
                if (feetY < y + 1) {
                  this.position.y = (y + 1) + eyeH;
                  this.velocity.y = 0;
                  this.isGrounded = true;
                  feetY = this.position.y - eyeH;
                  headY = feetY + totalH;
                }
              } else if (this.velocity.y > 0) {
                // Hitting head on bottom of solid block above (ceiling)
                if (headY > y) {
                  this.position.y = y - totalH + eyeH - 0.001;
                  this.velocity.y = 0;
                  feetY = this.position.y - eyeH;
                  headY = feetY + totalH;
                }
              }
            }
          }
        }
      }
    }
  }

  public update(dt: number) {
    // Check if swimming
    const feetBlock = this.world.getBlock(
      Math.floor(this.position.x),
      Math.floor(this.position.y - 1.4),
      Math.floor(this.position.z)
    );
    this.isSwimming = feetBlock === 'water';

    // Calculate movement forward/strafe vectors
    const forward = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw)).normalize();
    const right = new THREE.Vector3(Math.cos(this.yaw), 0, -Math.sin(this.yaw)).normalize();

    let moveX = 0;
    let moveZ = 0;
    if (this.keys['KeyW']) moveZ += 1;
    if (this.keys['KeyS']) moveZ -= 1;
    if (this.keys['KeyA']) moveX -= 1;
    if (this.keys['KeyD']) moveX += 1;

    this.isSprinting = !!(this.keys['ControlLeft'] || this.keys['KeyR'] || this.keys['ControlRight']);
    this.isSneaking = !!(this.keys['ShiftLeft'] || this.keys['ShiftRight']);

    const isMoving = moveX !== 0 || moveZ !== 0;

    let baseSpeed = 4.3;
    if (this.isSprinting) baseSpeed = 6.2;
    if (this.isSneaking) baseSpeed = 1.8;
    if (this.isSwimming) baseSpeed = 2.4;
    if (this.isFlying) baseSpeed = 11.0;

    const moveDir = new THREE.Vector3()
      .addScaledVector(forward, moveZ)
      .addScaledVector(right, moveX)
      .normalize();

    // Update coyote time and jump buffer
    if (this.isGrounded) {
      this.coyoteTime = 0.15; // 150ms coyote time
    } else {
      this.coyoteTime = Math.max(0, this.coyoteTime - dt);
    }

    if (this.jumpBufferTime > 0) {
      this.jumpBufferTime = Math.max(0, this.jumpBufferTime - dt);
    }

    const wantsJump = !!(this.keys['Space'] || this.jumpBufferTime > 0);

    if (this.isFlying) {
      // Flight physics
      this.velocity.x = moveDir.x * baseSpeed;
      this.velocity.z = moveDir.z * baseSpeed;
      if (this.keys['Space']) this.velocity.y = baseSpeed;
      else if (this.isSneaking) this.velocity.y = -baseSpeed;
      else this.velocity.y = 0;

      this.position.addScaledVector(this.velocity, dt);
    } else {
      // Ground / Gravity physics
      const targetVx = moveDir.x * baseSpeed;
      const targetVz = moveDir.z * baseSpeed;

      const accel = this.isGrounded ? 15 : 7;
      this.velocity.x = THREE.MathUtils.lerp(this.velocity.x, targetVx, dt * accel);
      this.velocity.z = THREE.MathUtils.lerp(this.velocity.z, targetVz, dt * accel);

      // Jump / Swim
      if (wantsJump) {
        if (this.isSwimming) {
          this.velocity.y = 4.0;
          sound.playSplash();
        } else if (this.isGrounded || this.coyoteTime > 0) {
          this.velocity.y = 8.8; // jump impulse for clearing 1.25 blocks
          this.isGrounded = false;
          this.coyoteTime = 0;
          this.jumpBufferTime = 0;
          sound.playJump();
        }
      }

      // Gravity
      const gravity = this.isSwimming ? -6 : -24;
      this.velocity.y += gravity * dt;
      if (this.velocity.y < -35) this.velocity.y = -35; // Terminal velocity

      // Resolve AABB collisions
      this.resolveCollisions(dt);
    }

    // Keyboard camera movement (Arrow keys)
    const rotSpeed = 2.4 * dt;
    if (this.keys['ArrowLeft']) this.yaw += rotSpeed;
    if (this.keys['ArrowRight']) this.yaw -= rotSpeed;
    if (this.keys['ArrowUp']) this.pitch += rotSpeed;
    if (this.keys['ArrowDown']) this.pitch -= rotSpeed;
    const maxPitch = (Math.PI / 2) * 0.98;
    this.pitch = Math.max(-maxPitch, Math.min(maxPitch, this.pitch));

    // Dynamic Zoom FOV (holding 'C' or isZooming)
    const targetFov = this.isZooming || this.keys['KeyC'] ? 22 : this.baseFov;
    this.camera.fov = THREE.MathUtils.lerp(this.camera.fov, targetFov, dt * 14);
    this.camera.updateProjectionMatrix();

    // Eye position & Forward vector
    const eyePos = this.position.clone();
    const lookDir = new THREE.Vector3(
      -Math.sin(this.yaw) * Math.cos(this.pitch),
      Math.sin(this.pitch),
      -Math.cos(this.yaw) * Math.cos(this.pitch)
    ).normalize();

    // Update Camera Perspective Position
    if (this.cameraMode === 'first_person') {
      this.camera.position.copy(eyePos);
      this.camera.rotation.order = 'YXZ';
      this.camera.rotation.y = this.yaw;
      this.camera.rotation.x = this.pitch;
      this.camera.rotation.z = 0;

      this.playerModel.group.visible = false;
      this.heldItem.group.visible = true;
    } else if (this.cameraMode === 'third_person_back') {
      this.playerModel.group.visible = true;
      this.heldItem.group.visible = false;

      let actualDist = this.cameraDistance;
      const backDir = lookDir.clone().negate();
      const checkSteps = 16;
      for (let s = 1; s <= checkSteps; s++) {
        const testD = (this.cameraDistance * s) / checkSteps;
        const testPos = eyePos.clone().addScaledVector(backDir, testD);
        if (this.world.isSolid(Math.floor(testPos.x), Math.floor(testPos.y), Math.floor(testPos.z))) {
          actualDist = Math.max(0.6, testD - 0.25);
          break;
        }
      }

      const camPos = eyePos.clone().addScaledVector(backDir, actualDist);
      this.camera.position.copy(camPos);
      this.camera.lookAt(eyePos.clone().add(new THREE.Vector3(0, 0.1, 0)));
    } else if (this.cameraMode === 'third_person_front') {
      this.playerModel.group.visible = true;
      this.heldItem.group.visible = false;

      let actualDist = this.cameraDistance;
      const frontDir = lookDir.clone();
      const checkSteps = 16;
      for (let s = 1; s <= checkSteps; s++) {
        const testD = (this.cameraDistance * s) / checkSteps;
        const testPos = eyePos.clone().addScaledVector(frontDir, testD);
        if (this.world.isSolid(Math.floor(testPos.x), Math.floor(testPos.y), Math.floor(testPos.z))) {
          actualDist = Math.max(0.6, testD - 0.25);
          break;
        }
      }

      const camPos = eyePos.clone().addScaledVector(frontDir, actualDist);
      this.camera.position.copy(camPos);
      this.camera.lookAt(eyePos.clone().add(new THREE.Vector3(0, 0.1, 0)));
    }

    // Sync playerModel position & animation
    const feetY = this.position.y - (this.isSneaking ? 1.4 : 1.62);
    this.playerModel.group.position.set(this.position.x, feetY, this.position.z);
    this.playerModel.setHeldItem(this.getHeldItem() ? this.getHeldItem()!.id : null);
    this.playerModel.update(
      dt,
      this.pitch,
      this.yaw,
      isMoving,
      this.isSprinting,
      this.heldItem.isSwinging,
      this.heldItem.swingProgress
    );

    // Footstep audio
    if (isMoving && this.isGrounded && !this.isFlying) {
      this.stepSoundTimer += dt * (this.isSprinting ? 2.8 : 2.0);
      if (this.stepSoundTimer >= 1.0) {
        this.stepSoundTimer = 0;
        const groundBlock = this.world.getBlock(
          Math.floor(this.position.x),
          Math.floor(this.position.y - 1.8),
          Math.floor(this.position.z)
        );
        const cat = BLOCKS[groundBlock]?.soundCategory || 'grass';
        sound.playStep(cat);
      }
    }

    // Raycast target block
    this.updateTargetBlock();

    // Mining / Block Breaking
    this.updateMining(dt);

    // Update 3D held item in hand
    const held = this.getHeldItem();
    this.heldItem.setItem(held ? held.id : null);
    this.heldItem.update(dt, isMoving, this.isSprinting);
  }

  private updateTargetBlock() {
    const dir = new THREE.Vector3();
    this.camera.getWorldDirection(dir);
    const hit = this.world.raycast(this.camera.position, dir, 5.5);

    this.targetBlock = hit;

    if (hit) {
      this.selectionBox.visible = true;
      this.selectionBox.position.set(hit.blockPos.x + 0.5, hit.blockPos.y + 0.5, hit.blockPos.z + 0.5);

      if (this.miningProgress > 0) {
        this.crackMesh.visible = true;
        this.crackMesh.position.copy(this.selectionBox.position);
        const stage = Math.min(9, Math.floor(this.miningProgress * 10));
        (this.crackMesh.material as THREE.MeshBasicMaterial).map = this.crackTextures[stage];
        (this.crackMesh.material as THREE.MeshBasicMaterial).needsUpdate = true;
      } else {
        this.crackMesh.visible = false;
      }
    } else {
      this.selectionBox.visible = false;
      this.crackMesh.visible = false;
    }
  }

  public onLeftClick() {
    // Swing arm
    this.heldItem.swing();

    // Attack mob check
    const dir = new THREE.Vector3();
    this.camera.getWorldDirection(dir);

    for (const mob of this.mobs.mobs) {
      const mobPos = new THREE.Vector3(mob.x, mob.y + 0.5, mob.z);
      const toMob = mobPos.clone().sub(this.camera.position);
      const dist = toMob.length();

      if (dist < 4.5 && toMob.normalize().dot(dir) > 0.85) {
        // Hit mob!
        const held = this.getHeldItem();
        const itemDef = held ? ITEMS[held.id] : null;
        const damage = itemDef?.attackDamage || 1;

        const { dead, drops } = this.mobs.hitMob(mob.id, damage, dir);
        if (dead) {
          this.xpLevel += 1;
          sound.playLevelUp();
          drops.forEach((d) => this.addToInventory(d, 1));
        }
        return;
      }
    }

    // Instant block break in Creative
    if (this.gameMode === 'creative' && this.targetBlock) {
      const bType = this.targetBlock.blockType as keyof typeof BLOCKS;
      if (bType !== 'bedrock') {
        const cat = BLOCKS[bType]?.soundCategory || 'stone';
        sound.playBreak(cat);
        this.particles.emitBlockBreak(this.targetBlock.blockPos, bType);
        this.world.setBlock(
          this.targetBlock.blockPos.x,
          this.targetBlock.blockPos.y,
          this.targetBlock.blockPos.z,
          'air'
        );
      }
    }
  }

  private updateMining(dt: number) {
    if (this.gameMode === 'creative') {
      this.miningProgress = 0;
      return;
    }

    if (this.isLeftMouseDown && this.targetBlock) {
      const pos = this.targetBlock.blockPos;

      if (!this.miningTarget || !this.miningTarget.equals(pos)) {
        this.miningTarget = pos.clone();
        this.miningTimer = 0;
        this.miningProgress = 0;
      }

      const bType = this.targetBlock.blockType as keyof typeof BLOCKS;
      const bDef = BLOCKS[bType];
      if (!bDef || bDef.hardness === Infinity) {
        this.miningProgress = 0;
        return;
      }

      // Calculate break time based on tool speed
      const held = this.getHeldItem();
      const itemDef = held ? ITEMS[held.id] : null;
      let speed = 1.0;
      if (itemDef?.toolSpeedMultiplier) {
        speed = itemDef.toolSpeedMultiplier;
      }

      // Hardness break duration
      const duration = Math.max(0.15, (bDef.hardness * 1.5) / speed);
      this.miningTimer += dt;
      this.miningProgress = Math.min(1.0, this.miningTimer / duration);

      // Play digging sound and swing arm
      this.digSoundTimer += dt;
      if (this.digSoundTimer >= 0.25) {
        this.digSoundTimer = 0;
        this.heldItem.swing();
        sound.playDig(bDef.soundCategory);
      }

      // Break complete!
      if (this.miningProgress >= 1.0) {
        sound.playBreak(bDef.soundCategory);
        this.particles.emitBlockBreak(pos, bType);
        this.world.setBlock(pos.x, pos.y, pos.z, 'air');

        // Add dropped item
        const drop = bDef.dropItem;
        if (drop && drop !== 'air') {
          this.addToInventory(drop, bDef.dropCount || 1);
        }

        this.miningProgress = 0;
        this.miningTimer = 0;
        this.miningTarget = null;
      }
    } else {
      this.miningProgress = 0;
      this.miningTimer = 0;
      this.miningTarget = null;
    }
  }

  public onRightClick() {
    if (!this.targetBlock) return;

    const bPos = this.targetBlock.blockPos;
    const pPos = this.targetBlock.placePos;
    const bType = this.targetBlock.blockType;

    // Check containers & interactive blocks first
    if (bType === 'crafting_table') {
      if (this.onOpenCraftingTable) {
        sound.playClick();
        this.onOpenCraftingTable();
        return;
      }
    }

    if (bType === 'furnace') {
      if (this.onOpenFurnace) {
        sound.playClick();
        this.onOpenFurnace();
        return;
      }
    }

    if (bType === 'chest') {
      if (this.onOpenChest) {
        sound.playDoor();
        this.onOpenChest();
        return;
      }
    }

    if (bType === 'oak_door') {
      sound.playDoor();
      return;
    }

    // TNT ignition!
    if (bType === 'tnt') {
      sound.playFuse();
      this.world.setBlock(bPos.x, bPos.y, bPos.z, 'air');
      setTimeout(() => {
        sound.playExplosion();
        this.particles.emitExplosion(bPos);
        const destroyed = this.world.explode(bPos, 3.5);
        destroyed.forEach((b) => {
          if (Math.random() < 0.6) {
            this.addToInventory(b.type, 1);
          }
        });
      }, 2500);
      return;
    }

    const held = this.getHeldItem();
    if (!held) return;

    // Check if eating food
    const itemDef = ITEMS[held.id];
    if (itemDef?.foodValue && this.hunger < 20) {
      this.hunger = Math.min(20, this.hunger + itemDef.foodValue);
      this.health = Math.min(20, this.health + 2);
      sound.playPop();
      if (this.gameMode === 'survival') {
        held.count--;
        if (held.count <= 0) {
          this.hotbar[this.selectedSlot] = null;
        }
      }
      return;
    }

    // Place Block
    if (itemDef?.isBlock) {
      // Don't place inside player AABB
      const playerMinX = this.position.x - 0.3;
      const playerMaxX = this.position.x + 0.3;
      const playerMinY = this.position.y - (this.isSneaking ? 1.4 : 1.62);
      const playerMaxY = playerMinY + 1.8;
      const playerMinZ = this.position.z - 0.3;
      const playerMaxZ = this.position.z + 0.3;

      const placeMinX = pPos.x;
      const placeMaxX = pPos.x + 1;
      const placeMinY = pPos.y;
      const placeMaxY = pPos.y + 1;
      const placeMinZ = pPos.z;
      const placeMaxZ = pPos.z + 1;

      const intersects =
        playerMinX < placeMaxX &&
        playerMaxX > placeMinX &&
        playerMinY < placeMaxY &&
        playerMaxY > placeMinY &&
        playerMinZ < placeMaxZ &&
        playerMaxZ > placeMinZ;

      if (!intersects) {
        const blockName = held.id as keyof typeof BLOCKS;
        this.world.setBlock(pPos.x, pPos.y, pPos.z, blockName);
        const cat = BLOCKS[blockName]?.soundCategory || 'stone';
        sound.playPlace(cat);
        this.heldItem.swing();

        if (this.gameMode === 'survival') {
          held.count--;
          if (held.count <= 0) {
            this.hotbar[this.selectedSlot] = null;
          }
        }
      }
    }
  }

  public takeDamage(dmg: number) {
    if (this.gameMode === 'creative') return;
    this.health = Math.max(0, this.health - dmg);
    sound.playHurt();

    if (this.health <= 0) {
      // Respawn at safe coordinates
      this.position.set(8.5, 26, 8.5);
      this.velocity.set(0, 0, 0);
      this.health = 20;
      this.hunger = 20;
    }
  }

  public addToScene(scene: THREE.Scene) {
    scene.add(this.camera);
    scene.add(this.playerModel.group);
    scene.add(this.selectionBox);
    scene.add(this.crackMesh);
  }
}
