/**
 * Crafting & Smelting system for Minecraft Web Edition.
 */

import { ItemStack, ItemType } from '../types/game';

export interface CraftingRecipe {
  pattern: (ItemType | null)[][]; // 1x1, 2x2, or 3x3
  result: ItemStack;
  shapeless?: boolean;
}

export interface SmeltingRecipe {
  input: ItemType;
  output: ItemType;
  cookTime: number; // in ticks or seconds
}

export const SMELTING_RECIPES: SmeltingRecipe[] = [
  { input: 'raw_porkchop', output: 'cooked_porkchop', cookTime: 5 },
  { input: 'iron_ore', output: 'iron_ingot', cookTime: 6 },
  { input: 'gold_ore', output: 'gold_ingot', cookTime: 6 },
  { input: 'sand', output: 'glass', cookTime: 4 },
  { input: 'cobblestone', output: 'stone', cookTime: 4 },
  { input: 'oak_log', output: 'coal', cookTime: 5 },
];

export const CRAFTING_RECIPES: CraftingRecipe[] = [
  // Planks from logs (shapeless 1 log -> 4 planks)
  {
    pattern: [['oak_log']],
    result: { id: 'oak_planks', count: 4 },
    shapeless: true,
  },
  // Sticks (2 planks vertical)
  {
    pattern: [
      ['oak_planks'],
      ['oak_planks'],
    ],
    result: { id: 'stick', count: 4 },
  },
  // Crafting Table (4 planks 2x2)
  {
    pattern: [
      ['oak_planks', 'oak_planks'],
      ['oak_planks', 'oak_planks'],
    ],
    result: { id: 'crafting_table', count: 1 },
  },
  // Torch (1 coal over 1 stick)
  {
    pattern: [
      ['coal'],
      ['stick'],
    ],
    result: { id: 'torch', count: 4 },
  },
  // Chest (8 planks 3x3 hollow)
  {
    pattern: [
      ['oak_planks', 'oak_planks', 'oak_planks'],
      ['oak_planks', null, 'oak_planks'],
      ['oak_planks', 'oak_planks', 'oak_planks'],
    ],
    result: { id: 'chest', count: 1 },
  },
  // Furnace (8 cobblestone 3x3 hollow)
  {
    pattern: [
      ['cobblestone', 'cobblestone', 'cobblestone'],
      ['cobblestone', null, 'cobblestone'],
      ['cobblestone', 'cobblestone', 'cobblestone'],
    ],
    result: { id: 'furnace', count: 1 },
  },
  // Door (6 planks 2x3)
  {
    pattern: [
      ['oak_planks', 'oak_planks'],
      ['oak_planks', 'oak_planks'],
      ['oak_planks', 'oak_planks'],
    ],
    result: { id: 'oak_door', count: 3 },
  },
  // TNT (5 gunpowder X, 4 sand +)
  {
    pattern: [
      ['gunpowder', 'sand', 'gunpowder'],
      ['sand', 'gunpowder', 'sand'],
      ['gunpowder', 'sand', 'gunpowder'],
    ],
    result: { id: 'tnt', count: 1 },
  },
  // Bookshelf (3 books / 6 planks)
  {
    pattern: [
      ['oak_planks', 'oak_planks', 'oak_planks'],
      ['stick', 'stick', 'stick'],
      ['oak_planks', 'oak_planks', 'oak_planks'],
    ],
    result: { id: 'bookshelf', count: 1 },
  },

  // --- Swords ---
  {
    pattern: [
      ['oak_planks'],
      ['oak_planks'],
      ['stick'],
    ],
    result: { id: 'wooden_sword', count: 1 },
  },
  {
    pattern: [
      ['cobblestone'],
      ['cobblestone'],
      ['stick'],
    ],
    result: { id: 'stone_sword', count: 1 },
  },
  {
    pattern: [
      ['iron_ingot'],
      ['iron_ingot'],
      ['stick'],
    ],
    result: { id: 'iron_sword', count: 1 },
  },
  {
    pattern: [
      ['diamond'],
      ['diamond'],
      ['stick'],
    ],
    result: { id: 'diamond_sword', count: 1 },
  },

  // --- Pickaxes ---
  {
    pattern: [
      ['oak_planks', 'oak_planks', 'oak_planks'],
      [null, 'stick', null],
      [null, 'stick', null],
    ],
    result: { id: 'wooden_pickaxe', count: 1 },
  },
  {
    pattern: [
      ['cobblestone', 'cobblestone', 'cobblestone'],
      [null, 'stick', null],
      [null, 'stick', null],
    ],
    result: { id: 'stone_pickaxe', count: 1 },
  },
  {
    pattern: [
      ['iron_ingot', 'iron_ingot', 'iron_ingot'],
      [null, 'stick', null],
      [null, 'stick', null],
    ],
    result: { id: 'iron_pickaxe', count: 1 },
  },
  {
    pattern: [
      ['diamond', 'diamond', 'diamond'],
      [null, 'stick', null],
      [null, 'stick', null],
    ],
    result: { id: 'diamond_pickaxe', count: 1 },
  },

  // --- Axes ---
  {
    pattern: [
      ['oak_planks', 'oak_planks'],
      ['oak_planks', 'stick'],
      [null, 'stick'],
    ],
    result: { id: 'wooden_axe', count: 1 },
  },
  {
    pattern: [
      ['cobblestone', 'cobblestone'],
      ['cobblestone', 'stick'],
      [null, 'stick'],
    ],
    result: { id: 'stone_axe', count: 1 },
  },
  {
    pattern: [
      ['iron_ingot', 'iron_ingot'],
      ['iron_ingot', 'stick'],
      [null, 'stick'],
    ],
    result: { id: 'iron_axe', count: 1 },
  },
  {
    pattern: [
      ['diamond', 'diamond'],
      ['diamond', 'stick'],
      [null, 'stick'],
    ],
    result: { id: 'diamond_axe', count: 1 },
  },

  // --- Shovels ---
  {
    pattern: [
      ['oak_planks'],
      ['stick'],
      ['stick'],
    ],
    result: { id: 'wooden_shovel', count: 1 },
  },
  {
    pattern: [
      ['cobblestone'],
      ['stick'],
      ['stick'],
    ],
    result: { id: 'stone_shovel', count: 1 },
  },
  {
    pattern: [
      ['iron_ingot'],
      ['stick'],
      ['stick'],
    ],
    result: { id: 'iron_shovel', count: 1 },
  },
  {
    pattern: [
      ['diamond'],
      ['stick'],
      ['stick'],
    ],
    result: { id: 'diamond_shovel', count: 1 },
  },
];

// Helper to trim empty rows and columns in a 2D grid
function trimGrid(grid: (ItemType | null)[][]): (ItemType | null)[][] {
  let minRow = grid.length;
  let maxRow = -1;
  let minCol = grid[0]?.length || 0;
  let maxCol = -1;

  for (let r = 0; r < grid.length; r++) {
    for (let c = 0; c < grid[r].length; c++) {
      if (grid[r][c] !== null) {
        minRow = Math.min(minRow, r);
        maxRow = Math.max(maxRow, r);
        minCol = Math.min(minCol, c);
        maxCol = Math.max(maxCol, c);
      }
    }
  }

  if (maxRow === -1) return [];

  const result: (ItemType | null)[][] = [];
  for (let r = minRow; r <= maxRow; r++) {
    const row: (ItemType | null)[] = [];
    for (let c = minCol; c <= maxCol; c++) {
      row.push(grid[r][c]);
    }
    result.push(row);
  }
  return result;
}

export function findMatchingRecipe(grid: (ItemStack | null)[][]): ItemStack | null {
  // Extract item IDs
  const idGrid: (ItemType | null)[][] = grid.map((row) =>
    row.map((slot) => (slot && slot.count > 0 ? slot.id : null))
  );

  const trimmed = trimGrid(idGrid);
  if (trimmed.length === 0) return null;

  // Check each recipe
  for (const recipe of CRAFTING_RECIPES) {
    if (recipe.shapeless) {
      // Collect non-null items in trimmed
      const inputItems: ItemType[] = [];
      for (const row of trimmed) {
        for (const it of row) {
          if (it) inputItems.push(it);
        }
      }
      const recipeItems: ItemType[] = [];
      for (const row of recipe.pattern) {
        for (const it of row) {
          if (it) recipeItems.push(it);
        }
      }
      if (inputItems.length === recipeItems.length) {
        inputItems.sort();
        recipeItems.sort();
        if (inputItems.every((val, idx) => val === recipeItems[idx])) {
          return { ...recipe.result };
        }
      }
      continue;
    }

    // Pattern matching
    if (trimmed.length !== recipe.pattern.length) continue;
    if (trimmed[0].length !== recipe.pattern[0].length) continue;

    let match = true;
    for (let r = 0; r < trimmed.length; r++) {
      for (let c = 0; c < trimmed[r].length; c++) {
        if (trimmed[r][c] !== recipe.pattern[r][c]) {
          match = false;
          break;
        }
      }
      if (!match) break;
    }

    if (match) {
      return { ...recipe.result };
    }
  }

  return null;
}
