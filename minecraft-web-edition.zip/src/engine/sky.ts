/**
 * Dynamic Skybox, Day/Night Cycle, Sun, Moon, Stars, and Voxel Clouds for Minecraft Web Edition.
 */

import * as THREE from 'three';

export class SkyEngine {
  public group: THREE.Group = new THREE.Group();
  public sunLight: THREE.DirectionalLight;
  public ambientLight: THREE.AmbientLight;

  private sunMesh: THREE.Mesh;
  private moonMesh: THREE.Mesh;
  private starPoints: THREE.Points;
  private cloudMesh: THREE.Mesh;

  // Time: 0.0 = sunrise, 0.25 = noon, 0.5 = sunset, 0.75 = midnight, 1.0 = loop
  public time: number = 0.2;
  public timeSpeed: number = 1 / 480; // 1 full day = 8 minutes by default

  constructor() {
    // Lights
    this.ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    this.sunLight = new THREE.DirectionalLight(0xffffff, 1.0);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.width = 1024;
    this.sunLight.shadow.mapSize.height = 1024;
    this.sunLight.shadow.camera.near = 0.5;
    this.sunLight.shadow.camera.far = 150;
    const d = 35;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;

    this.group.add(this.ambientLight);
    this.group.add(this.sunLight);

    // Sun: 2D square facing camera or billboard
    const sunGeo = new THREE.PlaneGeometry(16, 16);
    const sunMat = new THREE.MeshBasicMaterial({ color: 0xfff6bd, side: THREE.DoubleSide });
    this.sunMesh = new THREE.Mesh(sunGeo, sunMat);
    this.group.add(this.sunMesh);

    // Moon: 2D square
    const moonGeo = new THREE.PlaneGeometry(12, 12);
    const moonMat = new THREE.MeshBasicMaterial({ color: 0xe6e6f0, side: THREE.DoubleSide });
    this.moonMesh = new THREE.Mesh(moonGeo, moonMat);
    this.group.add(this.moonMesh);

    // Stars
    const starCount = 350;
    const starGeo = new THREE.BufferGeometry();
    const starPositions = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      const u = Math.random();
      const v = Math.random();
      const theta = u * 2.0 * Math.PI;
      const phi = Math.acos(2.0 * v - 1.0);
      const r = 180;
      const x = r * Math.sin(phi) * Math.cos(theta);
      const y = Math.abs(r * Math.cos(phi)) + 10; // upper hemisphere
      const z = r * Math.sin(phi) * Math.sin(theta);
      starPositions[i * 3] = x;
      starPositions[i * 3 + 1] = y;
      starPositions[i * 3 + 2] = z;
    }
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    const starMat = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 1.8,
      transparent: true,
      opacity: 0.8,
    });
    this.starPoints = new THREE.Points(starGeo, starMat);
    this.group.add(this.starPoints);

    // Clouds
    const cloudGeo = new THREE.PlaneGeometry(400, 400);
    // Create procedural pixelated cloud texture
    const cCanvas = document.createElement('canvas');
    cCanvas.width = 64;
    cCanvas.height = 64;
    const cCtx = cCanvas.getContext('2d')!;
    cCtx.fillStyle = 'rgba(255, 255, 255, 0.85)';
    for (let y = 0; y < 64; y += 4) {
      for (let x = 0; x < 64; x += 4) {
        if ((Math.sin(x * 0.2) + Math.cos(y * 0.2)) > 0.4) {
          cCtx.fillRect(x, y, 4, 4);
        }
      }
    }
    const cTex = new THREE.CanvasTexture(cCanvas);
    cTex.magFilter = THREE.NearestFilter;
    cTex.wrapS = THREE.RepeatWrapping;
    cTex.wrapT = THREE.RepeatWrapping;
    cTex.repeat.set(6, 6);

    const cloudMat = new THREE.MeshBasicMaterial({
      map: cTex,
      transparent: true,
      opacity: 0.65,
      side: THREE.DoubleSide,
      depthWrite: false,
    });

    this.cloudMesh = new THREE.Mesh(cloudGeo, cloudMat);
    this.cloudMesh.position.y = 44;
    this.cloudMesh.rotation.x = Math.PI / 2;
    this.group.add(this.cloudMesh);
  }

  public update(dt: number, playerPos: THREE.Vector3, scene: THREE.Scene) {
    this.time = (this.time + dt * this.timeSpeed) % 1.0;

    // Follow player horizontally
    this.group.position.x = playerPos.x;
    this.group.position.z = playerPos.z;

    // Scroll clouds
    const cMat = this.cloudMesh.material as THREE.MeshBasicMaterial;
    if (cMat.map) {
      cMat.map.offset.x += dt * 0.008;
    }

    // Celestial angle (0 = noon, 0.5 = midnight)
    const angle = (this.time - 0.25) * Math.PI * 2;
    const dist = 140;

    // Sun position
    const sunX = Math.cos(angle) * dist;
    const sunY = Math.sin(angle) * dist;
    this.sunMesh.position.set(sunX, sunY, 0);
    this.sunMesh.lookAt(0, 0, 0);

    // Moon position (opposite sun)
    this.moonMesh.position.set(-sunX, -sunY, 0);
    this.moonMesh.lookAt(0, 0, 0);

    // Light position
    this.sunLight.position.set(sunX + playerPos.x, sunY, playerPos.z);
    this.sunLight.target.position.copy(playerPos);
    this.sunLight.target.updateMatrixWorld();

    // Calculate daylight intensity based on sun height
    const sunAltitude = Math.sin(angle); // 1 = noon, -1 = midnight
    const dayFactor = Math.max(0, Math.min(1, (sunAltitude + 0.2) / 0.8));

    // Sky colors
    const daySky = new THREE.Color(0x78a7ff);
    const sunsetSky = new THREE.Color(0xf08050);
    const nightSky = new THREE.Color(0x0a0c18);

    let currentSky = new THREE.Color();
    if (dayFactor > 0.3) {
      currentSky.copy(daySky);
    } else if (dayFactor > 0.05) {
      const t = (dayFactor - 0.05) / 0.25;
      currentSky.copy(sunsetSky).lerp(daySky, t);
    } else {
      const t = dayFactor / 0.05;
      currentSky.copy(nightSky).lerp(sunsetSky, t);
    }

    scene.background = currentSky;
    if (scene.fog) {
      scene.fog.color.copy(currentSky);
    }

    // Lighting adjustments
    this.ambientLight.intensity = 0.2 + dayFactor * 0.6;
    this.sunLight.intensity = Math.max(0.1, dayFactor * 1.1);

    // Stars visibility
    const starMat = this.starPoints.material as THREE.PointsMaterial;
    starMat.opacity = Math.max(0, (1 - dayFactor * 2)) * 0.85;
  }
}
