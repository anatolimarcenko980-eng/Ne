/**
 * 3D Steve Character Model for third-person camera views in Minecraft Web Edition.
 */

import * as THREE from 'three';
import { ItemType } from '../types/game';
import { getAtlasMaterial, getBlockFaceUV } from './atlas';
import { BLOCKS, ITEMS } from './items';
import { getItemCanvas } from './textures';

export class PlayerModel {
  public group: THREE.Group = new THREE.Group();
  public head: THREE.Group;
  public body: THREE.Mesh;
  public leftArm: THREE.Mesh;
  public rightArm: THREE.Mesh;
  public leftLeg: THREE.Mesh;
  public rightLeg: THREE.Mesh;
  private heldItemMesh: THREE.Mesh | null = null;
  private currentItem: ItemType | null = null;

  constructor() {
    const skinMat = new THREE.MeshLambertMaterial({ color: 0xc48c66 });
    const hairMat = new THREE.MeshLambertMaterial({ color: 0x4a2e18 });
    const shirtMat = new THREE.MeshLambertMaterial({ color: 0x2bb0b0 });
    const pantsMat = new THREE.MeshLambertMaterial({ color: 0x22356b });
    const shoeMat = new THREE.MeshLambertMaterial({ color: 0x4a4a4a });

    // Head
    this.head = new THREE.Group();
    const headGeo = new THREE.BoxGeometry(0.5, 0.5, 0.5);
    const headMesh = new THREE.Mesh(headGeo, skinMat);
    this.head.add(headMesh);

    // Hair on top/back
    const hairGeo = new THREE.BoxGeometry(0.52, 0.2, 0.52);
    const hair = new THREE.Mesh(hairGeo, hairMat);
    hair.position.y = 0.18;
    this.head.add(hair);

    // Steve Eyes
    const eyeGeo = new THREE.PlaneGeometry(0.08, 0.05);
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0x224499 });
    const eyeL = new THREE.Mesh(eyeGeo, eyeMat);
    eyeL.position.set(-0.12, 0.02, 0.252);
    const eyeR = new THREE.Mesh(eyeGeo, eyeMat);
    eyeR.position.set(0.12, 0.02, 0.252);
    this.head.add(eyeL);
    this.head.add(eyeR);

    this.head.position.y = 1.45;
    this.group.add(this.head);

    // Body
    const bodyGeo = new THREE.BoxGeometry(0.5, 0.72, 0.28);
    this.body = new THREE.Mesh(bodyGeo, shirtMat);
    this.body.position.y = 0.88;
    this.group.add(this.body);

    // Arms
    const armGeo = new THREE.BoxGeometry(0.22, 0.7, 0.22);

    this.leftArm = new THREE.Mesh(armGeo, skinMat);
    this.leftArm.position.set(-0.38, 0.88, 0);
    this.group.add(this.leftArm);

    this.rightArm = new THREE.Mesh(armGeo, skinMat);
    this.rightArm.position.set(0.38, 0.88, 0);
    this.group.add(this.rightArm);

    // Legs
    const legGeo = new THREE.BoxGeometry(0.24, 0.72, 0.24);

    this.leftLeg = new THREE.Mesh(legGeo, pantsMat);
    this.leftLeg.position.set(-0.13, 0.36, 0);
    this.group.add(this.leftLeg);

    this.rightLeg = new THREE.Mesh(legGeo, pantsMat);
    this.rightLeg.position.set(0.13, 0.36, 0);
    this.group.add(this.rightLeg);

    this.group.visible = false;
  }

  public setHeldItem(item: ItemType | null) {
    if (this.currentItem === item && this.heldItemMesh) return;
    this.currentItem = item;

    if (this.heldItemMesh) {
      this.rightArm.remove(this.heldItemMesh);
      this.heldItemMesh.geometry.dispose();
      this.heldItemMesh = null;
    }

    if (!item) return;

    const itemDef = ITEMS[item];
    const isBlock = itemDef?.isBlock && BLOCKS[item as keyof typeof BLOCKS];

    if (isBlock) {
      const blockGeo = new THREE.BoxGeometry(0.25, 0.25, 0.25);
      const uvs: number[] = [];
      for (let f = 0; f < 6; f++) {
        const [u0, v0, u1, v1] = getBlockFaceUV(item as keyof typeof BLOCKS, f as 0 | 1 | 2 | 3 | 4 | 5);
        uvs.push(u0, v1, u1, v1, u0, v0, u1, v0);
      }
      blockGeo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));

      this.heldItemMesh = new THREE.Mesh(blockGeo, getAtlasMaterial());
      this.heldItemMesh.position.set(0, -0.32, 0.2);
      this.rightArm.add(this.heldItemMesh);
    } else {
      const itemCanvas = getItemCanvas(item);
      const tex = new THREE.CanvasTexture(itemCanvas);
      tex.magFilter = THREE.NearestFilter;
      tex.minFilter = THREE.NearestFilter;

      const spriteMat = new THREE.MeshLambertMaterial({
        map: tex,
        transparent: true,
        alphaTest: 0.1,
        side: THREE.DoubleSide,
      });

      const planeGeo = new THREE.PlaneGeometry(0.4, 0.4);
      this.heldItemMesh = new THREE.Mesh(planeGeo, spriteMat);
      this.heldItemMesh.position.set(0, -0.3, 0.2);
      this.heldItemMesh.rotation.set(Math.PI / 4, 0, 0);
      this.rightArm.add(this.heldItemMesh);
    }
  }

  public update(
    dt: number,
    pitch: number,
    yaw: number,
    isMoving: boolean,
    isSprinting: boolean,
    isSwinging: boolean,
    swingProgress: number
  ) {
    // Head looks up/down with pitch
    this.head.rotation.x = pitch;

    // Body rotation faces movement yaw
    this.group.rotation.y = yaw;

    // Walking animation for legs & arms
    if (isMoving) {
      const speed = isSprinting ? 12 : 8;
      const walkAngle = Math.sin(performance.now() * 0.001 * speed) * 0.6;
      this.leftLeg.rotation.x = walkAngle;
      this.rightLeg.rotation.x = -walkAngle;
      this.leftArm.rotation.x = -walkAngle * 0.8;
      if (!isSwinging) {
        this.rightArm.rotation.x = walkAngle * 0.8;
      }
    } else {
      this.leftLeg.rotation.x = 0;
      this.rightLeg.rotation.x = 0;
      this.leftArm.rotation.x = 0;
      if (!isSwinging) {
        this.rightArm.rotation.x = 0;
      }
    }

    // Arm swing when mining or hitting
    if (isSwinging) {
      const swing = Math.sin(swingProgress * Math.PI) * 1.4;
      this.rightArm.rotation.x = -swing;
      this.rightArm.rotation.z = -Math.sin(swingProgress * Math.PI) * 0.3;
    } else {
      this.rightArm.rotation.z = 0;
    }
  }
}
